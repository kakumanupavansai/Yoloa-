export default function ProgressBar({ percent = 0, className = '' }) {
  return (
    <div className={`h-2.5 w-24 rounded-full bg-accent-lilac ${className}`} role="progressbar" aria-valuenow={percent}>
      <div className="h-full rounded-full bg-brand" style={{ width: `${Math.min(100, percent)}%` }} />
    </div>
  )
}
