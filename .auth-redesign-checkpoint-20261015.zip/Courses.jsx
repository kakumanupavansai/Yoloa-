import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApi } from '../../hooks'
import { coursesApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import CoverImage from '../../components/ui/CoverImage'
import ProgressBar from '../../components/ui/ProgressBar'
import { Async } from '../../components/ui/States'
import { TrashIcon } from '../../components/ui/Icons'

// Figma: Desktop - 12 (student)  /  Desktop - 24 (admin, `admin` prop)
export default function Courses({ admin = false }) {
  const state = useApi(() => coursesApi.list(), [])
  const [tab, setTab] = useState('all')
  const [q, setQ] = useState('')
  const [busyId, setBusyId] = useState(null)
  const [error, setError] = useState('')
  const base = admin ? '/admin/courses' : '/student/courses'

  const enroll = async (id) => {
    setBusyId(id); setError('')
    try { await coursesApi.enroll(id); await state.reload() } catch (e) { setError(e.message) } finally { setBusyId(null) }
  }

  const remove = async (c) => {
    const extra = c.students ? ` ${c.students} enrolled student(s) will lose access and their progress.` : ''
    if (!window.confirm(`Delete course "${c.title}"?${extra} This cannot be undone.`)) return
    setBusyId(c.id); setError('')
    try { await coursesApi.remove(c.id); await state.reload() } catch (e) { setError(e.message) } finally { setBusyId(null) }
  }

  return (
    <>
      <Topbar title="Courses" onSearch={setQ} />
      <Async state={state}>{(courses) => {
        const mine = (s) => courses.filter((c) => c.enrolled && c.status === s)
        const shown = courses.filter((c) => {
          const inTab = tab === 'all' || (c.enrolled && c.status === tab)
          return inTab && c.title.toLowerCase().includes(q.toLowerCase())
        })
        const tabs = [['all', `All courses (${courses.length})`], ...(admin ? [] : [['ongoing', `Ongoing (${mine('ongoing').length})`], ['completed', `Completed (${mine('completed').length})`]])]
        return (
          <section className="card mt-2 rounded-[10px] p-3 sm:p-5">
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 px-2 sm:gap-x-10 sm:px-4">
              {tabs.map(([k, label]) => (
                <button key={k} onClick={() => setTab(k)} className={`text-base font-bold sm:text-lg ${tab === k ? 'text-brand underline underline-offset-8' : ''}`}>{label}</button>))}
            </div>
            {error && <p className="mt-3 px-4 text-sm text-red-600">{error}</p>}
            <div className="mt-5 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {shown.map((c) => (
                <article key={c.id} className="rounded-[20px] bg-surface p-1 shadow-panel">
                  <Link to={`${base}/${c.id}`}><CoverImage src={c.cover} title={c.title.split(' ')[0]} accent={c.accent} className="h-44 w-full rounded-[20px]" /></Link>
                  <div className="p-4">
                    <h3 className="text-sm font-bold text-ink-soft">{c.title}</h3>
                    {admin && c.enrollment && <p className="text-xs text-ink-soft">{c.enrollment}</p>}
                    {!admin && c.enrolled && (
                      <div className="mt-2 flex items-center gap-2 text-xs text-ink-soft"><ProgressBar percent={c.percent} className="w-full" />{c.percent}%</div>)}
                    {admin
                      ? (
                        <div className="mt-3 flex gap-2">
                          <Link to={`${base}/${c.id}`} className="flex-1 rounded-lg border border-black bg-surface-gray py-2 text-center text-sm">Open</Link>
                          <button disabled={busyId === c.id} onClick={() => remove(c)} aria-label={`Delete course ${c.title}`} title="Delete course"
                            className="rounded-lg border border-red-400 px-3 text-red-600 hover:bg-red-50 disabled:opacity-50"><TrashIcon className="h-5 w-5" /></button>
                        </div>)
                      : c.enrolled
                        ? <Link to={`${base}/${c.id}/watch`} className="mt-3 block rounded-lg border border-black bg-surface-gray py-2 text-center text-sm">{c.status === 'completed' ? 'Review' : 'Resume'}</Link>
                        : <button disabled={busyId === c.id} onClick={() => enroll(c.id)} className="btn-blue mt-3 w-full">{busyId === c.id ? 'Enrolling…' : 'Enroll'}</button>}
                  </div>
                </article>))}
              {!shown.length && <p className="p-4 text-sm text-ink-soft">No courses found.</p>}
            </div>
          </section>)
      }}</Async>
    </>
  )
}
