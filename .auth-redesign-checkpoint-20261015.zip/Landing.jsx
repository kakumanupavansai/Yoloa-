import { Link } from 'react-router-dom'
import Logo from '../components/ui/Logo'
import HeroArt from '../components/ui/HeroArt'

// Figma: Desktop - 1
export default function Landing() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-[#fdf9f8]">
      <div className="absolute inset-y-0 right-0 hidden w-[60%] bg-hero md:block" style={{ clipPath: 'ellipse(75% 70% at 100% 50%)', borderTopLeftRadius: '55% 100%', borderBottomLeftRadius: '55% 100%' }} />
      <div className="relative grid min-h-screen items-center md:grid-cols-2">
        <div className="px-6 py-10 sm:px-8 md:px-16 md:py-0">
          <Logo className="text-[28px]" />
          <p className="mt-8 text-2xl font-bold text-[#1a1a8c] sm:mt-10 sm:text-3xl"><span className="text-[#e8264f]">Y</span>ou - Only - Learn - Once</p>
          <div className="mt-8 flex flex-wrap gap-4 sm:mt-10 sm:gap-6">
            <Link to="/login?role=student" className="rounded-lg border border-black bg-brand-dark px-5 py-3 text-lg font-bold text-white hover:opacity-90">Login as&nbsp; Student</Link>
            <Link to="/login?role=admin" className="rounded-lg border border-black bg-white px-5 py-3 text-lg font-bold hover:bg-surface-gray">Login as Admin</Link>
          </div>
          <div className="mx-auto mt-8 h-56 w-full max-w-sm md:hidden"><HeroArt /></div>
        </div>
        <div className="hidden h-[80vh] md:block"><HeroArt /></div>
      </div>
    </div>
  )
}
