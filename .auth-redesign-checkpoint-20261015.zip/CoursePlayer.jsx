import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useApi } from '../../hooks'
import { coursesApi, chaptersApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import Avatar from '../../components/ui/Avatar'
import ProgressBar from '../../components/ui/ProgressBar'
import { PlayIcon } from '../../components/ui/Icons'
import { Loading, ErrorBox } from '../../components/ui/States'
import { useAuth } from '../../context/AuthContext'
import { toEmbedUrl } from '../../utils'

// Figma: Desktop - 9  (+ per-chapter progress tracking)
export default function CoursePlayer() {
  const { id } = useParams()
  const { user } = useAuth()
  const state = useApi(() => coursesApi.player(id), [id])
  const [modules, setModules] = useState([])
  const [active, setActive] = useState(null)
  const [percent, setPercent] = useState(0)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  useEffect(() => {
    if (!state.data) return
    setModules(state.data.modules); setActive(state.data.currentModuleId); setPercent(state.data.percent)
  }, [state.data])

  if (state.loading && !state.data) return <><Topbar title="Courses" showProfile={false} /><Loading /></>
  if (state.error?.status === 403) return (
    <><Topbar title="Courses" showProfile={false} />
      <div className="card mx-auto mt-10 max-w-md p-8 text-center">
        <p className="font-bold">{state.error.message}</p>
        <Link to={`/student/courses/${id}`} className="btn-blue mt-4">Go to course page to enroll</Link>
      </div></>)
  if (state.error) return <><Topbar title="Courses" showProfile={false} /><ErrorBox error={state.error} onRetry={state.reload} /></>

  const p = state.data
  const idx = modules.findIndex((m) => m.id === active)
  const current = modules[idx]
  const next = modules[idx + 1]

  const setComplete = async (completed) => {
    if (!current) return
    setSaving(true); setMsg('')
    try {
      const r = await chaptersApi.setComplete(id, current.id, completed)
      setModules((ms) => ms.map((m) => (m.id === current.id ? { ...m, completed } : m)))
      setPercent(r.percent)
      if (r.courseCompleted) setMsg('🎉 Course completed!')
      else if (completed && next) setActive(next.id)
    } catch (e) { setMsg(e.message) } finally { setSaving(false) }
  }

  const embed = toEmbedUrl(current?.videoUrl)
  return (
    <>
      <Topbar title="Courses" showProfile={false} />
      <div className="mt-2 flex flex-col gap-5 xl:flex-row">
        <div className="min-w-0 flex-1">
          <div className="mb-3 flex flex-wrap items-center gap-x-4 gap-y-2">
            <span className="rounded-lg bg-[#e3dcff] px-4 py-2 text-lg font-bold sm:px-8 sm:text-xl">{p.courseTitle}</span>
            <div className="flex flex-1 items-center gap-2 text-sm font-bold"><ProgressBar percent={percent} className="w-full max-w-xs" />{percent}%</div>
          </div>
          <div className="relative aspect-video overflow-hidden bg-black">
            {embed
              ? <iframe key={current?.id} title={current?.title} src={embed} className="h-full w-full" allowFullScreen />
              : <div className="flex h-full flex-col items-center justify-center gap-2 bg-gradient-to-br from-slate-500 to-slate-800 text-white/80"><PlayIcon className="h-20 w-20" /><span className="text-sm">No video attached to this chapter yet</span></div>}
            <span className="absolute left-0 top-0 bg-white/80 px-4 py-2 text-xs font-bold sm:px-10 sm:py-3">Video</span>
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <div className="mr-auto"><h3 className="text-sm font-bold">{current?.title}</h3><p className="text-xs text-ink-soft">{current?.duration}</p></div>
            {current?.completed
              ? <button disabled={saving} onClick={() => setComplete(false)} className="btn-outline text-xs">✓ Completed – mark as not done</button>
              : <button disabled={saving} onClick={() => setComplete(true)} className="btn-primary">{saving ? 'Saving…' : next ? 'Mark complete & next' : 'Mark complete'}</button>}
            {next && <button onClick={() => setActive(next.id)} className="btn-outline text-xs">Next lesson →</button>}
          </div>
          {msg && <p className="mt-2 text-sm font-bold text-brand">{msg}</p>}
          <p className="mt-4 text-sm">{p.description}</p>
        </div>
        <aside className="card w-full p-4 xl:w-[300px]">
          <div className="flex items-center gap-3"><Avatar src={user?.avatar} name={user?.name} size={56} /><div><p className="text-sm font-bold">{user?.name}</p><p className="text-xs">Student</p></div></div>
          <h2 className="mt-3 text-xl font-bold">Modules</h2>
          <ul className="mt-2 space-y-3">
            {modules.map((m) => (
              <li key={m.id}>
                <button onClick={() => setActive(m.id)} className={`flex w-full items-center gap-4 rounded-lg border px-3 py-3 text-left text-xs ${active === m.id ? 'border-brand bg-brand-soft text-brand' : 'border-black/60 bg-white'}`}>
                  {m.completed ? <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-green-600 text-[11px] text-white">✓</span> : <PlayIcon className="h-5 w-5 shrink-0" />}
                  <span className="flex-1">{m.title}</span><span>{m.duration}</span>
                </button>
              </li>))}
          </ul>
          <Link to={`/student/courses/${id}`} className="mt-5 block w-full rounded-lg bg-brand py-4 text-center text-sm font-bold text-white hover:opacity-90">Open Course</Link>
        </aside>
      </div>
    </>
  )
}
