import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { examsApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { PencilIcon, TrashIcon, MenuLinesIcon } from '../../components/ui/Icons'

const blankQ = () => ({ id: crypto.randomUUID(), text: '', choices: ['', '', '', ''], correct: 0, score: '', points: '' })

// Figma: Desktop - 23
export default function ExamCreation() {
  const nav = useNavigate()
  const [exam, setExam] = useState({ title: 'Midterm', subject: '', duration: '50 mins' })
  const [qs, setQs] = useState([blankQ()])
  const [open, setOpen] = useState(0)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const upd = (i, patch) => setQs(qs.map((q, j) => (j === i ? { ...q, ...patch } : q)))

  const submit = async (status) => {
    setBusy(true); setError('')
    try { await examsApi.create({ ...exam, status, questions: qs.map(({ id, ...q }) => q) }); nav('/admin/exams') }
    catch (e) { setError(e.message) } finally { setBusy(false) }
  }

  return (
    <>
      <Topbar title="Exam Creation" />
      <section className="mt-2 rounded-[10px] bg-white p-3 shadow-panel sm:p-6">
        <div className="flex flex-wrap items-center gap-6">
          <label className="flex w-full flex-col items-start gap-1 font-bold sm:w-auto sm:flex-row sm:items-center sm:gap-3">Exam Title: <input className="input w-full sm:w-44" value={exam.title} onChange={(e) => setExam({ ...exam, title: e.target.value })} /></label>
          <label className="flex w-full flex-col items-start gap-1 font-bold sm:w-auto sm:flex-row sm:items-center sm:gap-3">Subject: <input className="input w-full sm:w-44" placeholder="e.g. Chemistry" value={exam.subject} onChange={(e) => setExam({ ...exam, subject: e.target.value })} /></label>
          <label className="flex w-full flex-col items-start gap-1 font-bold sm:w-auto sm:flex-row sm:items-center sm:gap-3">Duration: <input className="input w-full sm:w-44" value={exam.duration} onChange={(e) => setExam({ ...exam, duration: e.target.value })} /></label>
        </div>
        <div className="mt-6 space-y-5">
          {qs.map((q, i) => (
            <div key={q.id} className="relative rounded-[10px] border border-gray-300 bg-surface p-3 sm:p-5">
              <div className="absolute right-4 top-3 flex gap-3 text-gray-700">
                <button aria-label="Edit question" onClick={() => setOpen(i)}><PencilIcon className="h-5 w-5" /></button>
                <button aria-label="Delete question" onClick={() => setQs(qs.filter((_, j) => j !== i))}><TrashIcon className="h-5 w-5" /></button>
              </div>
              <div className="flex flex-wrap items-start gap-x-3 gap-y-2 pr-16">
                <MenuLinesIcon className="mt-1 h-5 w-5" /><span className="font-bold">Question ({i + 1}):</span>
                {open === i
                  ? <textarea rows={2} aria-label={`Question ${i + 1} text`} className="input w-full max-w-xl sm:w-auto sm:flex-1" value={q.text} onChange={(e) => upd(i, { text: e.target.value })} />
                  : <button onClick={() => setOpen(i)} className="pt-1 text-left text-xs">{q.text || '(empty)'}</button>}
              </div>
              {open === i && (
                <div className="mt-6 sm:pl-10">
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    {q.choices.map((c, k) => <input key={k} className="input" placeholder={`Choice ${k + 1}`} value={c} onChange={(e) => upd(i, { choices: q.choices.map((x, m) => (m === k ? e.target.value : x)) })} />)}
                  </div>
                  <div className="mt-6 flex flex-wrap items-center gap-5 text-sm">
                    <span>Correct Choice:</span>
                    {['A', 'B', 'C', 'D'].map((l, k) => (
                      <label key={l} className="flex items-center gap-1 text-xs"><input type="radio" name={`correct-${q.id}`} checked={q.correct === k} onChange={() => upd(i, { correct: k })} className="accent-brand" />{l}</label>))}
                  </div>
                  <div className="mt-4 flex flex-wrap gap-4 text-xs font-bold sm:gap-6">
                    <label>Score: <input type="number" min="0" className="input ml-1 w-20" value={q.score} onChange={(e) => upd(i, { score: e.target.value })} /></label>
                    <label>Points: <input type="number" min="0" className="input ml-1 w-20" value={q.points} onChange={(e) => upd(i, { points: e.target.value })} /></label>
                  </div>
                </div>)}
            </div>))}
        </div>
        <button onClick={() => { setQs([...qs, blankQ()]); setOpen(qs.length) }} className="mt-6 w-full rounded-[10px] border border-red-400 py-4 text-left text-xs font-bold text-red-600 px-8">+ Add Question</button>
        {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-4 sm:gap-8">
          <button onClick={() => nav('/admin/exams')} className="text-red-600">Discard</button>
          <button disabled={busy} onClick={() => submit('draft')} className="rounded-lg border border-gray-400 bg-surface px-5 py-2 hover:bg-surface-gray">Keep in Draft</button>
          <button disabled={busy} onClick={() => submit('published')} className="rounded-lg bg-brand px-12 py-2 text-white hover:opacity-90 disabled:opacity-60">Publish</button>
        </div>
        <p className="mt-3 text-center text-xs text-gray-500">Published exams appear in the students' Quizzes. “Keep in Draft” keeps it hidden from students.</p>
      </section>
    </>
  )
}
