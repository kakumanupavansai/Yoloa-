/** Design tokens taken from the Figma file */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['"Istok Web"', 'ui-sans-serif', 'system-ui', 'sans-serif'] },
      colors: {
        brand: { DEFAULT: '#2b59ce', dark: '#2626ae', soft: '#d4deff', nav: '#adbbde' },
        surface: { DEFAULT: '#fffafa', muted: '#f7f3f3', gray: '#ebebeb', line: '#d9d9d9' },
        pastel: { green: '#a4f7b1', pink: '#f1b9c9', blue: '#d4deff', yellow: '#f5de99' },
        accent: { purple: '#7b70ee', lilac: '#d5cbfb', orange: '#fe9519', coral: '#ff7f7f' },
        ink: { DEFAULT: '#000', soft: '#3e3e3e', nav: '#373739' },
      },
      borderRadius: { card: '20px' },
      boxShadow: {
        panel: '4px 4px 10px rgba(0,0,0,0.25)',
        row: '0 4px 4px rgba(0,0,0,0.25)',
      },
      backgroundImage: {
        app: 'linear-gradient(227.7deg, #efefef 0.7%, rgba(74,153,163,0) 113.5%)',
        hero: 'linear-gradient(180deg, #4e68a5 0%, #b5c4d2 100%)',
        nav: 'linear-gradient(186deg, #adbbde 15%, rgba(182,188,202,0) 129%)',
      },
    },
  },
  plugins: [],
}
