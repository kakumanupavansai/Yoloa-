# YOLOA LMS – Django REST backend (PostgreSQL)

Backend for the YOLOA React frontend. Endpoints/JSON shapes match `src/services/api.js` in the frontend.

## 1. Setup
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # edit DB_* values
```
### PostgreSQL
```sql
-- in psql
CREATE DATABASE yoloa;
```
(or `USE_SQLITE=1` in `.env` for a quick trial without Postgres)

```bash
python manage.py migrate
python manage.py seed            # demo data from the Figma screens
python manage.py runserver       # http://localhost:8000
```
Logins: **admin / admin123** (admin) · **swetha / student123** (student). Django admin: `/admin/`.

## 2. Test with Postman
Import both files from `postman/`:
`YOLOA-LMS.postman_collection.json` and `YOLOA-Local.postman_environment.json`, select the *YOLOA Local* environment.
1. Run **1. Auth → Login – Student** (token saved automatically) → run the *Student* folder.
2. Run **Login – Admin** → run the *Admin* folder.
Each request has test scripts (status codes), so you can also use the Collection Runner.

Automated tests: `python manage.py test` (use `USE_SQLITE=1` for the local SQLite test database).

## 3. Connect the React frontend
In the frontend `.env`:
```
VITE_USE_MOCK=false
VITE_API_URL=/api
```
`vite.config.js` proxies `/api` → `http://localhost:8000` (no CORS issues in dev). `CORS_ALLOWED_ORIGINS` is set for production-style setups.

## 4. API summary
Auth is JWT: `Authorization: Bearer <token>`. Errors are `{ "message": "...", "errors": {...} }`.

| Endpoint | Who | Notes |
|---|---|---|
| POST `/api/auth/login` | public | `{username,password,role}` → `{token,refresh,user}`; 403 if role mismatches |
| POST `/api/auth/refresh` | public | `{refresh}` → `{access}` |
| GET `/api/auth/me` | any | |
| GET `/api/student/dashboard` | any | leaderboard = top 4 by total quiz score |
| GET `/api/admin/dashboard` | admin | `stats.total` = students registered, `newThisWeek`, `enrolled` (joined ≥1 course); no schedule |
| POST `/api/announcements` | admin | `{text}` |
| GET `/api/courses` · POST `/api/courses` | any · admin | POST is multipart (`cover` file, `chapters` JSON string) |
| DELETE `/api/courses/:id` | admin | deletes the course + chapters, lesson content, enrollments, progress; linked exams are kept |
| GET `/api/courses/:id` | any | includes `enrolled`, `percent`, and `chapters[{id,title,duration,completed}]` |
| POST / DELETE `/api/courses/:id/enroll` | student | enroll is idempotent (201 first time, then 200); unenroll keeps chapter progress |
| GET `/api/courses/:id/player` | enrolled student / admin | 403 `Enroll in this course to start learning.` if not enrolled; modules carry `completed` + `videoUrl` |
| PUT `/api/chapters/:id/progress` | enrolled student | `{completed: true or false}` → `{percent,status,currentChapter,courseCompleted}`; 100% flips the course to *completed* |
| GET `/api/quizzes` · `/api/quizzes/:id` · POST `/api/quizzes/:id/attempts` | any | list/detail include `attempts` + `bestScore`; detail has `durationMinutes`; POST answers `{questionId: choiceIndex}` → `{score,total,percent,review[]}` (review reveals correct answers *after* submitting); unanswered = skipped |
| GET/POST `/api/exams` · GET/PUT/DELETE `/api/exams/:id` | **admin only** | the exam builder (responses include correct answers). `status`: `draft` or `published` |
| GET `/api/library` · GET `/api/notes/apps` | any | |
| GET `/api/calendar?year=&month=` · POST `/api/calendar` | any | |
| GET/PUT `/api/profile` · POST `/api/profile/avatar` | any | avatar is multipart field `avatar` |

## 5. Enrollment, progress & quizzes – how it works
- `GET /courses` returns every course with `status`: `ongoing` / `completed` (enrolled) or `available` (not enrolled yet) for students.
- Progress is per chapter (`ChapterProgress`). After each change the server recomputes the enrollment's `percent` and `current_chapter`; completion is awarded by a passed final exam (or preserved legacy completion), not by lesson progress alone.
- Leaderboard = sum of each student's **best** score per quiz (retakes can't inflate it).
- Videos: set a chapter's *Video URL* in the Course Creation screen or in `/admin/`. YouTube watch/share links are converted to embeds by the frontend. The seed leaves videos empty (a placeholder is shown).

## 6. Exams = Quizzes (one table)
Admin **Exams** and student **Quizzes** are the *same* `Exam` records:
- **Published** → shows up in the student *Quizzes* list (same id, title, subject, questions, points, duration).
- **Draft** → admin only. **Unpublish** (PUT `{status:"draft"}`) hides it again; attempt history is kept.
- **Delete** an exam with no history → it disappears for students too. Assessments with attempts are retained and must be archived/unpublished to preserve the audit trail.
- Publishing is validated: at least one question, every question needs text + 2 choices, and the correct choice can't be empty (otherwise 400 with a readable `message`).
- Students never receive correct answers until after they submit; `/api/exams*` is admin-only for that reason.
- Upgrading an existing database: just run `python manage.py migrate` (migration `0003` drops the old `kind` column; no data is lost – old quizzes and exams simply appear in both places).

## 7. Models (lms/models.py)
User(role) · Course · Chapter · CourseContent · Enrollment · Exam(assessment_type) · Question · Attempt · GradingReview · LoginEvent · QuestionImportBatch · LibraryItem · Announcement · CalendarEvent · ScheduleItem · Assignment.
Manage everything in `/admin/` (upload covers, library files, add students and enrollments).

## 8. Assessment 2.0 and administration
- A course can have unlimited published module quizzes and one published final exam. Required chapters must have a passed module quiz before the final can start.
- Final attempts always use a server-side 600-second deadline and a 60% pass mark. Refresh/reconnect resumes the same in-progress attempt; answer saves are versioned, expiry is finalized server-side, and submission is idempotent.
- Every attempt is retained. Students may retake module quizzes and finals without losing the latest or best result. Passing a final marks the enrollment complete; later failed retakes never remove that completion.
- `GET /api/assessments`, `/api/assessments/:id`, `/api/assessments/:id/history`, `POST /api/assessments/:id/start`, `PUT /api/attempts/:id/answers`, and `POST /api/attempts/:id/submit` are the student assessment API. Answers are never returned before finalization.
- Admin-only `/api/admin/students`, `/api/admin/students/:id`, `/api/admin/analytics/logins`, and `/api/admin/analytics/exams` provide directory and aggregate reporting without passwords, private answers, or personal countdowns.
- Excel imports use `/api/admin/question-imports/upload`, `/preview`, and `/confirm`. Uploads are staged, worksheet/column mapping is explicit, validation happens before confirmation, and confirmation is transactional/idempotent. `.xlsx` files are limited to 5 MB and parsed with `openpyxl` in read-only/data-only mode.
- Run `python manage.py finalize_expired_attempts` from cron, Celery, or a task scheduler at least once per minute as a backstop for attempts whose browser has disconnected.

Question types are `single`, `multiple`, `true_false`, and `short`. Multiple-answer questions are all-or-nothing. Short answers use configured accepted answers for automatic scoring and can be changed through the admin review endpoint with an audit record.

## Before production
Set a real `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=False`, proper `ALLOWED_HOSTS`, serve media via S3/nginx, and add pagination if lists grow.
