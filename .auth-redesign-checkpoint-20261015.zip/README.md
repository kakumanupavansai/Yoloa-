# YOLOA LMS – Frontend (React + Vite + Tailwind)

Converted from the Figma file **Edu-learn LMS UI**. 17 Figma screens → 15 routes.

## Run
```bash
npm install
npm run dev        # http://localhost:5173
```
Runs in **mock mode** by default (`VITE_USE_MOCK=true` in `.env`) – any username/password logs in.
Use "Login as Student / Admin" on the landing page.

## Figma screen → route
| Figma | Route | File |
|---|---|---|
| Desktop 1 | `/` | pages/Landing.jsx |
| Desktop 2 | `/login?role=student\|admin` | pages/Login.jsx |
| Desktop 3 | `/student/dashboard` | pages/student/Dashboard.jsx |
| Desktop 12 | `/student/courses` | pages/student/Courses.jsx |
| Desktop 4 | `/student/courses/:id` | pages/student/CourseDetail.jsx |
| Desktop 9 | `/student/courses/:id/watch` | pages/student/CoursePlayer.jsx |
| Desktop 6 | `/student/calendar` | pages/student/Calendar.jsx |
| Desktop 7 | `/student/notes` | pages/student/Notes.jsx |
| Desktop 5 | `/student/quizzes` | pages/student/Quizzes.jsx |
| Desktop 13 | `/student/library` | pages/student/Library.jsx |
| Desktop 15 | `/student/profile` | pages/student/Profile.jsx |
| Desktop 19 | `/admin/dashboard` | pages/admin/Dashboard.jsx |
| Desktop 24 | `/admin/courses` | Courses.jsx (`admin` prop) |
| Desktop 20 | `/admin/courses/:id` | CourseDetail.jsx (`admin` prop) |
| Desktop 22 | `/admin/course-creation` | pages/admin/CourseCreation.jsx |
| Desktop 21 | `/admin/exams` | pages/admin/Exams.jsx |
| Desktop 23 | `/admin/exams/new` | pages/admin/ExamCreation.jsx |

## Connecting your backend
1. Set `VITE_USE_MOCK=false` and `VITE_API_URL` in `.env` (dev proxy: `/api` → `http://localhost:8000`, see `vite.config.js`).
2. Every call lives in **`src/services/api.js`** – one function per endpoint. Pages never call `fetch` directly.
3. `src/services/http.js` adds the `Authorization: Bearer <jwt>` header and auto-logs-out on 401.
4. Mock shapes in `src/data/mock.js` **are** the response contract – return the same JSON from your API.

### API contract
| Method & path | Request | Response |
|---|---|---|
| POST `/auth/login` | `{username,password,role}` | `{token,user}` |
| GET `/auth/me` | – | `user` `{id,name,role,email,username,firstName,lastName,avatar}` |
| GET `/student/dashboard` | – | `{announcement,leaderboard[],completion[],assignments[],schedule[],upcomingEvents[]}` |
| GET `/admin/dashboard` | – | `{announcements[],stats{total,absent,present},schedule[],upcomingEvents[]}` |
| GET `/courses` | – | `[{id,title,status:'ongoing'\|'completed',cover,enrollment}]` |
| GET `/courses/:id` | – | `{title,description,cover,professor,content[],progress[],publishedExams[]}` |
| GET `/courses/:id/player` | – | `{courseTitle,lessonTitle,videoUrl,description,modules[]}` |
| POST `/courses` | multipart: title, description, startDate, endDate, chapters(JSON), cover | course |
| GET `/quizzes` · POST `/quizzes/:id/attempts` | – / `{answers}` | `[{id,title,subject,questions,points}]` / `{score}` |
| GET `/library` | – | `[{id,title,subject,cover,fileUrl}]` |
| GET `/calendar?year=&month=` | – | `{events[{id,date,title,type}],daySchedule}` |
| GET/PUT `/profile`, POST `/profile/avatar` | profile fields / multipart `avatar` | profile / `{url}` |
| GET/POST `/exams`, PUT/DELETE `/exams/:id` | `{title,duration,status,questions[{text,choices[4],correct,score,points}]}` | exam(s) |
| POST `/announcements` | `{text}` | announcement |

## Enrolling, chapter progress & quizzes
- **Courses** (`/student/courses`): cards show *Enroll* for new courses, *Resume/Review* + progress bar for enrolled ones. The course page has the same Enroll button and a chapter checklist.
- **Lesson player** (`/student/courses/:id/watch`): opens on the first unfinished chapter; *Mark complete & next* saves progress (`PUT /chapters/:id/progress`) and updates the % bar. Not enrolled → friendly message with a link to enroll. Videos play when a chapter has a Video URL (YouTube links auto-embed).
- **Quizzes** (`/student/quizzes/:id`): *Preview* = details page, *Attempt/Retake* = quiz runner (one question at a time, question navigator, countdown timer that auto-submits, unanswered warning) → result with score and a full answer review. Best score and attempt count show on the list.
- Admin → Course Creation now has an optional *Video URL* per chapter.
- **Exams = Quizzes:** an exam the admin *publishes* (Admin → Exams, or “Publish” in the exam builder) is exactly what students see under Quizzes; *Unpublish* / *Delete* removes it for students too. The exam builder has a *Subject* field.
- **Admin dashboard:** the Schedule panel is replaced by a *Students registered* card (total, new this week, enrolled in a course).

## Tests
```bash
npm test                                   # UI flows in mock mode (enroll, progress, quiz)
# against your real Django server (seeded):
VITE_USE_MOCK=false VITE_API_URL=http://localhost:8000/api npm test
```

## Responsive design (phones, tablets, laptops)
Mobile-first Tailwind classes; no extra libraries. Tested at 320, 375, 768 and 1280 px on every page (no horizontal scrolling).

| Width | Breakpoint | Layout |
|---|---|---|
| < 640 px | phone | single column · top bar with ☰ menu, logo, avatar · rows stack · 2-column Library/Notes · calendar shows dots + an events list |
| 640 – 1023 px | `sm` / `md` tablet | same top bar + slide-in menu · roomier padding, 3-column Library · two-column grids where space allows |
| ≥ 1024 px | `lg` desktop | fixed sidebar (as in the Figma design) · top bar hidden · profile in the page header |
| ≥ 1280 px | `xl` | right-hand panels (schedule, course progress…) sit beside the content instead of below it |

How it's built
- `components/layout/AppLayout.jsx` – picks sidebar (≥ lg) or `MobileNav` (< lg).
- `components/layout/MobileNav.jsx` – sticky top bar + accessible slide-in menu (Esc / backdrop / ✕ close it, focus is managed, page scroll is locked, closes after you navigate, respects phone notches via `env(safe-area-inset-*)`).
- `components/layout/Topbar.jsx` – on phones: title + icons on row 1, full-width search on row 2.
- Pages use `flex-wrap`, `grid-cols-1 sm:grid-cols-…`, and `px-4 sm:px-10` style padding instead of fixed widths.

Try it yourself: open the app in Chrome → press **F12** → click the device icon (**Ctrl+Shift+M**) → pick *iPhone SE*, *iPhone 14*, *iPad* or drag the width.
When you add new pages: avoid fixed pixel widths, wrap rows with `flex-wrap` or stack them below `sm`, and keep tap targets ≥ 44 px.

## Design tokens
Colors, font (Istok Web), shadows and gradients from Figma live in `tailwind.config.js`
(`brand`, `surface`, `pastel`, `accent`, `ink`). Reusable classes (`.card`, `.btn-*`, `.input`, `.pill`) are in `src/index.css`.

## Things to finish on your side
- **Images/illustrations**: Figma assets couldn't be exported automatically. Logo (`components/ui/Logo.jsx`) and the login illustration (`HeroArt.jsx`) are placeholders – drop your exported files in `public/` and swap them in. Course covers, book covers and avatars come from the API (`cover`, `avatar` fields); gradient/initials fallbacks show until then.
- Notes page shows launcher tiles for Google/Office apps (as designed) – replace with real note CRUD if needed.
- Quiz "Attempt/Preview", Help, search-to-API, notifications and the "Daily/Weekly/Yearly" calendar views are UI-only for now.
