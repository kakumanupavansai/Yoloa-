import { useEffect, useState, useCallback } from 'react'
// Tiny data hook: const { data, loading, error, reload } = useApi(() => coursesApi.list(), [])
export function useApi(fn, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: null })
  const run = useCallback(() => {
    setState((s) => ({ ...s, loading: true, error: null }))
    return fn().then((data) => setState({ data, loading: false, error: null }))
      .catch((error) => setState({ data: null, loading: false, error }))
  }, deps) // eslint-disable-line
  useEffect(() => { run() }, [run])
  return { ...state, reload: run }
}
