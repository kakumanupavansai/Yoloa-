import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApi } from '../../hooks'
import { adminApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'

export default function Students() {
  const [query, setQuery] = useState('')
  const state = useApi(() => adminApi.students(query ? { q: query } : {}), [query])
  return <><Topbar title="Students" onSearch={setQuery} /><Async state={state}>{(data) => <section className="mt-2 rounded-[10px] bg-white p-4 shadow-panel sm:p-6"><div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-bold">Student directory</h2><span className="text-sm text-gray-500">{data.total} students</span></div><div className="mt-4 overflow-x-auto"><table className="w-full min-w-[700px] text-left text-sm"><thead><tr className="border-b text-xs uppercase text-gray-500"><th className="p-3">Student</th><th className="p-3">Email</th><th className="p-3">Registered</th><th className="p-3">Courses</th><th className="p-3">Latest sign-in</th><th className="p-3" /></tr></thead><tbody>{data.results.map((student) => <tr key={student.id} className="border-b last:border-0"><td className="p-3 font-bold">{student.name}<span className="block text-xs font-normal text-gray-500">@{student.username}</span></td><td className="p-3">{student.email || '—'}</td><td className="p-3">{student.registeredAt ? new Date(student.registeredAt).toLocaleDateString() : '—'}</td><td className="p-3">{student.enrollments.length}</td><td className="p-3">{student.lastLogin ? new Date(student.lastLogin).toLocaleString() : 'Never'}</td><td className="p-3 text-right"><Link className="btn-outline text-xs" to={`/admin/students/${student.id}`}>Details</Link></td></tr>)}{!data.results.length && <tr><td colSpan="6" className="p-8 text-center text-gray-500">No students match this search.</td></tr>}</tbody></table></div></section>}</Async></>
}
