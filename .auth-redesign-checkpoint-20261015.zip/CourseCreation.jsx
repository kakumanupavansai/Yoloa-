import { useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { coursesApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { UploadIcon, CalSmallIcon } from '../../components/ui/Icons'

// Figma: Desktop - 22
export default function CourseCreation() {
  const nav = useNavigate()
  const fileRef = useRef()
  const [form, setForm] = useState({ title: '', description: '', startDate: '', endDate: '' })
  const [chapters, setChapters] = useState([{ title: '', videoUrl: '' }, { title: '', videoUrl: '' }])
  const [cover, setCover] = useState(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })

  const publish = async (e) => {
    e.preventDefault(); setBusy(true); setError('')
    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => fd.append(k, v))
    fd.append('chapters', JSON.stringify(chapters.filter((c) => c.title.trim())))  // [{title, videoUrl}]
    if (cover) fd.append('cover', cover)
    try { await coursesApi.create(fd); nav('/admin/courses') } catch (err) { setError(err.message) } finally { setBusy(false) }
  }
  const drop = (e) => { e.preventDefault(); setCover(e.dataTransfer.files[0]) }

  return (
    <>
      <Topbar title="Course Creation" />
      <form onSubmit={publish} className="mt-2 rounded-[10px] bg-white p-4 shadow-panel sm:p-6">
        <h2 className="text-xl font-bold">Upload New Course</h2>
        <div className="mt-3 grid gap-8 lg:grid-cols-2">
          <div className="space-y-4">
            <div><label className="label">Title</label><input required className="input" placeholder="Type here" value={form.title} onChange={set('title')} /></div>
            <div><label className="label">Description</label><textarea rows={5} className="input" placeholder="Type here" value={form.description} onChange={set('description')} /></div>
          </div>
          <div onDragOver={(e) => e.preventDefault()} onDrop={drop} onClick={() => fileRef.current.click()}
            className="flex h-32 cursor-pointer flex-col items-center justify-center gap-2 self-start rounded-[10px] border border-gray-300 bg-surface text-xs font-bold text-brand-dark hover:bg-brand-soft/40">
            <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => setCover(e.target.files[0])} />
            {cover ? <span>{cover.name}</span> : <><span>Upload cover image</span><UploadIcon className="h-6 w-6" /><span>Drop your file here</span></>}
          </div>
        </div>
        <h3 className="mt-6 font-bold">Course Content</h3>
        <ul className="mt-2 max-w-3xl space-y-4">
          {chapters.map((c, i) => (
            <li key={i} className="flex flex-col gap-2 rounded-[10px] border border-[#d8a9a9] bg-surface px-4 py-3 sm:flex-row sm:items-center sm:gap-4">
              <span className="text-xs font-bold text-gray-400">Chapter {i + 1}</span><span className="text-xs font-bold">Title</span>
              <input className="input flex-1 rounded-full" placeholder="Type here" value={c.title} onChange={(e) => setChapters(chapters.map((x, j) => (j === i ? { ...x, title: e.target.value } : x)))} />
              <input className="input flex-1 rounded-full" type="url" placeholder="Video URL (optional, e.g. YouTube)" value={c.videoUrl} onChange={(e) => setChapters(chapters.map((x, j) => (j === i ? { ...x, videoUrl: e.target.value } : x)))} />
              {chapters.length > 1 && <button type="button" onClick={() => setChapters(chapters.filter((_, j) => j !== i))} className="text-xs text-red-600" aria-label="Remove chapter">✕</button>}
            </li>))}
        </ul>
        <button type="button" onClick={() => setChapters([...chapters, { title: '', videoUrl: '' }])} className="mt-5 rounded-[10px] border border-red-400 px-4 py-3 text-xs font-bold text-red-600">+ Add Chapter</button>
        <div className="mt-6 flex flex-wrap items-center gap-4 sm:gap-8">
          {[['startDate', 'Start Date'], ['endDate', 'End Date']].map(([k, l]) => (
            <label key={k} className="relative flex items-center gap-2 rounded-[10px] border border-gray-400 bg-surface px-4 py-3 text-xs font-bold">{l}
              <input type="date" required value={form[k]} onChange={set(k)} className="bg-transparent text-xs outline-none" /><CalSmallIcon className="h-5 w-5 text-blue-700" />
            </label>))}
          <button disabled={busy} className="rounded-[10px] bg-brand px-8 py-4 text-xs font-bold text-white hover:opacity-90 disabled:opacity-60">{busy ? 'Publishing…' : 'Publish Course'}</button>
        </div>
        {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
      </form>
    </>
  )
}
