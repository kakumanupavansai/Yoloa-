import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApi } from '../../hooks'
import { quizzesApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'

// Figma: Desktop - 5
export default function Quizzes() {
  const state = useApi(() => quizzesApi.list(), [])
  const [q, setQ] = useState('')
  return (
    <>
      <Topbar title="Quizzes" onSearch={setQ} />
      <Async state={state}>{(list) => (
        <section className="mt-2 rounded-[10px] bg-white p-3 shadow-panel sm:p-6">
          <h2 className="px-2 text-xl font-bold sm:px-14">Practice Tests</h2>
          <ul className="mt-5 space-y-4 sm:space-y-6 sm:px-6">
            {list.filter((t) => `${t.title} ${t.subject}`.toLowerCase().includes(q.toLowerCase())).map((t) => (
              <li key={t.id} className="grid grid-cols-2 items-center gap-3 rounded-[10px] bg-surface-muted px-4 py-4 shadow-panel sm:px-10 sm:py-6 md:grid-cols-4">
                <div><p className="text-sm font-bold">{t.title}</p><p className="text-sm font-bold text-gray-500">{t.subject}</p></div>
                <Link to={`/student/quizzes/${t.id}`} className="pill w-fit">Preview</Link>
                <p className="text-sm font-bold text-gray-500">
                  {t.questions} Questions<br />{t.points} points
                  {t.attempts > 0 && <><br /><span className="text-green-700">Best: {t.bestScore}/{t.points} · {t.attempts} attempt{t.attempts > 1 ? 's' : ''}</span></>}
                </p>
                <Link to={`/student/quizzes/${t.id}?start=1`} className="ml-auto rounded-xl border-2 border-brand bg-white px-8 py-2 text-xs font-bold text-brand hover:bg-brand-soft">{t.attempts > 0 ? 'Retake' : 'Attempt'}</Link>
              </li>))}
          </ul>
        </section>)}
      </Async>
    </>
  )
}
