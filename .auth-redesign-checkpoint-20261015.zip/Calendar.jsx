import { useMemo, useState } from 'react'
import { useApi } from '../../hooks'
import { calendarApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'
import { MailIcon } from '../../components/ui/Icons'

const DOW = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
const MONTHS = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER']
const pad = (n) => String(n).padStart(2, '0')

// Figma: Desktop - 6
export default function CalendarPage() {
  const [cur, setCur] = useState({ year: 2023, month: 10 }) // month: 0-11
  const [view, setView] = useState('Monthly')
  const state = useApi(() => calendarApi.month(cur.year, cur.month + 1), [cur.year, cur.month])

  const cells = useMemo(() => {
    const first = (new Date(cur.year, cur.month, 1).getDay() + 6) % 7 // Monday-first
    const days = new Date(cur.year, cur.month + 1, 0).getDate()
    return [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)]
  }, [cur])
  const shift = (d) => setCur(({ year, month }) => { const x = new Date(year, month + d, 1); return { year: x.getFullYear(), month: x.getMonth() } })

  return (
    <>
      <Topbar title="Calender" />
      <Async state={state}>{(data) => {
        const ev = (day) => data.events.find((e) => e.date === `${cur.year}-${pad(cur.month + 1)}-${pad(day)}`)
        return (
          <div className="mt-2 flex flex-col gap-4 xl:flex-row">
            <section className="min-w-0 flex-1 rounded-[10px] bg-white p-3 shadow-panel sm:p-5">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2"><button onClick={() => shift(-1)} aria-label="Previous month" className="px-3 py-1 text-lg">‹</button>
                  <h2 className="text-lg font-bold sm:text-xl">{MONTHS[cur.month]} {cur.year}</h2><button onClick={() => shift(1)} aria-label="Next month" className="px-3 py-1 text-lg">›</button></div>
                <div className="flex w-full flex-wrap items-center gap-x-1 gap-y-1 text-sm font-bold sm:ml-auto sm:w-auto sm:gap-x-5">
                  {['Daily', 'Weekly', 'Monthly', 'Yearly'].map((v) => <button key={v} onClick={() => setView(v)} className={`rounded-lg px-2 py-1 sm:px-3 ${view === v ? 'bg-surface-line' : ''}`}>{v}</button>)}
                  <button>New schedule</button>
                </div>
              </div>
              <div className="mt-5 grid grid-cols-7 text-center text-xs font-bold sm:text-sm">{DOW.map((d) => <div key={d} className="pb-2"><span className="hidden sm:inline">{d}</span><span className="sm:hidden">{d[0]}</span></div>)}</div>
              <div className="grid grid-cols-7 border-l border-t border-gray-300">
                {cells.map((day, i) => {
                  const e = day && ev(day)
                  return (
                    <div key={i} className={`min-h-[64px] border-b border-r border-gray-300 p-1 text-xs font-bold sm:min-h-[96px] sm:p-2 sm:text-sm ${e?.type === 'deadline' ? 'bg-[#f7d9dc]' : e ? 'bg-brand-soft' : ''}`}>
                      {day}{e && <><span aria-hidden="true" className={`mt-1 block h-2 w-2 rounded-full sm:hidden ${e.type === 'deadline' ? 'bg-red-400' : 'bg-brand'}`} /><p className="mt-3 hidden text-xs font-normal sm:block">{e.title}</p></>}
                    </div>)
                })}
              </div>
              {data.events.length > 0 && (
                <ul aria-label="Events this month" className="mt-4 space-y-2 sm:hidden">
                  {data.events.map((e) => (
                    <li key={e.id} className="flex items-center gap-2 text-xs">
                      <span aria-hidden="true" className={`h-2.5 w-2.5 shrink-0 rounded-full ${e.type === 'deadline' ? 'bg-red-400' : 'bg-brand'}`} />
                      <span className="font-bold">{new Date(`${e.date}T00:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                      <span>{e.title}</span>
                    </li>))}
                </ul>)}
            </section>
            <aside className="card w-full rounded-[10px] p-5 xl:w-[220px]">
              <h2 className="text-xl font-bold">Schedules</h2>
              <p className="mt-2 text-sm">{data.daySchedule.date}</p>
              {data.daySchedule.items.map((s) => (
                <div key={s.time} className="mt-3"><p className="text-sm">{s.time}</p><p className="mt-1 rounded-lg bg-brand-soft px-3 py-3 text-sm">{s.title}</p></div>))}
              <button className="mt-6 flex w-full items-center gap-2 rounded-lg bg-brand-soft px-4 py-3 text-sm"><MailIcon className="h-5 w-5" />Check Inbox</button>
            </aside>
          </div>)
      }}</Async>
    </>
  )
}
