import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { useApi } from '../../hooks'
import { assessmentsApi, quizzesApi } from '../../services/api'
import { USE_MOCK } from '../../services/http'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'
import { fmtTime } from '../../utils'

const LETTERS = ['A', 'B', 'C', 'D', 'E', 'F']

// One assessment UI serves module quizzes and final exams. The server owns the attempt,
// answers, version, and deadline; this component only renders the current server state.
export default function QuizTake({ final = false }) {
  const { id } = useParams()
  const [params] = useSearchParams()
  const state = useApi(() => (final ? assessmentsApi.get(id) : quizzesApi.get(id)), [id, final])
  const [stage, setStage] = useState(params.get('start') ? 'taking' : 'intro')
  const [result, setResult] = useState(null)
  const [round, setRound] = useState(0)
  const [error, setError] = useState('')

  const start = () => { setError(''); setResult(null); setRound((value) => value + 1); setStage('taking') }
  const finish = (value) => { setResult(value); setStage('result'); state.reload() }

  return (
    <>
      <Topbar title={final ? 'Final Examination' : 'Quizzes'} />
      <Async state={state}>{(assessment) => (
        <section className="mt-2 rounded-[10px] bg-white p-3 shadow-panel sm:p-6">
          {stage === 'intro' && <Intro assessment={assessment} final={final} onStart={start} error={error} />}
          {stage === 'taking' && <Runner key={round} assessment={assessment} final={final} onDone={finish} onError={setError} />}
          {stage === 'result' && <Result assessment={assessment} result={result} onRetake={start} final={final} />}
        </section>
      )}</Async>
    </>
  )
}

function Intro({ assessment, final, onStart, error }) {
  const eligibility = assessment.eligibility || { eligible: true, reasons: [] }
  const blocked = final && !eligibility.eligible
  return (
    <div className="mx-auto max-w-xl py-6 text-center">
      <p className="text-sm font-bold text-gray-500">{assessment.subject}</p>
      <h2 className="mt-1 text-3xl font-bold">{assessment.title}</h2>
      {final && <p className="mt-2 text-sm font-bold text-brand">Final examination · exactly 10 minutes</p>}
      <dl className="mt-6 grid grid-cols-3 gap-4 text-sm">
        <div className="rounded-[10px] bg-surface-muted p-4"><dt className="text-gray-500">Questions</dt><dd className="text-xl font-bold">{assessment.questionCount}</dd></div>
        <div className="rounded-[10px] bg-surface-muted p-4"><dt className="text-gray-500">Points</dt><dd className="text-xl font-bold">{assessment.totalPoints}</dd></div>
        <div className="rounded-[10px] bg-surface-muted p-4"><dt className="text-gray-500">Time</dt><dd className="text-xl font-bold">{final ? '10 min' : assessment.durationMinutes ? `${assessment.durationMinutes} min` : 'Untimed'}</dd></div>
      </dl>
      {assessment.attempts > 0 && <p className="mt-4 text-sm font-bold text-green-700">Best: {assessment.bestScore}/{assessment.totalPoints} · {assessment.attempts} attempt{assessment.attempts > 1 ? 's' : ''}</p>}
      {blocked && <div className="mt-5 rounded-lg bg-amber-50 p-4 text-left text-sm text-amber-900"><p className="font-bold">Final exam locked</p><ul className="mt-2 list-disc pl-5">{eligibility.reasons.map((reason) => <li key={reason}>{reason}</li>)}</ul></div>}
      {error && <p className="mt-4 text-sm text-red-600">{error}</p>}
      <p className="mt-4 text-xs text-gray-500">{final ? 'Your attempt is saved on the server as you answer. Refreshing resumes the same attempt and does not reset the deadline.' : 'You can retake this quiz without losing earlier attempts.'}</p>
      <div className="mt-6 flex justify-center gap-4">
        <Link to={final ? '/student/courses' : '/student/quizzes'} className="btn-outline">Back</Link>
        <button disabled={blocked} onClick={onStart} className="btn-primary px-10 disabled:cursor-not-allowed disabled:opacity-50">{assessment.attempts > 0 ? 'Retake' : 'Start'} {final ? 'exam' : 'quiz'}</button>
      </div>
    </div>
  )
}

function Runner({ assessment, final, onDone, onError }) {
  const api = final ? assessmentsApi : quizzesApi
  const [attempt, setAttempt] = useState(null)
  const [answers, setAnswers] = useState({})
  const [i, setI] = useState(0)
  const [left, setLeft] = useState(null)
  const [busy, setBusy] = useState(false)
  const [saveState, setSaveState] = useState('saved')
  const [localError, setLocalError] = useState('')
  const sent = useRef(false)
  const answersRef = useRef(answers)
  const submitRef = useRef(() => {})
  const version = useRef(0)
  const saveChain = useRef(Promise.resolve())
  const pending = useRef(null)
  const qs = assessment.questions || []
  const q = qs[i]
  answersRef.current = answers

  useEffect(() => {
    let alive = true
    api.start(assessment.id).then((data) => {
      if (!alive) return
      setAttempt(data)
      setAnswers(data.answers || {})
      version.current = data.answerVersion || 0
      if (data.deadline) setLeft(Math.max(0, Math.ceil((new Date(data.deadline).getTime() - Date.now()) / 1000)))
    }).catch((error) => { if (alive) { setLocalError(error.message); onError(error.message) } })
    return () => { alive = false }
  }, [assessment.id]) // server resume is intentionally keyed only by assessment

  useEffect(() => {
    if (!attempt?.deadline) return undefined
    const tick = () => {
      const seconds = Math.max(0, Math.ceil((new Date(attempt.deadline).getTime() - Date.now()) / 1000))
      setLeft(seconds)
      if (seconds === 0) submitRef.current(true)
    }
    tick()
    const timer = setInterval(tick, 500)
    return () => clearInterval(timer)
  }, [attempt?.deadline])

  const persist = (next, nextVersion) => {
    if (USE_MOCK) { setSaveState('saved'); return Promise.resolve() }
    setSaveState('saving')
    return api.save(attempt.attemptId, next, nextVersion).then((data) => {
      version.current = data.answerVersion
      setAttempt((current) => ({ ...current, ...data }))
      setSaveState('saved')
    }).catch((error) => { setSaveState('error'); setLocalError(error.message); throw error })
  }

  const choose = (value) => {
    if (!q || sent.current) return
    const next = { ...answers, [q.id]: value }
    setAnswers(next)
    if (USE_MOCK) return
    setSaveState('saving')
    clearTimeout(pending.current)
    pending.current = setTimeout(() => {
      const currentVersion = version.current
      saveChain.current = saveChain.current.then(() => persist(next, currentVersion)).catch(() => {})
    }, 350)
  }

  const submit = async (automatic = false) => {
    if (sent.current || !attempt) return
    if (!automatic && Object.keys(answers).length < qs.length && !window.confirm(`You have ${qs.length - Object.keys(answers).length} unanswered question(s). Submit anyway?`)) return
    sent.current = true; setBusy(true); setLocalError('')
    try {
      if (!USE_MOCK) {
        clearTimeout(pending.current)
        await saveChain.current
        // Flush the latest edit even if its debounce window has not elapsed.
        await persist(answersRef.current, version.current)
      }
      const result = USE_MOCK && !final ? await quizzesApi.submit(assessment.id, answers) : await assessmentsApi.submit(attempt.attemptId)
      onDone(result)
    } catch (error) {
      sent.current = false; setBusy(false); setLocalError(error.message); onError(error.message)
    }
  }
  submitRef.current = submit

  if (localError && !attempt) return <p className="p-6 text-sm text-red-600">{localError}</p>
  if (!attempt || !q) return <p className="p-6 text-sm">Connecting to the server and restoring your attempt…</p>
  const answered = Object.keys(answers).length
  const multiple = q.questionType === 'multiple'
  const selected = answers[q.id]
  return (
    <div>
      <div className="flex flex-wrap items-center gap-4">
        <div><h2 className="text-xl font-bold">{assessment.title}</h2><p className="text-xs font-bold text-gray-500">{assessment.subject}</p></div>
        <span className="ml-auto text-sm font-bold">{answered}/{qs.length} answered</span>
        {left !== null && <span className={`rounded-lg px-4 py-2 text-sm font-bold tabular-nums ${left < 60 ? 'bg-red-100 text-red-700' : 'bg-brand-soft text-brand'}`} aria-live="off">⏱ {fmtTime(left)}</span>}
        <span className={`text-xs ${saveState === 'error' ? 'text-red-600' : saveState === 'saving' ? 'text-amber-700' : 'text-green-700'}`} aria-live="polite">{saveState === 'saving' ? 'Saving…' : saveState === 'error' ? 'Save error — retrying' : 'Saved'}</span>
      </div>
      <div className="mt-3 h-2 rounded-full bg-accent-lilac"><div className="h-full rounded-full bg-brand transition-all" style={{ width: `${((i + 1) / qs.length) * 100}%` }} /></div>
      <div className="mt-6 rounded-[10px] bg-surface-muted p-4 shadow-row sm:p-6">
        <p className="text-xs font-bold text-gray-500">Question {i + 1} of {qs.length} · {q.points} point{q.points > 1 ? 's' : ''}</p>
        <h3 className="mt-2 text-lg font-bold">{q.text}</h3>
        {q.questionType === 'short' ? <input aria-label={`Answer for question ${i + 1}`} className="input mt-5 w-full" value={selected || ''} onChange={(event) => choose(event.target.value)} /> : (
          <div role={multiple ? 'group' : 'radiogroup'} aria-label={`Choices for question ${i + 1}`} className="mt-5 grid gap-3 md:grid-cols-2">
            {(q.choices || ['True', 'False']).map((choice, k) => {
              const on = multiple ? Array.isArray(selected) && selected.includes(k) : selected === k
              return <button key={k} role={multiple ? 'checkbox' : 'radio'} aria-checked={on} onClick={() => choose(multiple ? (on ? selected.filter((value) => value !== k) : [...(selected || []), k]) : q.questionType === 'true_false' ? k === 0 : k)} className={`flex items-center gap-3 rounded-[10px] border-2 px-4 py-3 text-left transition ${on ? 'border-brand bg-brand-soft' : 'border-transparent bg-white hover:border-brand/40'}`}><span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${on ? 'bg-brand text-white' : 'bg-surface-gray'}`}>{q.questionType === 'true_false' ? (k === 0 ? 'T' : 'F') : LETTERS[k]}</span><span className="text-sm">{choice}</span></button>
            })}
          </div>
        )}
      </div>
      <div className="mt-4 flex flex-wrap gap-2" aria-label="Question navigator">{qs.map((item, n) => <button key={item.id} onClick={() => setI(n)} aria-label={`Go to question ${n + 1}${answers[item.id] !== undefined ? ' (answered)' : ''}`} className={`h-8 w-8 rounded-full text-xs font-bold ${n === i ? 'ring-2 ring-brand ring-offset-2' : ''} ${answers[item.id] !== undefined ? 'bg-brand text-white' : 'bg-surface-gray'}`}>{n + 1}</button>)}</div>
      {localError && <p className="mt-3 text-sm text-red-600">{localError} <button onClick={() => persist(answers, version.current)} className="font-bold underline">Retry save</button></p>}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3"><button disabled={i === 0} onClick={() => setI(i - 1)} className="btn-outline disabled:opacity-40">← Previous</button><div className="flex flex-wrap gap-3">{i < qs.length - 1 && <button onClick={() => setI(i + 1)} className="btn-outline">Next →</button>}<button disabled={busy} onClick={() => submit(false)} className="btn-primary px-8">{busy ? 'Submitting…' : final ? 'Submit exam' : 'Submit quiz'}</button></div></div>
    </div>
  )
}

function Result({ assessment, result, onRetake, final }) {
  const nav = useNavigate()
  const pass = result?.passed ?? result?.percent >= 60
  return <div><div className="mx-auto max-w-md rounded-[20px] bg-surface-muted p-8 text-center shadow-panel"><p className="text-sm font-bold text-gray-500">{assessment.title} · {assessment.subject}</p><p className={`mt-2 text-5xl font-bold ${pass ? 'text-green-600' : 'text-accent-orange'}`}>{result.score}<span className="text-2xl text-gray-400">/{result.total}</span></p><p className="mt-1 text-sm font-bold">{result.percent}% · {pass ? (final ? 'Course completed!' : 'Well done!') : 'Keep practising!'}</p><p className="mt-1 text-xs text-gray-500">Best: {result.bestScore ?? result.score}/{result.total} · Attempts: {result.attempts ?? '—'}</p><div className="mt-5 flex justify-center gap-3"><button onClick={() => nav(final ? '/student/courses' : '/student/quizzes')} className="btn-outline">{final ? 'Back to courses' : 'All quizzes'}</button><button onClick={onRetake} className="btn-primary">Retake</button></div></div><h3 className="mt-8 text-xl font-bold">Review your answers</h3><ol className="mt-3 space-y-4">{(result.review || []).map((item, n) => <ReviewItem key={item.id} item={item} number={n + 1} />)}</ol></div>
}

function ReviewItem({ item, number }) {
  const choices = item.choices || []
  const correct = Array.isArray(item.correctAnswers) ? item.correctAnswers : [item.correct]
  const chosen = Array.isArray(item.chosen) ? item.chosen : [item.chosen]
  return <li className={`rounded-[10px] border-l-4 bg-surface-muted p-4 ${item.isCorrect ? 'border-green-600' : 'border-red-500'}`}><p className="text-sm font-bold">{number}. {item.text} <span className={`ml-2 text-xs ${item.isCorrect ? 'text-green-700' : 'text-red-600'}`}>{item.isCorrect ? `+${item.points}` : item.chosen == null ? 'Skipped' : 'Incorrect'}</span></p>{item.questionType === 'short' ? <p className="mt-2 text-sm">Answer: {item.chosen || 'Skipped'} {item.expectedAnswer && <span className="font-bold text-green-700"> · Expected: {item.expectedAnswer}</span>}</p> : <ul className="mt-2 grid gap-2 md:grid-cols-2">{choices.map((choice, k) => <li key={k} className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm ${correct.includes(k) ? 'bg-pastel-green' : chosen.includes(k) ? 'bg-pastel-pink' : 'bg-white'}`}><span className="font-bold">{LETTERS[k]}.</span><span className="flex-1">{choice}</span>{correct.includes(k) && <span className="text-xs font-bold text-green-800">Correct</span>}{chosen.includes(k) && !correct.includes(k) && <span className="text-xs font-bold text-red-700">Your answer</span>}</li>)}</ul>}</li>
}
