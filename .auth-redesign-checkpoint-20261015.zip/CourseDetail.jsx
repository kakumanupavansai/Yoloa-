import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useApi } from '../../hooks'
import { coursesApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import CoverImage from '../../components/ui/CoverImage'
import Avatar from '../../components/ui/Avatar'
import ProgressBar from '../../components/ui/ProgressBar'
import { Async } from '../../components/ui/States'

const colors = { green: 'bg-pastel-green', pink: 'bg-pastel-pink', blue: 'bg-pastel-blue', yellow: 'bg-pastel-yellow' }
const statusColor = { Completed: 'text-green-600', 'In progress': 'text-blue-600' }

// Figma: Desktop - 4 (student) / Desktop - 20 (admin)
export default function CourseDetail({ admin = false }) {
  const { id } = useParams()
  const state = useApi(() => coursesApi.get(id), [id])
  const nav = useNavigate()
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const removeCourse = async (c) => {
    if (!window.confirm(`Delete course "${c.adminTitle || c.title}"? Chapters, lesson content and student progress will be removed. This cannot be undone.`)) return
    setBusy(true); setError('')
    try { await coursesApi.remove(id); nav('/admin/courses', { replace: true }) } catch (e) { setError(e.message); setBusy(false) }
  }
  const enroll = async () => {
    setBusy(true); setError('')
    try { await coursesApi.enroll(id); await state.reload() } catch (e) { setError(e.message) } finally { setBusy(false) }
  }
  return (
    <>
      <Topbar title="Course" />
      <Async state={state}>{(c) => (
        <div className="mt-2 flex flex-col gap-5 xl:flex-row">
          <div className="min-w-0 flex-1 space-y-4">
            <section className="rounded-[10px] bg-white p-5 shadow-panel">
              <div className="flex flex-col gap-5 sm:flex-row">
                <CoverImage src={c.cover} title="" className="h-60 w-full shrink-0 sm:w-80" />
                <div>
                  <h2 className="text-xl font-bold">{admin ? c.adminTitle : c.title}</h2>
                  <p className="mt-4 text-sm leading-6">{c.description}</p>
                  {admin && c.professor && (
                    <div className="mt-4 flex items-center gap-3"><Avatar src={c.professor.avatar} name={c.professor.name} size={48} />
                      <div><p className="text-sm font-bold">{c.professor.name}</p><p className="text-xs font-bold text-gray-500">{c.professor.title}</p></div></div>)}
                </div>
              </div>
              <h3 className="mt-6 text-xl font-bold">Content</h3>
              <ul className="mt-3 space-y-4 scroll-thin sm:max-h-[340px] sm:overflow-y-auto sm:pr-2">
                {c.content.map((it) => (
                  <li key={it.id} className="flex flex-col gap-3 rounded-[10px] bg-surface-muted p-3 shadow-row sm:flex-row sm:items-center sm:gap-5">
                    <div className={`flex h-16 w-full shrink-0 items-center justify-center sm:h-20 sm:w-36 rounded-[10px] px-2 text-center text-sm font-bold shadow-row ${colors[it.color] || colors.blue}`}>{it.title}</div>
                    <p className="flex-1 text-xs">{it.text}</p>
                    <a href={it.fileUrl} download className="btn-primary text-xs">Download</a>
                  </li>))}
              </ul>
            </section>
            {admin && (
              <section className="rounded-[10px] bg-white p-5 shadow-panel">
                <h3 className="text-xl font-bold">Published Exams</h3>
                {c.publishedExams.map((e) => (
                  <div key={e.id} className="mt-3 flex flex-wrap items-center gap-x-8 gap-y-2 p-2">
                    <span className="h-4 w-4 rounded-full bg-green-600" />
                    <div><p className="text-xl font-bold">{e.title}</p><p className="text-sm font-bold text-gray-500">{e.subject}</p></div>
                    <span className="ml-auto text-xs font-bold text-green-700">● {e.status}</span>
                    <Link to="/admin/exams" className="rounded-lg border border-[#c9a9a9] px-5 py-1 text-xs font-bold">Edit</Link>
                  </div>))}
              </section>)}
            {!admin && c.assessment && (
              <section className="rounded-[10px] bg-white p-5 shadow-panel">
                <h3 className="text-xl font-bold">Assessments</h3>
                <div className="mt-3 space-y-3">
                  {(c.assessment.moduleQuizzes || []).map((quiz) => (
                    <div key={quiz.id} className="flex flex-wrap items-center gap-3 rounded-lg bg-surface-muted p-3">
                      <div className="min-w-0 flex-1"><p className="text-sm font-bold">{quiz.moduleTitle} quiz</p><p className="text-xs text-gray-500">{quiz.required ? 'Required module' : 'Optional module'} · {quiz.attempts} attempt{quiz.attempts === 1 ? '' : 's'}</p></div>
                      <span className={`text-xs font-bold ${quiz.passed ? 'text-green-700' : 'text-gray-500'}`}>{quiz.passed ? 'Passed' : quiz.latestPercent == null ? 'Not attempted' : `${quiz.latestPercent}% latest`}</span>
                      <Link to={`/student/quizzes/${quiz.id}`} className="btn-outline text-xs">Open quiz</Link>
                    </div>
                  ))}
                  {c.assessment.finalExam && (
                    <div className="flex flex-wrap items-center gap-3 rounded-lg border-2 border-brand/30 bg-brand-soft p-3">
                      <div className="min-w-0 flex-1"><p className="text-sm font-bold">{c.assessment.finalExam.title}</p><p className="text-xs text-gray-600">10 minutes · pass mark 60%</p></div>
                      <span className={`text-xs font-bold ${c.assessment.finalExam.passed ? 'text-green-700' : c.assessment.finalExam.eligible ? 'text-brand' : 'text-amber-700'}`}>{c.assessment.finalExam.passed ? 'Completed' : c.assessment.finalExam.eligible ? 'Eligible' : 'Locked'}</span>
                      <Link to={`/student/exams/${c.assessment.finalExam.id}`} className={`btn-primary text-xs ${!c.assessment.finalExam.eligible ? 'pointer-events-none opacity-50' : ''}`}>Open final exam</Link>
                    </div>
                  )}
                  {!c.assessment.moduleQuizzes?.length && !c.assessment.finalExam && <p className="text-sm text-gray-500">No assessments have been published for this course yet.</p>}
                </div>
              </section>
            )}
          </div>
          <aside className="card h-fit w-full p-5 xl:w-[280px]">
            <div className="flex items-baseline justify-between"><h2 className="text-xl font-bold">Course Progress</h2>{admin && <button className="text-xs">See all</button>}</div>
            <ul className="mt-4 space-y-4">
              {c.progress.map((p) => (
                <li key={p.id} className="flex items-center justify-between rounded-[10px] bg-surface-gray px-4 py-3">
                  <div><p className="text-sm font-bold">{p.title}</p><p className="text-sm font-bold text-gray-500">{p.chapter}</p></div>
                  <span className={`text-xs font-bold ${statusColor[p.status]}`}>{p.status}</span>
                </li>))}
            </ul>
            {!admin && (
              <div className="mt-6 border-t border-black/10 pt-4">
                {c.enrolled ? (
                  <>
                    <div className="flex items-center gap-2 text-sm font-bold"><ProgressBar percent={c.percent} className="w-full" />{c.percent}%</div>
                    <ul className="mt-3 max-h-48 space-y-1 overflow-y-auto scroll-thin text-xs">
                      {(c.chapters || []).map((ch) => (
                        <li key={ch.id} className="flex items-center gap-2"><span className={`flex h-4 w-4 items-center justify-center rounded-full border text-[10px] ${ch.completed ? 'border-green-600 bg-green-600 text-white' : 'border-gray-400'}`}>{ch.completed && '✓'}</span>{ch.title}</li>))}
                    </ul>
                    <Link to={`/student/courses/${id}/watch`} className="btn-blue mt-4 w-full">{c.percent === 100 ? 'Review lessons' : c.percent > 0 ? 'Continue learning' : 'Start learning'}</Link>
                  </>
                ) : (
                  <>
                    <p className="text-sm text-ink-soft">Enroll to unlock the lessons and track your progress.</p>
                    <button disabled={busy} onClick={enroll} className="btn-blue mt-3 w-full">{busy ? 'Enrolling…' : 'Enroll in this course'}</button>
                    {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
                  </>
                )}
              </div>)}
            {admin && (
              <div className="mt-6 border-t border-black/10 pt-4">
                <button disabled={busy} onClick={() => removeCourse(c)} className="w-full rounded-lg border-2 border-red-500 py-2 text-sm font-bold text-red-600 hover:bg-red-50 disabled:opacity-50">{busy ? 'Deleting…' : 'Delete course'}</button>
                {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
              </div>)}
          </aside>
        </div>)}
      </Async>
    </>
  )
}
