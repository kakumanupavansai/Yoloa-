import { useState } from 'react'
import { useApi } from '../../hooks'
import { coursesApi, examsApi, adminApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'

export default function QuestionImport() {
  const courses = useApi(() => coursesApi.list(), [])
  const exams = useApi(() => examsApi.list(), [])
  const [examId, setExamId] = useState('')
  const [file, setFile] = useState(null)
  const [batch, setBatch] = useState(null)
  const [sheets, setSheets] = useState([])
  const [sheet, setSheet] = useState('')
  const [headers, setHeaders] = useState([])
  const [mapping, setMapping] = useState({ questionType: '', questionText: '', options: '', correctAnswer: '', marks: '' })
  const [preview, setPreview] = useState(null)
  const [message, setMessage] = useState('')
  const upload = async (event) => { event.preventDefault(); setMessage(''); const body = new FormData(); body.append('file', file); body.append('examId', examId); try { const value = await adminApi.uploadQuestions(body); setBatch(value.batchId); setSheets(value.sheets || []); setSheet(value.sheets[0]?.name || ''); setHeaders(value.sheets[0]?.headers || []); setMessage('Workbook uploaded. Map its columns and preview the rows.') } catch (error) { setMessage(error.message) } }
  const selectSheet = (name) => { const selected = sheets.find((item) => item.name === name); setSheet(name); setHeaders(selected?.headers || []); setPreview(null) }
  const runPreview = async () => { try { const value = await adminApi.previewQuestions(batch, { sheet, mapping }); setPreview(value); setMessage(`${value.validCount} valid rows, ${value.invalidCount} rejected rows.`) } catch (error) { setMessage(error.message) } }
  const confirm = async () => { try { const value = await adminApi.confirmQuestions(batch, crypto.randomUUID()); setMessage(`Imported ${value.imported} questions safely.`) } catch (error) { setMessage(error.message) } }
  return <><Topbar title="Question import" /><Async state={courses}>{() => <Async state={exams}>{(examRows) => <section className="card mt-2 p-5"><h2 className="text-xl font-bold">Excel question import</h2><p className="mt-1 text-sm text-gray-600">Upload a safe .xlsx workbook, map arbitrary headers, preview validation, then explicitly confirm.</p><form onSubmit={upload} className="mt-5 grid gap-3 sm:grid-cols-2"><label className="text-sm font-bold">Target assessment<select className="input mt-1 w-full" value={examId} onChange={(e) => setExamId(e.target.value)} required><option value="">Select an assessment</option>{examRows.map((exam) => <option key={exam.id} value={exam.id}>{exam.title} · {exam.assessmentTypeLabel || exam.status}</option>)}</select></label><label className="text-sm font-bold">Workbook<input className="input mt-1 w-full" type="file" accept=".xlsx" onChange={(e) => setFile(e.target.files[0])} required /></label><button className="btn-primary w-fit" type="submit">Upload workbook</button></form>{batch && <div className="mt-6 border-t pt-5"><label className="text-sm font-bold">Worksheet<select className="input mt-1 w-full" value={sheet} onChange={(e) => selectSheet(e.target.value)}>{sheets.map((item) => <option key={item.name} value={item.name}>{item.name}</option>)}</select></label><div className="mt-4 grid gap-3 sm:grid-cols-2">{Object.keys(mapping).map((field) => <label key={field} className="text-xs font-bold">{field}<select className="input mt-1 w-full" value={mapping[field]} onChange={(e) => setMapping({ ...mapping, [field]: e.target.value })}><option value="">Not mapped</option>{headers.map((header) => <option key={header} value={header}>{header}</option>)}</select></label>)}</div><button className="btn-outline mt-4" onClick={runPreview}>Validate and preview</button>{preview && <div className="mt-4 rounded-lg bg-surface-muted p-4"><p className="text-sm font-bold">{preview.validCount} valid · {preview.invalidCount} rejected</p>{preview.errors.length > 0 && <ul className="mt-2 list-disc pl-5 text-sm text-red-600">{preview.errors.map((item) => <li key={`${item.row}-${item.message}`}>Row {item.row}: {item.message}</li>)}</ul>}<button disabled={preview.invalidCount > 0 || preview.validCount === 0} className="btn-primary mt-4 disabled:opacity-50" onClick={confirm}>Confirm import</button></div>}</div>}{message && <p className="mt-4 text-sm text-gray-700">{message}</p>}</section>}</Async>}</Async></>}
