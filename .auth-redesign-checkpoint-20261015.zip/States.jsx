export const Loading = ({ label = 'Loading…' }) => <div className="p-6 text-sm text-ink-soft">{label}</div>
export const ErrorBox = ({ error, onRetry }) => (
  <div className="m-4 rounded-lg bg-red-50 p-4 text-sm text-red-700">
    {error?.message || 'Something went wrong.'}
    {onRetry && <button onClick={onRetry} className="ml-3 font-bold underline">Retry</button>}
  </div>
)
// Wraps a useApi() result: renders loading/error or children(data)
export function Async({ state, children }) {
  if (state.loading && !state.data) return <Loading />
  if (state.error) return <ErrorBox error={state.error} onRetry={state.reload} />
  return children(state.data)
}
