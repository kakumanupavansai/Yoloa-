// Thin fetch wrapper. All backend calls go through here:
//  - base URL from VITE_API_URL
//  - attaches JWT from localStorage
//  - throws ApiError on non-2xx
const BASE = import.meta.env.VITE_API_URL || '/api'
export const USE_MOCK = String(import.meta.env.VITE_USE_MOCK) === 'true'
const TOKEN_KEY = 'yoloa_token'

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
}

export class ApiError extends Error {
  constructor(message, status, data) { super(message); this.status = status; this.data = data }
}

export async function http(path, { method = 'GET', body, headers = {}, isForm = false } = {}) {
  const token = tokenStore.get()
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      ...(isForm || body === undefined ? {} : { 'Content-Type': 'application/json' }),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
  })
  const data = res.status === 204 ? null : await res.json().catch(() => null)
  if (!res.ok) {
    if (res.status === 401) { tokenStore.clear(); window.dispatchEvent(new Event('auth:logout')) }
    throw new ApiError(data?.message || res.statusText, res.status, data)
  }
  return data
}

export const get = (p) => http(p)
export const post = (p, body) => http(p, { method: 'POST', body })
export const put = (p, body) => http(p, { method: 'PUT', body })
export const del = (p) => http(p, { method: 'DELETE' })

// Returns mock data (small delay) when VITE_USE_MOCK=true, else performs the real call.
export const withMock = (mockValue, realFn) =>
  USE_MOCK ? new Promise((r) => setTimeout(() => r(structuredClone(mockValue)), 150)) : realFn()

// Lazy version for stateful mocks: `fn` runs at call time and may throw an ApiError.
export const withMockFn = (fn, realFn) =>
  USE_MOCK
    ? new Promise((resolve, reject) => setTimeout(() => { try { resolve(structuredClone(fn())) } catch (e) { reject(e) } }, 150))
    : realFn()
