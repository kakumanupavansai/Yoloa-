import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApi } from '../../hooks'
import { examsApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'
import { TrashIcon } from '../../components/ui/Icons'

// Figma: Desktop - 21  (+ delete one / delete all)
export default function Exams() {
  const state = useApi(() => examsApi.list(), [])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const run = async (fn) => {
    setBusy(true); setError('')
    try { await fn(); await state.reload() } catch (e) { setError(e.message) } finally { setBusy(false) }
  }
  const toggle = (e) => run(() => examsApi.update(e.id, { status: e.status === 'Published' ? 'draft' : 'published' }))
  const removeOne = (e) => {
    if (window.confirm(`Delete "${e.title} – ${e.subject || 'untitled'}"? Its questions will be deleted too.`)) run(() => examsApi.remove(e.id))
  }
  const removeAll = (exams) => {
    if (window.confirm(`Delete ALL ${exams.length} exams and their questions? This cannot be undone.`)) run(() => Promise.all(exams.map((e) => examsApi.remove(e.id))))
  }

  return (
    <>
      <Topbar title="Exams" />
      <Async state={state}>{(exams) => (
        <section className="mt-2 rounded-[10px] bg-white p-3 shadow-panel sm:p-6">
          <div className="flex flex-wrap items-center gap-4 px-2 sm:px-6">
            <h2 className="text-xl font-bold">Final Exams</h2>
            <span className="pill ml-auto px-8">1st Term</span>
            {exams.length > 0 && <button disabled={busy} onClick={() => removeAll(exams)} className="rounded-xl border-2 border-red-500 bg-white px-6 py-1 text-xs font-bold text-red-600 hover:bg-red-50 disabled:opacity-50">Delete all</button>}
            <Link to="/admin/exams/new" className="rounded-xl border-2 border-brand bg-white px-6 py-1 text-xs font-bold text-brand">+ create new Exam</Link>
          </div>
          {error && <p className="mt-3 px-6 text-sm text-red-600">{error}</p>}
          <ul className="mt-5 space-y-4 sm:space-y-6 sm:px-4">
            {exams.map((e) => (
              <li key={e.id} className="grid grid-cols-2 items-center gap-3 rounded-[10px] bg-surface-muted px-4 py-4 shadow-panel sm:px-10 sm:py-6 md:grid-cols-5">
                <div><p className="text-sm font-bold">{e.title}</p><p className="text-sm font-bold text-gray-500">{e.subject}</p></div>
                <span className="pill w-fit px-8">{e.term}</span>
                <p className="text-sm font-bold text-gray-500">{e.questions} Questions<br />{e.points} points</p>
                <div>
                  <p className={`text-sm font-bold ${e.status === 'Published' ? 'text-green-600' : 'text-gray-500'}`}>{e.status === 'Published' && '● '}{e.status}</p>
                  {e.status === 'Published' && <p className="text-[11px] text-gray-500">Live in student Quizzes</p>}
                  <button disabled={busy} onClick={() => toggle(e)} aria-label={`${e.status === 'Published' ? 'Unpublish' : 'Publish'} ${e.title} ${e.subject}`}
                    className="mt-1 text-xs font-bold text-brand underline disabled:opacity-50">{e.status === 'Published' ? 'Unpublish' : 'Publish'}</button>
                </div>
                <button disabled={busy} onClick={() => removeOne(e)} aria-label={`Delete ${e.title} ${e.subject}`} className="ml-auto text-red-600 hover:text-red-800 disabled:opacity-50"><TrashIcon className="h-6 w-6" /></button>
              </li>))}
            {!exams.length && <li className="p-6 text-center text-sm text-gray-500">No exams yet. Click “+ create new Exam”.</li>}
          </ul>
        </section>)}
      </Async>
    </>
  )
}
