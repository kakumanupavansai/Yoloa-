from datetime import timedelta
from io import BytesIO

from django.core.files.uploadedfile import SimpleUploadedFile
from django.utils import timezone
from openpyxl import Workbook
from rest_framework.test import APITestCase

from lms import models as m
from lms.views import finalize_expired_attempts


class AssessmentApiTests(APITestCase):
    """End-to-end tests for the security-sensitive assessment workflow."""

    def setUp(self):
        self.admin = m.User.objects.create_user('admin', password='admin123', role='admin', is_staff=True)
        self.student = m.User.objects.create_user('student', password='student123', role='student', first_name='Ada', last_name='Lovelace')
        self.other = m.User.objects.create_user('other', password='student123', role='student')
        self.course = m.Course.objects.create(title='Secure learning')
        self.module = m.Chapter.objects.create(course=self.course, title='Required module', required=True)
        m.Chapter.objects.create(course=self.course, title='Optional module', required=False)
        m.Enrollment.objects.create(student=self.student, course=self.course)
        m.Enrollment.objects.create(student=self.other, course=self.course)

        self.module_exam = m.Exam.objects.create(
            title='Module quiz', course=self.course, module=self.module, assessment_type='module_quiz', status='published')
        self.single = m.Question.objects.create(
            exam=self.module_exam, text='One?', question_type='single', choices=['A', 'B'], correct=0,
            correct_answers=[0], points=2, order=0)
        self.multiple = m.Question.objects.create(
            exam=self.module_exam, text='Many?', question_type='multiple', choices=['A', 'B', 'C'],
            correct_answers=[0, 2], points=3, order=1)
        self.boolean = m.Question.objects.create(
            exam=self.module_exam, text='True?', question_type='true_false', choices=['True', 'False'],
            correct_answers=[True], points=1, order=2)
        self.short = m.Question.objects.create(
            exam=self.module_exam, text='Framework?', question_type='short', expected_answer='Django',
            accepted_answers=['Django framework'], normalization={'caseInsensitive': True}, points=4, order=3)

        self.final_exam = m.Exam.objects.create(
            title='Final', course=self.course, assessment_type='final_exam', status='published',
            duration='10 mins', duration_seconds=600)
        self.final_question = m.Question.objects.create(
            exam=self.final_exam, text='Final?', question_type='single', choices=['Yes', 'No'], correct=0,
            correct_answers=[0], points=5)

    def login(self, username='student', password='student123', role='student'):
        response = self.client.post('/api/auth/login', {'username': username, 'password': password, 'role': role}, format='json')
        self.assertEqual(response.status_code, 200, response.data)
        self.client.credentials(HTTP_AUTHORIZATION='Bearer ' + response.data['token'])
        return response.data

    def start(self, exam):
        return self.client.post(f'/api/assessments/{exam.id}/start', {}, format='json')

    def save(self, attempt, answers, version=None):
        return self.client.put(f'/api/attempts/{attempt["attemptId"]}/answers', {
            'answers': answers, 'version': attempt['answerVersion'] if version is None else version}, format='json')

    def submit(self, attempt):
        return self.client.post(f'/api/attempts/{attempt["attemptId"]}/submit', {}, format='json')

    def pass_module(self):
        started = self.start(self.module_exam)
        self.assertEqual(started.status_code, 201, started.data)
        saved = self.save(started.data, {
            str(self.single.id): 0,
            str(self.multiple.id): [0, 2],
            str(self.boolean.id): True,
            str(self.short.id): ' django framework ',
        })
        self.assertEqual(saved.status_code, 200, saved.data)
        return self.submit({**started.data, **saved.data})

    def test_login_and_refresh_events_are_distinct(self):
        tokens = self.login()
        self.assertEqual(m.LoginEvent.objects.filter(user=self.student, event_type='login').count(), 1)
        response = self.client.post('/api/auth/refresh', {'refresh': tokens['refresh']}, format='json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(m.LoginEvent.objects.filter(user=self.student, event_type='login').count(), 1)
        self.assertEqual(m.LoginEvent.objects.filter(user=self.student, event_type='refresh').count(), 1)
        self.client.credentials()
        bad = self.client.post('/api/auth/login', {'username': 'student', 'password': 'wrong', 'role': 'student'}, format='json')
        self.assertEqual(bad.status_code, 401)
        self.assertEqual(m.LoginEvent.objects.filter(user=self.student, event_type='login').count(), 1)

    def test_module_types_grade_and_unlock_final(self):
        self.login()
        self.assertEqual(self.start(self.final_exam).status_code, 403)
        result = self.pass_module()
        self.assertEqual(result.status_code, 200, result.data)
        self.assertEqual((result.data['score'], result.data['total'], result.data['percent']), (10.0, 10.0, 100.0))
        self.assertTrue(result.data['passed'])
        public = self.client.get(f'/api/assessments/{self.module_exam.id}')
        self.assertNotIn('correctAnswers', public.data['questions'][0])
        final = self.start(self.final_exam)
        self.assertEqual(final.status_code, 201, final.data)
        self.assertEqual((final.data['deadline'] - final.data['startedAt']).total_seconds(), 600)

    def test_resume_autosave_expiry_and_completion_are_server_controlled(self):
        self.login()
        self.assertTrue(self.pass_module().data['passed'])
        started = self.start(self.final_exam)
        resumed = self.start(self.final_exam)
        self.assertEqual((resumed.status_code, resumed.data['attemptId']), (200, started.data['attemptId']))

        saved = self.save(started.data, {str(self.final_question.id): 0})
        self.assertEqual(saved.status_code, 200)
        stale = self.save({**started.data, **saved.data}, {str(self.final_question.id): 1}, version=0)
        self.assertEqual(stale.status_code, 409)
        final = self.submit({**started.data, **saved.data})
        self.assertEqual(final.data['status'], 'submitted')
        enrollment = m.Enrollment.objects.get(student=self.student, course=self.course)
        self.assertEqual((enrollment.status, enrollment.completion_source), ('completed', 'final_exam'))

        retake = self.start(self.final_exam)
        bad_save = self.save(retake.data, {str(self.final_question.id): 1})
        self.assertFalse(self.submit({**retake.data, **bad_save.data}).data['passed'])
        enrollment.refresh_from_db()
        self.assertEqual(enrollment.status, 'completed')

        expired = self.start(self.final_exam)
        m.Attempt.objects.filter(pk=expired.data['attemptId']).update(deadline_at=timezone.now() - timedelta(seconds=1))
        finalize_expired_attempts()
        self.assertEqual(m.Attempt.objects.get(pk=expired.data['attemptId']).status, 'expired')
        self.assertEqual(self.save(expired.data, {str(self.final_question.id): 0}).status_code, 409)

    def test_permissions_manual_review_directory_and_analytics(self):
        self.login()
        started = self.start(self.module_exam)
        saved = self.save(started.data, {str(self.short.id): 'wrong'})
        failed = self.submit({**started.data, **saved.data})
        self.assertFalse(failed.data['passed'])

        self.login('other')
        self.assertEqual(self.client.get('/api/admin/students').status_code, 403)
        self.assertEqual(self.client.get(f'/api/attempts/{failed.data["attemptId"]}').status_code, 403)

        self.login('admin', 'admin123', 'admin')
        review = self.client.post(
            f'/api/admin/attempts/{failed.data["attemptId"]}/review',
            {'revisedScore': 10, 'reason': 'Verified written response'}, format='json')
        self.assertEqual(review.status_code, 200, review.data)
        self.assertEqual(m.GradingReview.objects.filter(attempt_id=failed.data['attemptId']).count(), 1)
        directory = self.client.get('/api/admin/students?q=Ada')
        self.assertEqual(directory.data['total'], 1)
        self.assertNotIn('password', directory.data['results'][0])
        self.assertEqual(self.client.get('/api/admin/analytics/exams').data['finalExamDurationSeconds'], 600)

        self.login()
        self.assertEqual(self.start(self.final_exam).status_code, 201)

    def test_excel_preview_and_idempotent_confirmation(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = 'Questions'
        sheet.append(['Type', 'Question', 'Options', 'Answer', 'Marks'])
        sheet.append(['single', 'Choose A', 'A|B', 'A', 2])
        stream = BytesIO()
        workbook.save(stream)

        self.login('admin', 'admin123', 'admin')
        upload = SimpleUploadedFile(
            'questions.xlsx', stream.getvalue(),
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response = self.client.post('/api/admin/question-imports/upload', {
            'file': upload, 'examId': self.module_exam.id, 'courseId': self.course.id}, format='multipart')
        self.assertEqual(response.status_code, 201, response.data)
        batch = response.data['batchId']
        preview = self.client.post(f'/api/admin/question-imports/{batch}/preview', {
            'sheet': 'Questions',
            'mapping': {'questionType': 'Type', 'questionText': 'Question', 'options': 'Options',
                        'correctAnswer': 'Answer', 'marks': 'Marks'},
        }, format='json')
        self.assertEqual((preview.status_code, preview.data['validCount'], preview.data['invalidCount']), (200, 1, 0))
        confirmation = self.client.post(
            f'/api/admin/question-imports/{batch}/confirm', {'idempotencyKey': 'retry-safe-key'}, format='json')
        self.assertEqual((confirmation.status_code, confirmation.data['imported']), (201, 1))
        retry = self.client.post(
            f'/api/admin/question-imports/{batch}/confirm', {'idempotencyKey': 'retry-safe-key'}, format='json')
        self.assertTrue(retry.data['alreadyImported'])
