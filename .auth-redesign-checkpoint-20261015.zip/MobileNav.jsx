import { useEffect, useRef, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import Avatar from '../ui/Avatar'
import Logo from '../ui/Logo'
import { MenuLinesIcon, CloseIcon } from '../ui/Icons'
import { NavLinks } from './Sidebar'

// Sticky top bar (hamburger · logo · avatar) + slide-in menu. Visible below 1024px only.
export default function MobileNav() {
  const { user } = useAuth()
  const { pathname } = useLocation()
  const [open, setOpen] = useState(false)
  const menuBtn = useRef(null)
  const closeBtn = useRef(null)

  useEffect(() => { setOpen(false) }, [pathname])            // close after navigating

  useEffect(() => {
    if (!open) return undefined
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('keydown', onKey)
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'                   // don't scroll the page behind the menu
    closeBtn.current?.focus()
    const opener = menuBtn.current
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prevOverflow; opener?.focus() }
  }, [open])

  return (
    <>
      <header className="sticky top-0 z-30 flex items-center gap-3 bg-surface px-3 pb-2 shadow-sm lg:hidden"
        style={{ paddingTop: 'max(0.875rem, env(safe-area-inset-top))' }}>
        <button ref={menuBtn} onClick={() => setOpen(true)} aria-label="Open menu" aria-haspopup="dialog" aria-expanded={open}
          className="flex h-11 w-11 items-center justify-center rounded-lg text-brand hover:bg-brand-soft"><MenuLinesIcon className="h-7 w-7" /></button>
        <Logo className="text-[11px]" />
        {user && <Link to={user.role === 'admin' ? '/admin/profile' : '/student/profile'} aria-label="My profile" className="ml-auto"><Avatar src={user.avatar} name={user.name} size={40} /></Link>}
      </header>

      {open && (
        <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Main menu">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} aria-hidden="true" />
          <div className="absolute inset-y-0 left-0 flex w-72 max-w-[85vw] flex-col overflow-y-auto bg-surface py-4 shadow-panel"
            style={{ paddingTop: 'max(1rem, env(safe-area-inset-top))' }}>
            <div className="flex items-center justify-between px-6">
              <Logo className="mt-2 text-[13px]" />
              <button ref={closeBtn} onClick={() => setOpen(false)} aria-label="Close menu" className="flex h-11 w-11 items-center justify-center rounded-lg hover:bg-surface-gray"><CloseIcon className="h-6 w-6" /></button>
            </div>
            <NavLinks />
          </div>
        </div>)}
    </>
  )
}
