import { useAuth } from '../../context/AuthContext'
import Avatar from '../ui/Avatar'
import { ChevronDown, PresentationIcon } from '../ui/Icons'

const DAYS = ['Fri 3', 'Sat 4', 'Sun 5', 'Mon 6', 'Tue 7']
// Right column used on dashboards: profile, week strip, schedule, upcoming events.
export default function RightPanel({ schedule = [], events = [], month = 'November 2023', registered = null }) {
  const { user } = useAuth()
  return (
    <aside className="card w-full shrink-0 p-4 xl:w-[300px]">
      <div className="hidden items-center gap-3 lg:flex">
        <Avatar src={user?.avatar} name={user?.name} size={60} />
        <div className="leading-tight"><p className="text-sm font-bold">{user?.name}</p><p className="text-xs text-ink-soft capitalize">{user?.role}</p></div>
        {user?.role === 'admin' && <ChevronDown className="ml-auto h-4 w-4" />}
      </div>
      <h2 className="text-xl font-bold lg:mt-5">{month}</h2>
      <div className="mt-2 flex gap-2">
        {DAYS.map((d) => { const [n, num] = d.split(' '); return (
          <div key={d} className="flex h-11 w-10 flex-col items-center justify-center rounded-[10px] bg-surface-line text-xs"><span>{n}</span><span>{num}</span></div>) })}
      </div>
      {registered ? (
        <section aria-label="Students registered">
          <h2 className="mt-5 text-xl font-bold">Students registered</h2>
          <div className="mt-2 rounded-[10px] bg-brand-soft p-5 text-center">
            <p className="text-5xl font-bold text-brand" data-testid="students-registered">{registered.total}</p>
            <p className="mt-1 text-sm text-ink-soft">students on the platform</p>
          </div>
          <dl className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between rounded-[5px] bg-surface-gray px-4 py-2.5"><dt>New this week</dt><dd className="font-bold">{registered.newThisWeek}</dd></div>
            <div className="flex justify-between rounded-[5px] bg-surface-gray px-4 py-2.5"><dt>Enrolled in a course</dt><dd className="font-bold">{registered.enrolled}</dd></div>
          </dl>
        </section>
      ) : (
        <>
          <h2 className="mt-5 text-xl font-bold">Schedule</h2>
          <ul className="mt-2 space-y-3">
            {schedule.map((s, i) => (
              <li key={s.id} className="flex items-center gap-3 rounded-[5px] bg-surface-gray px-4 py-2.5">
                <span className="w-4 text-xl font-bold">{i + 1}</span>
                <div className="border-l border-black pl-3"><p className="text-sm font-bold">{s.subject}</p><p className="text-xs text-ink-soft/70">{s.done} of {s.total} chapters</p></div>
                <span className="ml-auto text-xs text-ink-soft">{s.time}</span>
              </li>))}
          </ul>
        </>
      )}
      <div className="mt-5 flex items-baseline justify-between"><h2 className="text-xl font-bold">Upcoming Events</h2><button className="text-sm text-ink-soft">See all</button></div>
      <ul className="mt-3 space-y-3">
        {events.map((e) => (
          <li key={e.id} className="flex items-center gap-4">
            <div className="flex h-16 w-20 shrink-0 items-center justify-center rounded-[10px] bg-surface-line text-brand"><PresentationIcon className="h-9 w-9" /></div>
            <p className={`text-sm ${e.soon ? 'text-black/40' : 'font-bold'}`}>{e.soon ? 'Coming soon' : e.title}</p>
          </li>))}
      </ul>
    </aside>
  )
}
