import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { authApi } from '../services/api'
import { tokenStore, USE_MOCK } from '../services/http'

const AuthContext = createContext(null)
export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!tokenStore.get()) { setLoading(false); return }
    authApi.me().then(setUser).catch(() => tokenStore.clear()).finally(() => setLoading(false))
  }, [])

  const logout = useCallback(() => { authApi.logout(); localStorage.removeItem('yoloa_role'); setUser(null) }, [])
  useEffect(() => {
    window.addEventListener('auth:logout', logout)
    return () => window.removeEventListener('auth:logout', logout)
  }, [logout])

  const login = async (creds) => {
    const { token, user } = await authApi.login(creds) // errors bubble up to the form
    tokenStore.set(token); localStorage.setItem('yoloa_role', user.role); setUser(user)
    return user
  }

  return <AuthContext.Provider value={{ user, loading, login, logout, setUser, mock: USE_MOCK }}>{children}</AuthContext.Provider>
}
