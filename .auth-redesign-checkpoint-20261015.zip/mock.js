// Mock data mirroring the Figma screens. Replace by real API responses later.
export const mockUsers = {
  student: { id: 's1', name: 'Swetha shankaresh', role: 'student', email: 'swetha@example.com', username: 'swetha', firstName: 'Swetha', lastName: 'Shankaresh', address: '', city: '', country: '', postalCode: '', avatar: '' },
  admin: { id: 'a1', name: 'Admin', role: 'admin', email: 'admin@example.com', username: 'admin', firstName: 'Admin', lastName: '', avatar: '' },
}

export const mockDashboard = {
  announcement: 'Hello swetha, your live session is about to start!',
  leaderboard: [
    { id: 1, name: 'Shyam Nithin', score: 60, avatar: '' },
    { id: 2, name: 'Nivin Kumar', score: 58, avatar: '' },
    { id: 3, name: 'Nivetha Dinesh', score: 50, avatar: '' },
    { id: 4, name: 'Rudhra shankar', score: 49, avatar: '' },
  ],
  completion: [
    { id: 1, title: 'Organic Chemistry', chapter: 'Chapter 1', percent: 77 },
    { id: 2, title: 'States of matter', chapter: 'Chapter 2', percent: 63 },
    { id: 3, title: 'Solutions', chapter: 'Chapter 3', percent: 52 },
    { id: 4, title: 'Chemical changes', chapter: 'Chapter 4', percent: 66 },
  ],
  assignments: [{ id: 1, subject: 'Chemistry', chapter: 'Chapter 5', title: 'Daily task', page: 'Page 10', time: '11.00 AM', status: 'Pending' }],
  schedule: [
    { id: 1, subject: 'Physics', done: 6, total: 20, time: '17.00 - 18.00' },
    { id: 2, subject: 'Chemistry', done: 8, total: 20, time: '18.00 - 19.00' },
    { id: 3, subject: 'Mathmetics', done: 5, total: 20, time: '19.00 - 20.00' },
    { id: 4, subject: 'Biology', done: 4, total: 20, time: '21.00 - 22.00' },
    { id: 5, subject: 'Social', done: 7, total: 20, time: '16.00 - 17.00' },
  ],
  upcomingEvents: [
    { id: 1, title: 'Presentation for maths', soon: false },
    { id: 2, title: 'Guest Lecture on Atoms', soon: true },
    { id: 3, title: 'English - Prepositions', soon: true },
  ],
}

export const mockCourses = [
  { id: 'math', title: 'Maths Department', status: 'ongoing', enrolled: true, percent: 67, chapters: 6, students: 12, cover: '', accent: 'from-emerald-700 to-emerald-900', enrollment: 'Continous enrollement' },
  { id: 'chem', title: 'Chemistry Department', status: 'ongoing', enrolled: true, percent: 50, chapters: 6, students: 12, cover: '', accent: 'from-fuchsia-500 to-indigo-700', enrollment: 'Continous enrollement' },
  { id: 'phys', title: 'Physics Department', status: 'ongoing', enrolled: true, percent: 50, chapters: 6, students: 12, cover: '', accent: 'from-orange-400 to-blue-700' },
  { id: 'cs', title: 'Computer science Department', status: 'completed', enrolled: true, percent: 100, chapters: 6, students: 12, cover: '', accent: 'from-slate-700 to-black' },
  { id: 'eng', title: 'English Department', status: 'ongoing', enrolled: true, percent: 67, chapters: 6, students: 12, cover: '', accent: 'from-yellow-400 to-pink-500' },
  { id: 'soc', title: 'Social science Department', status: 'available', enrolled: false, percent: 0, chapters: 6, students: 12, cover: '', accent: 'from-amber-200 to-amber-600' },
]

export const mockCourseDetail = {
  id: 'chem', title: 'Matter', adminTitle: 'Chemistry', cover: '',
  description: 'Matter is one of the very important topic in Chemistry. Matter is anything that takes up space and can be weighed. In other words, matter has volume and mass. There are many different substances, or types of matter, in the universe.',
  professor: { name: 'Devi Prasad', title: 'Professor', avatar: '' },
  content: [
    { id: 1, title: 'What is matter?', text: 'A common or traditional definition of matter is "anything that has mass and volume (occupies space)".', color: 'green', fileUrl: '#' },
    { id: 2, title: 'Chemical Element', text: 'A chemical element is a pure substance that consists of atoms with the same number of protons in the nucleus.', color: 'pink', fileUrl: '#' },
    { id: 3, title: 'Phase Changes', text: 'Heat decides the state of matter. Heat plays an important role in converting one state of matter to another. Adding heat or taking off heat brings in change of state/ phase.', color: 'blue', fileUrl: '#' },
  ],
  progress: [
    { id: 1, title: 'Organic Chemistry', chapter: 'Chapter 10', status: 'Completed' },
    { id: 2, title: 'Advanced maths', chapter: 'Chapter 9', status: 'Completed' },
    { id: 3, title: 'Physics', chapter: 'Chapter 8', status: 'In progress' },
  ],
  publishedExams: [{ id: 1, title: 'Final exam', subject: 'Mathematics', status: 'Published' }],
}

export const mockPlayer = {
  courseId: 'math', courseTitle: 'Java Module 2',
  description: 'Probability theory helps students to calculate the possibilities in cases like cards deck, heads, and tails in coins, probability of winning the match, and many more situations. This is considered one of the most important math topics in the class 9 math syllabus and for students preparing for other Competitive exams.',
  modules: [1, 2, 3, 4, 5, 6].map((n) => ({ id: n, title: `Math chapter ${n}`, duration: '1 hr 30 mins', videoUrl: '', completed: n <= 3 })),
}

export const mockLibrary = [
  ['Chemistry', 'Chemistry Textbook Class 9'], ['Chemistry', 'Problems in Inorganic Chemistry'],
  ['Physics', 'Physics Class 12'], ['Physics', 'Principles of Physics'],
  ['Mathematics', 'Mathematics Textbook Class XI'], ['Mathematics', 'Active Mathematics Book 1'],
  ['English', 'Learn English'], ['English', 'General English'],
].map(([subject, title], i) => ({ id: i + 1, subject, title, cover: '', fileUrl: '#' }))

export const mockNotesApps = [
  { id: 'drive', name: 'Google Drive', url: 'https://drive.google.com', color: '#34a853' },
  { id: 'lens', name: 'Google Lens', url: 'https://lens.google.com', color: '#4285f4' },
  { id: 'excel', name: 'Excel', url: 'https://www.office.com/launch/excel', color: '#107c41' },
  { id: 'doc', name: 'Google Doc', url: 'https://docs.google.com', color: '#4285f4' },
  { id: 'word', name: 'Word', url: 'https://www.office.com/launch/word', color: '#2b579a' },
  { id: 'ppt', name: 'Power point', url: 'https://www.office.com/launch/powerpoint', color: '#d24726' },
]

export const mockCalendar = {
  year: 2023, monthIndex: 10,
  events: [
    { id: 1, date: '2023-11-11', title: 'Physics workshop', type: 'event' },
    { id: 2, date: '2023-11-15', title: 'Maths Assignment Deadline', type: 'deadline' },
  ],
  daySchedule: { date: 'November 20, Monday', items: [{ time: '10.00 AM', title: 'Live class' }, { time: '11.00 AM', title: 'Physics Workshop' }] },
}

// Single source of truth: admin "Exams" and student "Quizzes" are the same records (Published ones = quizzes).
const ex = (id, title, subject, status, points, duration) =>
  ({ id, title, subject, term: '1st Term', duration, questions: 10, points, status, attempts: 0, bestScore: null })
export const mockExams = [
  ex(1, 'Test 01', 'Java', 'Published', 10, '15 mins'), ex(2, 'Test 02', 'Java', 'Published', 10, '15 mins'),
  ex(3, 'Test 03', 'Python', 'Published', 10, '15 mins'), ex(4, 'Test 04', 'DSA', 'Published', 10, '15 mins'),
  ex(5, 'Final exam', 'Mathematics', 'Published', 100, '50 mins'), ex(6, 'Final exam', 'Chemistry', 'Draft', 100, '50 mins'),
  ex(7, 'Final exam', 'Botany', 'Draft', 100, '50 mins'), ex(8, 'Final exam', 'Physics', 'Draft', 100, '50 mins'),
  ex(9, 'Final exam', 'English', 'Draft', 100, '50 mins'),
]
// Questions for an exam. Admin-created exams carry their own `items`; seeded ones get generated samples (correct = i % 4).
export const mockQuizQuestions = (e) => e.items || Array.from({ length: e.questions }, (_, i) => ({
  id: e.id * 100 + i, points: Math.round(e.points / e.questions), correct: i % 4,
  text: `${e.subject} sample question ${i + 1}: which option is correct?`,
  choices: ['Option A', 'Option B', 'Option C', 'Option D'],
}))

export const mockAdminDashboard = {
  announcements: [{ id: 1, author: 'Sherin jackson', text: 'Hello, you have to complete your papers', time: '3.30 pm', avatar: '' }],
  stats: { total: 31, absent: 20, present: 11, newThisWeek: 4, enrolled: 27 },
  upcomingEvents: mockDashboard.upcomingEvents,
}
