"""HTTP API for YOLOA.

Assessment decisions live here (and not in React): eligibility, timing, scoring,
answer ownership, and completion are all calculated against persisted records.
"""
import calendar as cal
import io
import json
import re
import string
import unicodedata
import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal

from django.contrib.auth import authenticate
from django.db import IntegrityError, transaction
from django.db.models import Avg, Count, Max, Q
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework.decorators import api_view, parser_classes, permission_classes
from rest_framework.exceptions import ValidationError
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenRefreshView

from . import models as m
from .utils import IsAdminRole, abs_url, to_int, user_json

ANY = [JSONParser, FormParser, MultiPartParser]
PASS_PERCENT = Decimal('60')
FINAL_DURATION_SECONDS = 600
MAX_IMPORT_BYTES = 5 * 1024 * 1024


def fail(message, code=400):
    return Response({'message': message}, status=code)


def value_number(value):
    """JSON-friendly number which does not expose Decimal implementation details."""
    return float(value) if isinstance(value, Decimal) else value


def date_filter(request, queryset, field='created_at'):
    """Apply optional ISO date range query parameters to an analytics queryset."""
    for name, lookup in (('start', 'gte'), ('end', 'lte')):
        raw = request.query_params.get(name)
        if not raw:
            continue
        try:
            parsed = date.fromisoformat(raw)
        except ValueError:
            raise ValidationError({name: 'Use YYYY-MM-DD.'})
        if lookup == 'gte':
            queryset = queryset.filter(**{f'{field}__date__gte': parsed})
        else:
            queryset = queryset.filter(**{f'{field}__date__lte': parsed})
    return queryset


# ───────────────────────── Authentication and dashboards ─────────────────────────
class TrackedTokenRefreshView(TokenRefreshView):
    """Refreshes are tracked separately, and never create a credential-login event."""
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        if response.status_code < 400:
            try:
                token = RefreshToken(request.data.get('refresh', ''))
                user_id = token.get('user_id')
                if user_id and m.User.objects.filter(pk=user_id).exists():
                    m.LoginEvent.objects.create(user_id=user_id, event_type='refresh')
            except Exception:
                # A valid refresh response is authoritative; analytics must not reveal token details.
                pass
        return response


@api_view(['POST'])
@permission_classes([AllowAny])
def login(request):
    data = request.data
    user = authenticate(username=data.get('username', ''), password=data.get('password', ''))
    if not user:
        return fail('Invalid username or password', 401)
    if data.get('role') and data['role'] != user.role:
        return fail(f'This account is not a {data["role"]} account', 403)
    refresh = RefreshToken.for_user(user)
    user.last_login = timezone.now()
    user.save(update_fields=['last_login'])
    m.LoginEvent.objects.create(user=user, event_type='login')
    return Response({'token': str(refresh.access_token), 'refresh': str(refresh), 'user': user_json(user, request)})


@api_view(['GET'])
def me(request):
    return Response(user_json(request.user, request))


def schedule_json(user):
    return [{'id': item.id, 'subject': item.subject, 'done': item.done, 'total': item.total, 'time': item.time} for item in user.schedule.all()]


def upcoming_json():
    events = m.CalendarEvent.objects.filter(user__isnull=True, date__gte=date.today())[:3]
    return [{'id': event.id, 'title': event.title, 'soon': index > 0} for index, event in enumerate(events)]


@api_view(['GET'])
def student_dashboard(request):
    user = request.user
    latest = m.Announcement.objects.first()
    best = {}
    for student_id, exam_id, score in m.Attempt.objects.filter(status__in=['submitted', 'expired']).values_list('student_id', 'exam_id', 'score'):
        best[(student_id, exam_id)] = max(best.get((student_id, exam_id), Decimal('0')), score)
    totals = {}
    for (student_id, _), score in best.items():
        totals[student_id] = totals.get(student_id, Decimal('0')) + score
    top = sorted(totals.items(), key=lambda item: -item[1])[:4]
    users = {item.id: item for item in m.User.objects.filter(id__in=[student_id for student_id, _ in top])}
    leaderboard = [{'id': student_id, 'name': users[student_id].display_name, 'score': value_number(score), 'avatar': abs_url(request, users[student_id].avatar)} for student_id, score in top]
    completion = [{'id': enrollment.id, 'title': enrollment.course.title, 'chapter': enrollment.current_chapter, 'percent': enrollment.percent,
                   'status': enrollment.status, 'completionSource': enrollment.completion_source}
                  for enrollment in user.enrollments.select_related('course')[:6]]
    assignments = [{'id': assignment.id, 'subject': assignment.subject, 'chapter': assignment.chapter, 'title': assignment.title,
                    'page': assignment.page, 'time': assignment.due_time, 'status': assignment.status} for assignment in user.assignments.all()]
    return Response({'announcement': latest.text if latest else '', 'leaderboard': leaderboard, 'completion': completion,
                     'assignments': assignments, 'schedule': schedule_json(user), 'upcomingEvents': upcoming_json()})


@api_view(['GET'])
@permission_classes([IsAdminRole])
def admin_dashboard(request):
    students = m.User.objects.filter(role='student')
    period = date_filter(request, students, 'date_joined')
    today = timezone.localdate()
    week_ago = timezone.now() - timedelta(days=7)
    logins = date_filter(request, m.LoginEvent.objects.all())
    announcements = [{'id': announcement.id, 'author': announcement.author.display_name, 'text': announcement.text,
                      'time': timezone.localtime(announcement.created_at).strftime('%I.%M %p').lstrip('0').lower(),
                      'avatar': abs_url(request, announcement.author.avatar)}
                     for announcement in m.Announcement.objects.select_related('author')[:5]]
    return Response({'announcements': announcements, 'stats': {
        'total': students.count(),
        'newRegistrations': period.count(),
        'newThisWeek': students.filter(date_joined__gte=week_ago).count(),
        'uniqueSignedIn': logins.filter(event_type='login').values('user_id').distinct().count(),
        'successfulLogins': logins.filter(event_type='login').count(),
        'tokenRefreshes': logins.filter(event_type='refresh').count(),
        # Retained for existing dashboard UI; it is explicitly a daily last-login estimate.
        'present': students.filter(last_login__date=today).count(),
        'absent': students.exclude(last_login__date=today).count(),
        'enrolled': students.filter(enrollments__isnull=False).distinct().count(),
    }, 'upcomingEvents': upcoming_json()})


@api_view(['POST'])
@permission_classes([IsAdminRole])
def announcements(request):
    text = (request.data.get('text') or '').strip()
    if not text:
        raise ValidationError({'text': 'This field is required.'})
    announcement = m.Announcement.objects.create(author=request.user, text=text)
    return Response({'id': announcement.id, 'text': announcement.text, 'author': request.user.display_name}, status=201)


# ───────────────────────── Courses, enrollment and lesson progress ─────────────────────────
def get_enrollment(user, course):
    return m.Enrollment.objects.filter(student=user, course=course).first() if user.role == 'student' else None


def done_chapter_ids(user, chapters):
    return set(m.ChapterProgress.objects.filter(student=user, chapter__in=chapters, completed=True).values_list('chapter_id', flat=True))


def recalc_enrollment(enrollment):
    """Lesson progress is independent of earned final-exam completion."""
    chapters = list(enrollment.course.chapters.all())
    done = done_chapter_ids(enrollment.student, chapters)
    next_chapter = next((chapter for chapter in chapters if chapter.id not in done), None)
    enrollment.percent = round(len(done) * 100 / len(chapters)) if chapters else 0
    enrollment.current_chapter = next_chapter.title if next_chapter else (chapters[-1].title if chapters else '')
    # Never erase a passed final exam or an existing legacy completion because lesson progress changes.
    if enrollment.status != 'completed':
        enrollment.status = 'ongoing'
    enrollment.save(update_fields=['percent', 'current_chapter', 'status'])
    return enrollment


def module_assessments(course):
    return m.Exam.objects.filter(course=course, assessment_type='module_quiz', status='published').select_related('module')


def latest_and_best(student, exam):
    attempts = m.Attempt.objects.filter(student=student, exam=exam, status__in=['submitted', 'expired'])
    latest = attempts.order_by('-submitted_at', '-id').first()
    best = attempts.aggregate(best=Max('score'))['best']
    return {'attempts': attempts.count(), 'latestScore': value_number(latest.score) if latest else None,
            'latestPercent': value_number(latest.percentage) if latest else None,
            'bestScore': value_number(best) if best is not None else None,
            'passed': attempts.filter(passed=True).exists()}


def final_eligibility(student, exam):
    if exam.assessment_type != 'final_exam':
        return {'eligible': True, 'reasons': []}
    reasons = []
    if exam.status != 'published':
        reasons.append('The final exam is not published.')
    if not exam.course_id:
        reasons.append('The final exam is not associated with a course.')
        return {'eligible': False, 'reasons': reasons, 'requiredQuizzes': []}
    enrollment = get_enrollment(student, exam.course)
    if not enrollment:
        reasons.append('Enroll in this course before starting its final exam.')
    required_modules = list(exam.course.chapters.filter(required=True))
    quizzes = {quiz.module_id: quiz for quiz in module_assessments(exam.course) if quiz.module_id}
    report = []
    for module in required_modules:
        quiz = quizzes.get(module.id)
        if not quiz:
            report.append({'moduleId': module.id, 'title': module.title, 'status': 'missing'})
            reasons.append(f'A published required module quiz is missing for {module.title}.')
        elif m.Attempt.objects.filter(student=student, exam=quiz, passed=True, status__in=['submitted', 'expired']).exists():
            report.append({'moduleId': module.id, 'quizId': quiz.id, 'title': module.title, 'status': 'passed'})
        else:
            report.append({'moduleId': module.id, 'quizId': quiz.id, 'title': module.title, 'status': 'not_passed'})
            reasons.append(f'Pass the {module.title} module quiz first.')
    return {'eligible': not reasons, 'reasons': reasons, 'requiredQuizzes': report,
            'enrollmentStatus': enrollment.status if enrollment else None}


def course_assessment_summary(student, course):
    quizzes = []
    for exam in module_assessments(course):
        quizzes.append({'id': exam.id, 'moduleId': exam.module_id, 'moduleTitle': exam.module.title if exam.module else '',
                        'required': bool(exam.module and exam.module.required), **latest_and_best(student, exam)})
    final = m.Exam.objects.filter(course=course, assessment_type='final_exam', status='published').first()
    return {'moduleQuizzes': quizzes, 'finalExam': ({'id': final.id, 'title': final.title, **final_eligibility(student, final),
                                                      **latest_and_best(student, final)} if final else None)}


@api_view(['GET', 'POST'])
@parser_classes(ANY)
def courses(request):
    if request.method == 'GET':
        is_student = request.user.role == 'student'
        enrollments = {item.course_id: item for item in request.user.enrollments.all()} if is_student else {}
        rows = []
        for course in m.Course.objects.annotate(n=Count('chapters', distinct=True), s=Count('enrollments', distinct=True)):
            enrollment = enrollments.get(course.id)
            rows.append({'id': course.id, 'title': course.title, 'cover': abs_url(request, course.cover), 'enrollment': course.enrollment_label,
                         'status': enrollment.status if enrollment else ('available' if is_student else 'ongoing'), 'enrolled': bool(enrollment),
                         'percent': enrollment.percent if enrollment else 0, 'chapters': course.n, 'students': course.s,
                         'completionSource': enrollment.completion_source if enrollment else ''})
        return Response(rows)

    if request.user.role != 'admin':
        return fail('Admin access required.', 403)
    data = request.data
    title = (data.get('title') or '').strip()
    if not title:
        raise ValidationError({'title': 'This field is required.'})
    try:
        chapters = json.loads(data.get('chapters') or '[]')
    except json.JSONDecodeError:
        raise ValidationError({'chapters': 'Must be a JSON array.'})
    with transaction.atomic():
        course = m.Course.objects.create(title=title, description=data.get('description', ''), cover=data.get('cover') or None,
                                         start_date=data.get('startDate') or None, end_date=data.get('endDate') or None,
                                         created_by=request.user, professor=request.user)
        for index, chapter in enumerate(chapters):
            m.Chapter.objects.create(course=course, title=chapter.get('title') or f'Chapter {index + 1}', order=index,
                                     video_url=chapter.get('videoUrl', ''), required=bool(chapter.get('required', False)))
    return Response({'id': course.id, 'title': course.title}, status=201)


@api_view(['POST', 'DELETE'])
def course_enroll(request, pk):
    if request.user.role != 'student':
        return fail('Only students can enroll in courses.', 403)
    course = get_object_or_404(m.Course, pk=pk)
    if request.method == 'DELETE':
        m.Enrollment.objects.filter(student=request.user, course=course).delete()
        return Response(status=204)
    enrollment, created = m.Enrollment.objects.get_or_create(student=request.user, course=course)
    recalc_enrollment(enrollment)
    return Response({'enrolled': True, 'percent': enrollment.percent, 'status': enrollment.status,
                     'currentChapter': enrollment.current_chapter}, status=201 if created else 200)


@api_view(['GET', 'DELETE'])
def course_detail(request, pk):
    course = get_object_or_404(m.Course, pk=pk)
    if request.method == 'DELETE':
        if request.user.role != 'admin':
            return fail('Admin access required.', 403)
        if course.exams.filter(attempts__isnull=False).exists():
            return fail('This course has assessment history and cannot be deleted. Archive its assessments instead.', 409)
        if course.cover:
            course.cover.delete(save=False)
        for item in course.contents.all():
            if item.file:
                item.file.delete(save=False)
        course.delete()
        return Response(status=204)
    professor = course.professor
    enrollment = get_enrollment(request.user, course)
    chapters = list(course.chapters.all())
    done = done_chapter_ids(request.user, chapters) if enrollment else set()
    progress = [{'id': item.id, 'title': item.course.title, 'chapter': item.current_chapter,
                 'status': 'Completed' if item.status == 'completed' else 'In progress'}
                for item in request.user.enrollments.select_related('course')[:5]]
    published = course.exams.filter(status='published')
    return Response({'id': course.id, 'title': course.title, 'adminTitle': course.title, 'description': course.description,
        'cover': abs_url(request, course.cover), 'enrolled': bool(enrollment), 'percent': enrollment.percent if enrollment else 0,
        'status': enrollment.status if enrollment else 'available', 'completionSource': enrollment.completion_source if enrollment else '',
        'professor': {'name': professor.display_name, 'title': 'Professor', 'avatar': abs_url(request, professor.avatar)} if professor else None,
        'content': [{'id': item.id, 'title': item.title, 'text': item.text, 'color': item.color, 'fileUrl': abs_url(request, item.file) or '#'} for item in course.contents.all()],
        'chapters': [{'id': chapter.id, 'title': chapter.title, 'duration': chapter.duration, 'required': chapter.required,
                      'completed': chapter.id in done} for chapter in chapters], 'progress': progress,
        'publishedExams': [exam_row(exam) for exam in published],
        'assessment': course_assessment_summary(request.user, course) if enrollment else None})


@api_view(['GET'])
def course_player(request, pk):
    course = get_object_or_404(m.Course, pk=pk)
    enrollment = get_enrollment(request.user, course)
    if request.user.role == 'student' and not enrollment:
        return fail('Enroll in this course to start learning.', 403)
    chapters = list(course.chapters.all())
    done = done_chapter_ids(request.user, chapters) if enrollment else set()
    current = next((chapter for chapter in chapters if chapter.id not in done), chapters[-1] if chapters else None)
    return Response({'courseId': course.id, 'courseTitle': course.title, 'description': course.description,
                     'percent': enrollment.percent if enrollment else 0, 'status': enrollment.status if enrollment else 'ongoing',
                     'lessonTitle': current.title if current else '', 'videoUrl': current.video_url if current else '',
                     'currentModuleId': current.id if current else None,
                     'modules': [{'id': chapter.id, 'title': chapter.title, 'duration': chapter.duration,
                                  'videoUrl': chapter.video_url, 'completed': chapter.id in done} for chapter in chapters]})


@api_view(['PUT'])
def chapter_progress(request, pk):
    if request.user.role != 'student':
        return fail('Only students track progress.', 403)
    chapter = get_object_or_404(m.Chapter.objects.select_related('course'), pk=pk)
    enrollment = get_enrollment(request.user, chapter.course)
    if not enrollment:
        return fail('Enroll in this course first.', 403)
    raw = request.data.get('completed', True)
    completed = raw if isinstance(raw, bool) else str(raw).lower() in ('1', 'true', 'yes')
    m.ChapterProgress.objects.update_or_create(student=request.user, chapter=chapter,
        defaults={'completed': completed, 'completed_at': timezone.now() if completed else None})
    recalc_enrollment(enrollment)
    return Response({'chapterId': chapter.id, 'completed': completed, 'percent': enrollment.percent, 'status': enrollment.status,
                     'currentChapter': enrollment.current_chapter, 'courseCompleted': enrollment.status == 'completed'})


# ───────────────────────── Assessment definitions and validation ─────────────────────────
def assessment_type_label(exam):
    return dict(m.Exam.ASSESSMENT_TYPES).get(exam.assessment_type, exam.assessment_type)


def exam_row(exam):
    questions = list(exam.questions.all())
    return {'id': exam.id, 'title': exam.title, 'subject': exam.subject, 'term': exam.term, 'duration': exam.duration,
            'durationSeconds': exam.duration_seconds, 'questions': len(questions), 'points': sum(question.points for question in questions),
            'status': exam.get_status_display(), 'assessmentType': exam.assessment_type, 'assessmentTypeLabel': assessment_type_label(exam),
            'courseId': exam.course_id, 'moduleId': exam.module_id, 'moduleTitle': exam.module.title if exam.module else ''}


def parse_choice_reference(raw, choices):
    if isinstance(raw, int):
        return raw
    text = str(raw or '').strip()
    if len(text) == 1 and text.upper() in string.ascii_uppercase:
        return ord(text.upper()) - ord('A')
    try:
        return int(text)
    except ValueError:
        if text in choices:
            return choices.index(text)
    return -1


def split_values(value):
    if isinstance(value, list):
        return value
    if value is None:
        return []
    return [part.strip() for part in re.split(r'[|;,]', str(value)) if part.strip()]


def normalise_answer(value, rules):
    output = str(value or '').strip()
    if rules.get('caseInsensitive', True):
        output = output.casefold()
    if rules.get('ignorePunctuation', False):
        output = ''.join(char for char in output if not unicodedata.category(char).startswith('P'))
    return ' '.join(output.split())


def question_data(raw, index=0):
    question_type = raw.get('questionType', raw.get('question_type', 'single'))
    if question_type not in dict(m.Question.QUESTION_TYPES):
        raise ValidationError({'questions': f'Question {index + 1}: unsupported question type.'})
    text = str(raw.get('text', raw.get('questionText', '')) or '').strip()
    if not text:
        raise ValidationError({'questions': f'Question {index + 1} needs text.'})
    points = to_int(raw.get('points', raw.get('marks', raw.get('score', 1))), 1)
    if points <= 0:
        raise ValidationError({'questions': f'Question {index + 1} has invalid marks.'})
    choices = [str(choice).strip() for choice in (raw.get('choices') or split_values(raw.get('options'))) if str(choice).strip()]
    normalisation = raw.get('normalization') or {}
    if not isinstance(normalisation, dict):
        raise ValidationError({'questions': f'Question {index + 1} has invalid normalization rules.'})
    correct_raw = raw.get('correctAnswers', raw.get('correct', raw.get('correctAnswer')))
    result = {'text': text, 'question_type': question_type, 'choices': choices, 'points': points, 'score': points,
              'order': index, 'normalization': normalisation, 'correct': 0, 'correct_answers': [],
              'expected_answer': '', 'accepted_answers': []}
    if question_type == 'single':
        if len(choices) < 2:
            raise ValidationError({'questions': f'Question {index + 1} needs at least two choices.'})
        refs = split_values(correct_raw)
        if len(refs) != 1:
            raise ValidationError({'questions': f'Question {index + 1} needs exactly one correct choice.'})
        correct = parse_choice_reference(refs[0], choices)
        if correct < 0 or correct >= len(choices):
            raise ValidationError({'questions': f'Question {index + 1} has an invalid correct choice.'})
        result.update(correct=correct, correct_answers=[correct])
    elif question_type == 'multiple':
        if len(choices) < 2:
            raise ValidationError({'questions': f'Question {index + 1} needs at least two choices.'})
        indexes = [parse_choice_reference(value, choices) for value in split_values(correct_raw)]
        if not indexes or any(value < 0 or value >= len(choices) for value in indexes) or len(set(indexes)) != len(indexes):
            raise ValidationError({'questions': f'Question {index + 1} needs valid distinct correct choices.'})
        result['correct_answers'] = sorted(indexes)
    elif question_type == 'true_false':
        if isinstance(correct_raw, list):
            correct_raw = correct_raw[0] if correct_raw else None
        text_value = str(correct_raw).strip().casefold()
        if text_value not in ('true', 'false'):
            raise ValidationError({'questions': f'Question {index + 1} needs a true or false answer.'})
        result.update(choices=['True', 'False'], correct_answers=[text_value == 'true'], correct=0 if text_value == 'true' else 1)
    else:
        expected = str(raw.get('expectedAnswer', raw.get('expected_answer', correct_raw)) or '').strip()
        alternatives = [str(value).strip() for value in split_values(raw.get('acceptedAlternatives', raw.get('accepted_answers'))) if str(value).strip()]
        if not expected:
            raise ValidationError({'questions': f'Question {index + 1} needs an expected short answer.'})
        result.update(expected_answer=expected, accepted_answers=alternatives)
    return result


def check_publishable(exam):
    questions = list(exam.questions.all())
    if not questions:
        raise ValidationError({'message': 'Add at least one question before publishing.'})
    for index, question in enumerate(questions):
        # Re-use authoritative validation so direct API and spreadsheet imports follow one rule.
        question_data({'text': question.text, 'questionType': question.question_type, 'choices': question.choices,
                       'correct': question.correct_answers if question.question_type == 'multiple' else (
                           question.correct_answers[0] if question.correct_answers else question.correct),
                       'expectedAnswer': question.expected_answer, 'acceptedAlternatives': question.accepted_answers,
                       'points': question.points, 'normalization': question.normalization}, index)
    if exam.assessment_type == 'final_exam':
        if not exam.course_id:
            raise ValidationError({'courseId': 'A final exam must belong to a course.'})
        missing = [chapter.title for chapter in exam.course.chapters.filter(required=True)
                   if not m.Exam.objects.filter(course=exam.course, module=chapter, assessment_type='module_quiz', status='published').exists()]
        if missing:
            raise ValidationError({'message': 'Required module quizzes are missing for: ' + ', '.join(missing)})


def save_exam(exam, data, user=None):
    assessment_type = data.get('assessmentType', data.get('assessment_type', exam.assessment_type or 'legacy_quiz'))
    if assessment_type not in dict(m.Exam.ASSESSMENT_TYPES):
        raise ValidationError({'assessmentType': 'Unsupported assessment type.'})
    if data.get('status') and data['status'] not in ('draft', 'published'):
        raise ValidationError({'status': "Must be 'draft' or 'published'."})
    for field in ('title', 'subject', 'term', 'duration', 'status'):
        if field in data:
            setattr(exam, field, data[field])
    exam.assessment_type = assessment_type
    if 'courseId' in data or 'course_id' in data:
        course_id = data.get('courseId', data.get('course_id'))
        exam.course = get_object_or_404(m.Course, pk=course_id) if course_id else None
    if 'moduleId' in data or 'module_id' in data:
        module_id = data.get('moduleId', data.get('module_id'))
        exam.module = get_object_or_404(m.Chapter, pk=module_id) if module_id else None
    if assessment_type == 'final_exam':
        exam.module = None
        exam.duration_seconds = FINAL_DURATION_SECONDS
        exam.duration = '10 mins'
    elif 'durationSeconds' in data:
        exam.duration_seconds = to_int(data.get('durationSeconds'), 0) or None
    if assessment_type == 'module_quiz':
        if not exam.course_id or not exam.module_id or exam.module.course_id != exam.course_id:
            raise ValidationError({'moduleId': 'A module quiz must belong to a module in its course.'})
    if not exam.title:
        raise ValidationError({'title': 'This field is required.'})
    if user and not exam.pk:
        exam.created_by = user
    exam.save()
    if 'questions' in data:
        if exam.attempts.filter(status='in_progress').exists():
            raise ValidationError({'message': 'Cannot edit questions while an attempt is in progress.'})
        questions = data['questions'] or []
        validated = [question_data(question, index) for index, question in enumerate(questions)]
        exam.questions.all().delete()
        m.Question.objects.bulk_create([m.Question(exam=exam, **question) for question in validated])
    if exam.status == 'published':
        check_publishable(exam)
    return exam


@api_view(['GET', 'POST'])
def exams(request):
    if request.user.role != 'admin':
        return fail('Admin access required.', 403)
    if request.method == 'GET':
        return Response([exam_row(exam) for exam in m.Exam.objects.select_related('course', 'module').prefetch_related('questions')])
    with transaction.atomic():
        exam = save_exam(m.Exam(), request.data, request.user)
    return Response(exam_row(exam), status=201)


@api_view(['GET', 'PUT', 'DELETE'])
def exam_detail(request, pk):
    if request.user.role != 'admin':
        return fail('Admin access required.', 403)
    exam = get_object_or_404(m.Exam.objects.select_related('course', 'module'), pk=pk)
    if request.method == 'DELETE':
        if exam.attempts.exists():
            return fail('Assessments with attempt history cannot be deleted. Unpublish or archive them instead.', 409)
        exam.delete()
        return Response(status=204)
    if request.method == 'PUT':
        with transaction.atomic():
            exam = save_exam(exam, request.data)
    row = exam_row(exam)
    row['questions'] = [{'id': question.id, 'text': question.text, 'questionType': question.question_type,
                         'choices': question.choices, 'correct': question.correct, 'correctAnswers': question.correct_answers,
                         'expectedAnswer': question.expected_answer, 'acceptedAlternatives': question.accepted_answers,
                         'normalization': question.normalization, 'score': question.score, 'points': question.points}
                        for question in exam.questions.all()]
    return Response(row)


# ───────────────────────── Attempt lifecycle, scoring, and finalisation ─────────────────────────
def public_question(question):
    choices = question.choices or (['True', 'False'] if question.question_type == 'true_false' else [])
    return {'id': question.id, 'text': question.text, 'questionType': question.question_type, 'choices': choices, 'points': question.points}


def snapshot_question(question):
    return {**public_question(question), 'correct': question.correct, 'correctAnswers': question.correct_answers,
            'expectedAnswer': question.expected_answer, 'acceptedAlternatives': question.accepted_answers,
            'normalization': question.normalization}


def assessment_payload(exam, student):
    stats = latest_and_best(student, exam)
    return {'id': exam.id, 'title': exam.title, 'subject': exam.subject, 'assessmentType': exam.assessment_type,
            'durationSeconds': FINAL_DURATION_SECONDS if exam.assessment_type == 'final_exam' else exam.duration_seconds,
            'duration': '10 mins' if exam.assessment_type == 'final_exam' else exam.duration,
            'questionCount': exam.questions.count(), 'totalPoints': sum(question.points for question in exam.questions.all()),
            'courseId': exam.course_id, 'moduleId': exam.module_id, **stats,
            'eligibility': final_eligibility(student, exam)}


def student_visible_assessments(student):
    exams = m.Exam.objects.filter(status='published').exclude(assessment_type='final_exam').select_related('course', 'module').prefetch_related('questions')
    visible = []
    for exam in exams:
        if exam.course_id and not get_enrollment(student, exam.course):
            continue
        visible.append(exam)
    return visible


def attempt_response(attempt, include_correct=False):
    payload = {'attemptId': attempt.id, 'assessmentId': attempt.exam_id, 'status': attempt.status,
               'startedAt': attempt.started_at, 'deadline': attempt.deadline_at, 'submittedAt': attempt.submitted_at,
               'answers': attempt.answers, 'answerVersion': attempt.answer_version, 'score': value_number(attempt.score),
               'autoScore': value_number(attempt.auto_score), 'total': value_number(attempt.total_points),
               'percent': value_number(attempt.percentage), 'passed': attempt.passed,
               'questions': [{key: value for key, value in question.items() if include_correct or key not in ('correct', 'correctAnswers', 'expectedAnswer', 'acceptedAlternatives', 'normalization')}
                             for question in attempt.question_snapshot]}
    if include_correct and attempt.status != 'in_progress':
        payload['review'] = grade_snapshot(attempt.question_snapshot, attempt.answers)[2]
    return payload


def grade_snapshot(questions, answers):
    total = Decimal('0')
    score = Decimal('0')
    review = []
    for question in questions:
        points = Decimal(str(question.get('points', 0)))
        total += points
        question_id = str(question['id'])
        chosen = answers.get(question_id)
        question_type = question.get('questionType', 'single')
        if question_type == 'single':
            correct = (question.get('correctAnswers') or [question.get('correct', 0)])[0]
            ok = to_int(chosen, -1) == int(correct)
        elif question_type == 'multiple':
            expected = sorted({to_int(value, -1) for value in question.get('correctAnswers', [])})
            actual = sorted({to_int(value, -1) for value in (chosen if isinstance(chosen, list) else [])})
            ok = actual == expected
        elif question_type == 'true_false':
            expected = bool((question.get('correctAnswers') or [False])[0])
            actual = chosen if isinstance(chosen, bool) else str(chosen).strip().casefold() == 'true'
            ok = actual == expected
        else:
            rules = question.get('normalization') or {}
            candidates = [question.get('expectedAnswer', '')] + (question.get('acceptedAlternatives') or [])
            ok = any(normalise_answer(chosen, rules) == normalise_answer(candidate, rules) for candidate in candidates)
        earned = points if ok else Decimal('0')
        score += earned
        review.append({'id': question['id'], 'text': question['text'], 'questionType': question_type,
                       'choices': question.get('choices', []), 'chosen': chosen, 'correct': question.get('correct'),
                       'correctAnswers': question.get('correctAnswers', []), 'expectedAnswer': question.get('expectedAnswer', ''),
                       'isCorrect': ok, 'points': value_number(points), 'earned': value_number(earned)})
    return (score, total, review)


def update_completion(attempt):
    """A later failed retake deliberately cannot undo an already-earned completion."""
    exam = attempt.exam
    if exam.assessment_type != 'final_exam' or not exam.course_id or not attempt.passed:
        return
    enrollment = m.Enrollment.objects.filter(student=attempt.student, course=exam.course).first()
    if enrollment and enrollment.status != 'completed':
        enrollment.status = 'completed'
        enrollment.completed_at = timezone.now()
        enrollment.completion_source = 'final_exam'
        enrollment.save(update_fields=['status', 'completed_at', 'completion_source'])


def finalize_attempt(attempt_id, expired=False):
    """Idempotent finaliser shared by expiry processing and manual submit."""
    with transaction.atomic():
        attempt = m.Attempt.objects.select_for_update().select_related('exam', 'student', 'exam__course').get(pk=attempt_id)
        if attempt.status != 'in_progress':
            return attempt
        now = timezone.now()
        is_expired = expired or bool(attempt.deadline_at and attempt.deadline_at <= now)
        score, total, _ = grade_snapshot(attempt.question_snapshot, attempt.answers)
        percent = (score * Decimal('100') / total).quantize(Decimal('0.01')) if total else Decimal('0')
        attempt.auto_score = score
        attempt.score = score
        attempt.total_points = total
        attempt.percentage = percent
        attempt.passed = percent >= PASS_PERCENT
        attempt.status = 'expired' if is_expired else 'submitted'
        attempt.submitted_at = now
        attempt.save(update_fields=['auto_score', 'score', 'total_points', 'percentage', 'passed', 'status', 'submitted_at'])
        update_completion(attempt)
        return attempt


def finalize_expired_attempts():
    """Called at request boundaries and by the scheduled management command."""
    ids = list(m.Attempt.objects.filter(status='in_progress', deadline_at__lte=timezone.now()).values_list('id', flat=True))
    return [finalize_attempt(attempt_id, expired=True).id for attempt_id in ids]


def create_or_resume_attempt(student, exam):
    if student.role != 'student':
        raise ValidationError({'message': 'Only students can take assessments.'})
    if exam.status != 'published':
        raise ValidationError({'message': 'This assessment is not published.'})
    if exam.course_id and not get_enrollment(student, exam.course):
        raise ValidationError({'message': 'Enroll in this course before taking its assessment.'})
    eligibility = final_eligibility(student, exam)
    if not eligibility['eligible']:
        raise ValidationError({'message': ' '.join(eligibility['reasons'])})
    finalize_expired_attempts()
    with transaction.atomic():
        existing = m.Attempt.objects.select_for_update().filter(student=student, exam=exam, status='in_progress').first()
        if existing:
            return existing, False
        now = timezone.now()
        snapshot = [snapshot_question(question) for question in exam.questions.all()]
        if not snapshot:
            raise ValidationError({'message': 'This assessment has no questions.'})
        try:
            attempt = m.Attempt.objects.create(student=student, exam=exam, started_at=now,
                deadline_at=now + timedelta(seconds=FINAL_DURATION_SECONDS) if exam.assessment_type == 'final_exam' else None,
                question_snapshot=snapshot, course_snapshot={'id': exam.course_id, 'title': exam.course.title if exam.course_id else ''})
        except IntegrityError:
            # Database constraint closes the race between two concurrent final-exam starts.
            attempt = m.Attempt.objects.get(student=student, exam=exam, status='in_progress')
            return attempt, False
        return attempt, True


def get_owned_attempt(request, pk):
    attempt = get_object_or_404(m.Attempt.objects.select_related('exam', 'exam__course'), pk=pk)
    if request.user.role == 'student' and attempt.student_id != request.user.id:
        return None
    return attempt


@api_view(['GET'])
def assessments(request):
    if request.user.role != 'student':
        return fail('Only students can view assessments.', 403)
    finalize_expired_attempts()
    items = []
    for exam in student_visible_assessments(request.user):
        items.append(assessment_payload(exam, request.user))
    for exam in m.Exam.objects.filter(status='published', assessment_type='final_exam').select_related('course').prefetch_related('questions'):
        if exam.course_id and get_enrollment(request.user, exam.course):
            items.append(assessment_payload(exam, request.user))
    return Response(items)


def student_assessment_detail(request, pk):
    if request.user.role != 'student':
        return fail('Only students can view assessments.', 403)
    exam = get_object_or_404(m.Exam.objects.prefetch_related('questions'), pk=pk, status='published')
    if exam.course_id and not get_enrollment(request.user, exam.course):
        return fail('Enroll in this course before viewing this assessment.', 403)
    eligibility = final_eligibility(request.user, exam)
    if exam.assessment_type == 'final_exam' and not eligibility['eligible']:
        return fail(' '.join(eligibility['reasons']), 403)
    return Response({**assessment_payload(exam, request.user), 'questions': [public_question(question) for question in exam.questions.all()]})


@api_view(['GET'])
def assessment_detail(request, pk):
    return student_assessment_detail(request, pk)


@api_view(['POST'])
def assessment_start(request, pk):
    exam = get_object_or_404(m.Exam.objects.prefetch_related('questions').select_related('course'), pk=pk)
    try:
        attempt, created = create_or_resume_attempt(request.user, exam)
    except ValidationError as error:
        return fail(str(error.detail.get('message', error.detail)), 403)
    response = attempt_response(attempt)
    response['resumed'] = not created
    return Response(response, status=201 if created else 200)


@api_view(['GET'])
def attempt_detail(request, pk):
    finalize_expired_attempts()
    attempt = get_owned_attempt(request, pk)
    if not attempt:
        return fail('You cannot access this attempt.', 403)
    return Response(attempt_response(attempt, include_correct=request.user.role == 'admin'))


@api_view(['PUT'])
def attempt_answers(request, pk):
    finalize_expired_attempts()
    attempt = get_owned_attempt(request, pk)
    if not attempt:
        return fail('You cannot modify this attempt.', 403)
    if attempt.status != 'in_progress':
        return fail('This attempt has already been finalized.', 409)
    version = request.data.get('version')
    if version is None or to_int(version, -1) != attempt.answer_version:
        return Response({'message': 'Answers changed elsewhere. Refresh the attempt before saving.', 'answerVersion': attempt.answer_version,
                         'answers': attempt.answers}, status=409)
    updates = request.data.get('answers')
    if not isinstance(updates, dict):
        raise ValidationError({'answers': 'Must be an object keyed by question id.'})
    valid_ids = {str(question['id']) for question in attempt.question_snapshot}
    if not set(str(key) for key in updates).issubset(valid_ids):
        raise ValidationError({'answers': 'An answer references a question outside this attempt.'})
    merged = dict(attempt.answers)
    merged.update({str(key): value for key, value in updates.items()})
    attempt.answers = merged
    attempt.answer_version += 1
    attempt.save(update_fields=['answers', 'answer_version'])
    return Response({'answers': attempt.answers, 'answerVersion': attempt.answer_version, 'savedAt': timezone.now()})


@api_view(['POST'])
def attempt_submit(request, pk):
    attempt = get_owned_attempt(request, pk)
    if not attempt:
        return fail('You cannot submit this attempt.', 403)
    final = finalize_attempt(attempt.id)
    return Response(attempt_response(final, include_correct=True))


@api_view(['GET'])
def assessment_history(request, pk):
    exam = get_object_or_404(m.Exam, pk=pk)
    if request.user.role != 'student' or (exam.course_id and not get_enrollment(request.user, exam.course)):
        return fail('You cannot access this assessment history.', 403)
    attempts = m.Attempt.objects.filter(student=request.user, exam=exam).exclude(status='in_progress')
    return Response([{'id': attempt.id, 'status': attempt.status, 'score': value_number(attempt.score), 'total': value_number(attempt.total_points),
                      'percent': value_number(attempt.percentage), 'passed': attempt.passed, 'submittedAt': attempt.submitted_at}
                     for attempt in attempts])


# Compatibility API: legacy course screens keep working while now using server-side lifecycle rules.
@api_view(['GET'])
def quizzes(request):
    if request.user.role != 'student':
        return fail('Only students can view quizzes.', 403)
    return Response([{**assessment_payload(exam, request.user), 'questions': exam.questions.count(),
                      'points': sum(question.points for question in exam.questions.all())}
                     for exam in student_visible_assessments(request.user)])


@api_view(['GET'])
def quiz_detail(request, pk):
    return student_assessment_detail(request, pk)


@api_view(['POST'])
def quiz_attempt(request, pk):
    exam = get_object_or_404(m.Exam.objects.prefetch_related('questions').select_related('course'), pk=pk)
    if exam.assessment_type == 'final_exam':
        return fail('Use the final-exam start endpoint for timed final examinations.', 400)
    try:
        attempt, _ = create_or_resume_attempt(request.user, exam)
    except ValidationError as error:
        return fail(str(error.detail.get('message', error.detail)), 403)
    answers = request.data.get('answers')
    if not isinstance(answers, dict):
        raise ValidationError({'answers': 'Must be an object keyed by question id.'})
    attempt.answers = {str(key): value for key, value in answers.items()}
    attempt.answer_version += 1
    attempt.save(update_fields=['answers', 'answer_version'])
    final = finalize_attempt(attempt.id)
    response = attempt_response(final, include_correct=True)
    response.update(latest_and_best(request.user, exam))
    return Response(response, status=201)


# ───────────────────────── Student directory and analytics ─────────────────────────
def student_record(user):
    enrollments = []
    for enrollment in user.enrollments.select_related('course').all():
        summaries = course_assessment_summary(user, enrollment.course)
        enrollments.append({'courseId': enrollment.course_id, 'course': enrollment.course.title, 'percent': enrollment.percent,
                            'status': enrollment.status, 'completionSource': enrollment.completion_source, 'assessment': summaries})
    return {'id': user.id, 'name': user.display_name, 'username': user.username, 'email': user.email,
            'registeredAt': user.date_joined, 'enrollments': enrollments,
            'lastLogin': user.last_login, 'loginEvents': user.login_events.filter(event_type='login').count()}


@api_view(['GET'])
@permission_classes([IsAdminRole])
def students(request):
    query = (request.query_params.get('q') or '').strip()
    queryset = m.User.objects.filter(role='student').order_by('id')
    if query:
        queryset = queryset.filter(Q(username__icontains=query) | Q(email__icontains=query) |
                                   Q(first_name__icontains=query) | Q(last_name__icontains=query))
    status_value = request.query_params.get('status')
    if status_value in ('ongoing', 'completed'):
        queryset = queryset.filter(enrollments__status=status_value).distinct()
    page = max(to_int(request.query_params.get('page'), 1), 1)
    page_size = min(max(to_int(request.query_params.get('pageSize'), 20), 1), 100)
    total = queryset.count()
    rows = queryset[(page - 1) * page_size: page * page_size]
    return Response({'results': [student_record(user) for user in rows], 'page': page, 'pageSize': page_size, 'total': total})


@api_view(['GET'])
@permission_classes([IsAdminRole])
def student_detail(request, pk):
    student = get_object_or_404(m.User, pk=pk, role='student')
    return Response(student_record(student))


@api_view(['GET'])
@permission_classes([IsAdminRole])
def login_analytics(request):
    events = date_filter(request, m.LoginEvent.objects.select_related('user'))
    page = max(to_int(request.query_params.get('page'), 1), 1)
    page_size = min(max(to_int(request.query_params.get('pageSize'), 50), 1), 100)
    total = events.count()
    rows = events[(page - 1) * page_size: page * page_size]
    return Response({'metrics': {'registeredStudents': m.User.objects.filter(role='student').count(),
        'newRegistrations': date_filter(request, m.User.objects.filter(role='student'), 'date_joined').count(),
        'uniqueSignedIn': events.filter(event_type='login').values('user_id').distinct().count(),
        'successfulLogins': events.filter(event_type='login').count(), 'tokenRefreshes': events.filter(event_type='refresh').count()},
        'events': [{'id': event.id, 'userId': event.user_id, 'name': event.user.display_name, 'eventType': event.event_type,
                    'createdAt': event.created_at} for event in rows], 'page': page, 'pageSize': page_size, 'total': total})


@api_view(['GET'])
@permission_classes([IsAdminRole])
def exam_analytics(request):
    attempts = date_filter(request, m.Attempt.objects.select_related('exam').filter(exam__assessment_type='final_exam'))
    completed = attempts.exclude(status='in_progress')
    published = m.Exam.objects.filter(assessment_type='final_exam', status='published').count()
    passed = completed.filter(passed=True).count()
    total_completed = completed.count()
    average = completed.aggregate(value=Avg('percentage'))['value'] or Decimal('0')
    return Response({'finalExamDurationSeconds': FINAL_DURATION_SECONDS, 'metrics': {'publishedFinalExams': published,
        'totalAttempts': attempts.count(), 'inProgress': attempts.filter(status='in_progress').count(), 'completed': total_completed,
        'expired': attempts.filter(status='expired').count(), 'passed': passed, 'failed': total_completed - passed,
        'passRate': float(Decimal('100') * passed / total_completed) if total_completed else 0, 'averagePercent': value_number(average)}})


@api_view(['POST'])
@permission_classes([IsAdminRole])
def review_attempt(request, pk):
    attempt = get_object_or_404(m.Attempt.objects.select_related('exam', 'student'), pk=pk)
    if attempt.status == 'in_progress':
        return fail('An in-progress attempt cannot be reviewed.', 409)
    reason = (request.data.get('reason') or '').strip()
    if not reason:
        raise ValidationError({'reason': 'A review reason is required.'})
    revised = request.data.get('revisedScore')
    try:
        revised_score = Decimal(str(revised))
    except Exception:
        raise ValidationError({'revisedScore': 'Use a numeric score.'})
    if revised_score < 0 or revised_score > attempt.total_points:
        raise ValidationError({'revisedScore': 'Score must be between zero and the assessment total.'})
    with transaction.atomic():
        original = attempt.score
        attempt.score = revised_score
        attempt.percentage = (revised_score * Decimal('100') / attempt.total_points).quantize(Decimal('0.01')) if attempt.total_points else 0
        attempt.passed = attempt.percentage >= PASS_PERCENT
        attempt.save(update_fields=['score', 'percentage', 'passed'])
        review = m.GradingReview.objects.create(attempt=attempt, reviewer=request.user, original_score=original,
                                                 revised_score=revised_score, reason=reason,
                                                 adjustments=request.data.get('adjustments') or {})
        update_completion(attempt)
    return Response({'reviewId': review.id, 'attempt': attempt_response(attempt, include_correct=True)})


# ───────────────────────── Excel question import ─────────────────────────
def get_openpyxl():
    try:
        from openpyxl import load_workbook
        return load_workbook
    except ImportError:
        raise ValidationError({'file': 'Excel imports require the openpyxl dependency.'})


def serialise_cell(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


@api_view(['POST'])
@permission_classes([IsAdminRole])
@parser_classes([MultiPartParser])
def question_import_upload(request):
    upload = request.FILES.get('file')
    if not upload:
        raise ValidationError({'file': 'Select an .xlsx spreadsheet.'})
    if not upload.name.lower().endswith('.xlsx') or upload.size > MAX_IMPORT_BYTES:
        raise ValidationError({'file': 'Use an .xlsx file smaller than 5 MB.'})
    exam = get_object_or_404(m.Exam, pk=request.data.get('examId'))
    course_id = request.data.get('courseId')
    if course_id and str(exam.course_id or '') != str(course_id):
        raise ValidationError({'courseId': 'The selected assessment does not belong to this course.'})
    try:
        workbook = get_openpyxl()(io.BytesIO(upload.read()), read_only=True, data_only=True, keep_vba=False)
        sheets = {}
        for sheet in workbook.worksheets:
            rows = [[serialise_cell(cell) for cell in row] for row in sheet.iter_rows(values_only=True)]
            headers = [str(value).strip() if value is not None else '' for value in (rows[0] if rows else [])]
            sheets[sheet.title] = {'headers': headers, 'rows': rows[1:] if rows else []}
    except Exception:
        raise ValidationError({'file': 'The workbook could not be read as a safe .xlsx file.'})
    batch = m.QuestionImportBatch.objects.create(public_id=uuid.uuid4().hex, admin=request.user, exam=exam, workbook={'sheets': sheets})
    return Response({'batchId': batch.public_id, 'sheets': [{'name': name, 'headers': data['headers'], 'rows': len(data['rows'])}
                                                            for name, data in sheets.items()]}, status=201)


def mapped_row(headers, row, mapping):
    values = {headers[index]: row[index] if index < len(row) else None for index in range(len(headers))}
    return {field: values.get(column) for field, column in mapping.items()}


@api_view(['POST'])
@permission_classes([IsAdminRole])
def question_import_preview(request, batch_id):
    batch = get_object_or_404(m.QuestionImportBatch, public_id=batch_id, admin=request.user)
    sheet_name = request.data.get('sheet')
    mapping = request.data.get('mapping')
    sheets = batch.workbook.get('sheets', {})
    if sheet_name not in sheets or not isinstance(mapping, dict):
        raise ValidationError({'message': 'Choose a worksheet and column mapping.'})
    sheet = sheets[sheet_name]
    headers = sheet['headers']
    errors, candidates, seen = [], [], set()
    required_map = {'questionType', 'questionText', 'marks'}
    missing = [field for field in required_map if not mapping.get(field)]
    if missing:
        raise ValidationError({'mapping': 'Missing mappings: ' + ', '.join(missing)})
    for row_number, row in enumerate(sheet['rows'], start=2):
        if not any(value not in (None, '') for value in row):
            errors.append({'row': row_number, 'message': 'Empty row.'})
            continue
        source = mapped_row(headers, row, mapping)
        raw = {'questionType': source.get('questionType'), 'text': source.get('questionText'), 'options': source.get('options'),
               'correctAnswer': source.get('correctAnswer'), 'marks': source.get('marks'),
               'acceptedAlternatives': source.get('acceptedAlternatives'), 'normalization': {}}
        try:
            candidate = question_data(raw, row_number - 2)
            signature = json.dumps({'text': candidate['text'].casefold(), 'type': candidate['question_type'],
                                    'choices': candidate['choices']}, sort_keys=True)
            if signature in seen or m.Question.objects.filter(exam=batch.exam, text__iexact=candidate['text']).exists():
                raise ValidationError({'questions': f'Question {row_number}: duplicate candidate.'})
            seen.add(signature)
            candidates.append(candidate)
        except ValidationError as error:
            errors.append({'row': row_number, 'message': str(error.detail.get('questions', error.detail))})
    validation = {'sheet': sheet_name, 'headers': headers, 'candidates': candidates, 'errors': errors}
    batch.mapping, batch.validation, batch.status = mapping, validation, 'previewed'
    batch.save(update_fields=['mapping', 'validation', 'status'])
    return Response({'validCount': len(candidates), 'invalidCount': len(errors), 'preview': candidates, 'errors': errors})


@api_view(['POST'])
@permission_classes([IsAdminRole])
def question_import_confirm(request, batch_id):
    with transaction.atomic():
        batch = get_object_or_404(m.QuestionImportBatch.objects.select_for_update(), public_id=batch_id, admin=request.user)
        key = (request.data.get('idempotencyKey') or '').strip()
        if not key:
            raise ValidationError({'idempotencyKey': 'An idempotency key is required.'})
        if batch.status == 'imported':
            if key == batch.idempotency_key:
                return Response({'imported': len(batch.validation.get('candidates', [])), 'rejected': len(batch.validation.get('errors', [])), 'alreadyImported': True})
            return fail('This import batch was already confirmed.', 409)
        candidates, errors = batch.validation.get('candidates', []), batch.validation.get('errors', [])
        if batch.status != 'previewed' or errors:
            return fail('Resolve validation errors and preview again before importing.', 400)
        m.Question.objects.bulk_create([m.Question(exam=batch.exam, **candidate) for candidate in candidates])
        batch.status, batch.idempotency_key, batch.confirmed_at = 'imported', key, timezone.now()
        batch.save(update_fields=['status', 'idempotency_key', 'confirmed_at'])
    return Response({'imported': len(candidates), 'rejected': 0, 'alreadyImported': False}, status=201)


# ───────────────────────── Library, notes, calendar and profile ─────────────────────────
@api_view(['GET'])
def library(request):
    return Response([{'id': item.id, 'title': item.title, 'subject': item.subject, 'cover': abs_url(request, item.cover),
                      'fileUrl': abs_url(request, item.file) or '#'} for item in m.LibraryItem.objects.all()])


NOTES_APPS = [
    {'id': 'drive', 'name': 'Google Drive', 'url': 'https://drive.google.com', 'color': '#34a853'},
    {'id': 'lens', 'name': 'Google Lens', 'url': 'https://lens.google.com', 'color': '#4285f4'},
    {'id': 'excel', 'name': 'Excel', 'url': 'https://www.office.com/launch/excel', 'color': '#107c41'},
    {'id': 'doc', 'name': 'Google Doc', 'url': 'https://docs.google.com', 'color': '#4285f4'},
    {'id': 'word', 'name': 'Word', 'url': 'https://www.office.com/launch/word', 'color': '#2b579a'},
    {'id': 'ppt', 'name': 'Power point', 'url': 'https://www.office.com/launch/powerpoint', 'color': '#d24726'},
]


@api_view(['GET'])
def notes_apps(request):
    return Response(NOTES_APPS)


@api_view(['GET', 'POST'])
def calendar_view(request):
    if request.method == 'POST':
        data = request.data
        if not data.get('date') or not data.get('title'):
            raise ValidationError({'message': 'date and title are required.'})
        event = m.CalendarEvent.objects.create(user=request.user, date=data['date'], title=data['title'], time=data.get('time', ''), type=data.get('type', 'event'))
        return Response({'id': event.id, 'date': str(event.date), 'title': event.title, 'type': event.type}, status=201)
    today = date.today()
    year, month = to_int(request.query_params.get('year'), today.year), to_int(request.query_params.get('month'), today.month)
    if not 1 <= month <= 12:
        raise ValidationError({'month': 'Must be 1-12.'})
    mine = m.CalendarEvent.objects.filter(Q(user__isnull=True) | Q(user=request.user))
    events = mine.filter(date__year=year, date__month=month)
    day = today if (today.year, today.month) == (year, month) else date(year, month, 1)
    day_events = mine.filter(date=day).exclude(time='')
    return Response({'year': year, 'monthIndex': month - 1, 'events': [{'id': event.id, 'date': str(event.date), 'title': event.title, 'type': event.type} for event in events],
                     'daySchedule': {'date': f'{cal.month_name[month]} {day.day}, {cal.day_name[day.weekday()]}',
                                     'items': [{'time': event.time, 'title': event.title} for event in day_events]}})


PROFILE_FIELDS = {'username': 'username', 'email': 'email', 'firstName': 'first_name', 'lastName': 'last_name', 'address': 'address', 'city': 'city', 'country': 'country', 'postalCode': 'postal_code'}


@api_view(['GET', 'PUT'])
def profile(request):
    user = request.user
    if request.method == 'PUT':
        if 'username' in request.data and m.User.objects.exclude(pk=user.pk).filter(username=request.data['username']).exists():
            raise ValidationError({'username': 'This username is taken.'})
        for js_name, model_field in PROFILE_FIELDS.items():
            if js_name in request.data:
                setattr(user, model_field, request.data[js_name])
        user.save()
    return Response(user_json(user, request))


@api_view(['POST'])
@parser_classes([MultiPartParser])
def profile_avatar(request):
    upload = request.FILES.get('avatar')
    if not upload:
        raise ValidationError({'avatar': 'No file uploaded.'})
    request.user.avatar = upload
    request.user.save(update_fields=['avatar'])
    return Response({'url': abs_url(request, request.user.avatar)})
