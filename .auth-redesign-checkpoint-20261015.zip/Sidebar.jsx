import { NavLink } from 'react-router-dom'
import Logo from '../ui/Logo'
import { useAuth } from '../../context/AuthContext'
import * as I from '../ui/Icons'

const studentNav = [
  { to: '/student/dashboard', label: 'Dashboard', icon: I.DashboardIcon },
  { to: '/student/courses', label: 'Courses', icon: I.StarIcon },
  { to: '/student/calendar', label: 'Calender', icon: I.CalendarIcon },
  { to: '/student/notes', label: 'Notes', icon: I.NotesIcon },
  { to: '/student/quizzes', label: 'Quizzes', icon: I.QuizIcon },
  { to: '/student/library', label: 'Library', icon: I.LibraryIcon },
]
const adminNav = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: I.DashboardIcon },
  { to: '/admin/courses', label: 'Courses', icon: I.StarIcon },
  { to: '/admin/course-creation', label: 'Course Creation', icon: I.CalendarIcon },
  { to: '/admin/exams', label: 'Exams', icon: I.NotesIcon },
  { to: '/admin/students', label: 'Students', icon: I.QuizIcon },
  { to: '/admin/analytics', label: 'Analytics', icon: I.CalendarIcon },
  { to: '/admin/question-import', label: 'Question Import', icon: I.NotesIcon },
  { to: '/admin/library', label: 'Library', icon: I.LibraryIcon },
]

// The menu itself – used by the desktop sidebar and by the mobile/tablet drawer.
export function NavLinks() {
  const { user, logout } = useAuth()
  const items = user?.role === 'admin' ? adminNav : studentNav
  return (
    <>
      <nav aria-label="Main" className="mt-6 flex flex-1 flex-col lg:mt-10">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to}
            className={({ isActive }) => `flex items-center gap-5 px-6 py-3 text-base font-bold text-brand transition lg:px-8 ${isActive ? 'bg-nav opacity-90' : 'hover:bg-brand-soft/60'}`}>
            <Icon className="h-7 w-7 shrink-0" /><span>{label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="mt-6 flex flex-col text-base font-bold text-ink-nav">
        <button className="flex items-center gap-5 px-6 py-3 text-left hover:bg-surface-muted lg:px-8"><I.HelpIcon className="h-7 w-7 text-gray-500" />Help</button>
        <NavLink to={user?.role === 'admin' ? '/admin/profile' : '/student/profile'} className="flex items-center gap-5 px-6 py-3 hover:bg-surface-muted lg:px-8"><I.SettingIcon className="h-7 w-7 text-gray-500" />Setting</NavLink>
        <button onClick={logout} className="flex items-center gap-5 px-6 py-3 text-left hover:bg-surface-muted lg:px-8"><I.LogoutIcon className="h-7 w-7 text-gray-500" />Log out</button>
      </div>
    </>
  )
}

// Desktop sidebar: only from the `lg` breakpoint (>=1024px). Below that the MobileNav drawer is used.
export default function Sidebar() {
  return (
    <aside className="card sticky top-0 hidden h-screen w-60 shrink-0 flex-col overflow-y-auto rounded-l-none py-6 lg:flex">
      <div className="px-8"><Logo className="text-[15px]" /></div>
      <NavLinks />
    </aside>
  )
}
