import { Link } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import Avatar from '../ui/Avatar'
import { SearchIcon, BellIcon, MailIcon, ChevronDown } from '../ui/Icons'

// Page header. Mobile: [Title ........ bell mail] / [search – full width].  Desktop: [Title][search][bell mail] ... [profile]
// (below lg the profile lives in the MobileNav top bar, so it is hidden here)
export default function Topbar({ title, onSearch, showProfile = true }) {
  const { user } = useAuth()
  return (
    <header className="flex flex-wrap items-center gap-x-4 gap-y-3 px-1 py-3 lg:px-2">
      <h1 className="text-2xl font-bold sm:text-3xl">{title}</h1>
      <div className="order-2 ml-auto flex items-center gap-4 text-gray-600 lg:ml-0">
        <button aria-label="Notifications" className="p-1"><BellIcon className="h-6 w-6" /></button>
        <button aria-label="Messages" className="p-1"><MailIcon className="h-6 w-6" /></button>
      </div>
      <label className="relative order-3 w-full lg:order-1 lg:ml-2 lg:min-w-[240px] lg:max-w-md lg:flex-1">
        <span className="sr-only">Search</span>
        <SearchIcon className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500" />
        <input placeholder="Search" onChange={(e) => onSearch?.(e.target.value)}
          className="w-full rounded-lg bg-surface py-2.5 pl-10 pr-3 text-sm font-bold shadow-sm outline-none placeholder:text-black/40 focus:ring-2 focus:ring-brand/40" />
      </label>
      {showProfile && user && (
        <Link to={user.role === 'admin' ? '/admin/profile' : '/student/profile'} className="order-4 ml-auto hidden items-center gap-3 lg:flex">
          <Avatar src={user.avatar} name={user.name} size={56} />
          <div className="leading-tight"><p className="text-sm font-bold">{user.name}</p><p className="text-xs capitalize text-ink-soft">{user.role}</p></div>
          <ChevronDown className="h-4 w-4" />
        </Link>
      )}
    </header>
  )
}
