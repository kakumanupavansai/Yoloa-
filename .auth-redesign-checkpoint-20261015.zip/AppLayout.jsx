import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import MobileNav from './MobileNav'

// Shell for every authenticated page.
//  >= 1024px : fixed sidebar on the left
//  <  1024px : sticky top bar with a slide-in menu (MobileNav)
export default function AppLayout() {
  return (
    <div className="min-h-screen lg:flex">
      <Sidebar />
      <div className="min-w-0 flex-1">
        <MobileNav />
        <main className="px-3 pb-8 sm:px-4 lg:px-6"><Outlet /></main>
      </div>
    </div>
  )
}
