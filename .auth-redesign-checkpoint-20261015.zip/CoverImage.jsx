// Shows `src` if provided by backend; otherwise a gradient placeholder with the title.
export default function CoverImage({ src, title, accent = 'from-fuchsia-500 to-indigo-700', className = '' }) {
  if (src) return <img src={src} alt={title} className={`object-cover ${className}`} />
  return (
    <div className={`flex items-center justify-center bg-gradient-to-br p-3 text-center text-lg font-bold text-white/90 ${accent} ${className}`}>{title}</div>
  )
}
