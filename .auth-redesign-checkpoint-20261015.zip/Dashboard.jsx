import { useApi } from '../../hooks'
import { dashboardApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import RightPanel from '../../components/layout/RightPanel'
import Avatar from '../../components/ui/Avatar'
import ProgressBar from '../../components/ui/ProgressBar'
import { Async } from '../../components/ui/States'

const rowColors = ['bg-pastel-green', 'bg-pastel-pink', 'bg-pastel-blue', 'bg-pastel-yellow']

// Figma: Desktop - 3
export default function StudentDashboard() {
  const state = useApi(() => dashboardApi.student(), [])
  return (
    <Async state={state}>{(d) => (
      <div className="flex flex-col gap-4 xl:flex-row">
        <div className="min-w-0 flex-1">
          <Topbar title="Dashboard" showProfile={false} />
          <section className="card mt-2 p-4">
            <h2 className="text-xl font-bold">Announcement</h2>
            <p className="mt-2 rounded-[20px] bg-brand-soft py-3 text-center">{d.announcement}</p>
          </section>
          <div className="mt-5 grid gap-5 lg:grid-cols-2">
            <section className="card p-4">
              <h2 className="text-xl font-bold">Leader board</h2>
              <ul className="mt-3 max-h-[330px] space-y-3 overflow-y-auto scroll-thin pr-2">
                {d.leaderboard.map((l, i) => (
                  <li key={l.id} className={`flex items-center gap-4 rounded-[10px] px-4 py-3 ${rowColors[i % 4]}`}>
                    <Avatar src={l.avatar} name={l.name} size={48} />
                    <div className="mx-auto text-center"><p className="text-sm font-bold">{l.name}</p><p className="text-xs text-ink-soft">Score {l.score}</p></div>
                  </li>))}
              </ul>
            </section>
            <section className="card bg-white p-4">
              <h2 className="text-xl font-bold">Completion progress</h2>
              <ul className="mt-3 max-h-[330px] space-y-3 overflow-y-auto scroll-thin pr-2">
                {d.completion.map((c) => (
                  <li key={c.id} className="flex items-center justify-between rounded-[10px] bg-surface-muted px-4 py-3">
                    <div><p className="text-sm font-bold">{c.title}</p><p className="text-xs text-ink-soft">{c.chapter}</p></div>
                    <ProgressBar percent={c.percent} />
                  </li>))}
              </ul>
            </section>
          </div>
          <section className="card mt-5 p-4 sm:p-6">
            <h2 className="text-xl font-bold">Assignments</h2>
            {d.assignments.map((a) => (
              <div key={a.id} className="mt-4 grid grid-cols-2 items-center gap-y-2 rounded-[10px] border border-[#6d88ce] bg-surface-muted px-4 py-3 shadow-row md:grid-cols-4 md:px-10">
                <div><p className="text-sm font-bold">{a.subject}</p><p className="text-xs text-ink-soft">{a.chapter}</p></div>
                <div className="text-right md:text-center"><p className="text-sm font-bold">{a.title}</p><p className="text-xs text-ink-soft">{a.page}</p></div>
                <p className="text-left text-xs font-bold md:text-center">{a.time}</p>
                <p className="text-right text-sm font-bold text-accent-orange">{a.status}</p>
              </div>))}
          </section>
        </div>
        <RightPanel schedule={d.schedule} events={d.upcomingEvents} />
      </div>)}
    </Async>
  )
}
