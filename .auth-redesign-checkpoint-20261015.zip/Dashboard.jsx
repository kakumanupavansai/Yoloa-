import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApi } from '../../hooks'
import { dashboardApi, coursesApi, announcementsApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import RightPanel from '../../components/layout/RightPanel'
import Avatar from '../../components/ui/Avatar'
import CoverImage from '../../components/ui/CoverImage'
import { Async } from '../../components/ui/States'

// Figma: Desktop - 19
export default function AdminDashboard() {
  const state = useApi(() => dashboardApi.admin(), [])
  const courses = useApi(() => coursesApi.list(), [])
  const [text, setText] = useState('')
  const [adding, setAdding] = useState(false)

  const addAnnouncement = async () => {
    if (!text.trim()) return
    await announcementsApi.create({ text }); setText(''); setAdding(false); state.reload()
  }
  return (
    <Async state={state}>{(d) => (
      <div className="flex flex-col gap-4 xl:flex-row">
        <div className="min-w-0 flex-1">
          <Topbar title="Courses" showProfile={false} />
          <section className="card mt-2 rounded-[10px] p-5">
            <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="text-xl font-bold">Announcements</h2>
              <button onClick={() => setAdding(!adding)} className="rounded-lg border border-black bg-white px-5 py-2 text-sm font-bold">Add Announcements</button></div>
            {adding && <div className="mt-3 flex gap-2"><input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Write an announcement…" /><button onClick={addAnnouncement} className="btn-primary">Post</button></div>}
            {d.announcements.map((a) => (
              <div key={a.id} className="mt-4 flex flex-wrap items-center gap-4 rounded-[20px] bg-surface-line px-4 py-4 sm:gap-8 sm:px-10">
                <Avatar src={a.avatar} name={a.author} size={68} />
                <div className="min-w-[8rem] flex-1"><p className="font-bold">{a.author}</p><p className="text-sm">{a.text}</p></div>
                <span className="text-xl font-bold">{a.time}</span>
              </div>))}
          </section>
          <section className="card mt-4 rounded-[10px] p-5">
            <div className="flex items-center justify-between"><h2 className="text-xl font-bold">Published courses</h2><Link to="/admin/courses" className="text-sm font-bold">See all</Link></div>
            <div className="mt-4 grid gap-5 sm:grid-cols-2">
              {(courses.data || []).slice(0, 2).map((c) => (
                <Link key={c.id} to={`/admin/courses/${c.id}`} className="rounded-[20px] bg-surface p-1 shadow-panel">
                  <CoverImage src={c.cover} title={c.title.split(' ')[0]} accent={c.accent} className="h-44 w-full rounded-[20px]" />
                  <div className="p-4"><p className="text-sm font-bold text-ink-soft">{c.title}</p><p className="text-sm text-ink-soft">{c.enrollment}</p></div>
                </Link>))}
            </div>
          </section>
          <section className="card mt-4 rounded-[10px] p-5">
            <h2 className="font-bold">Course Registered</h2>
            <div className="mt-3 flex flex-wrap gap-4 sm:gap-10">
              {[['Total no. of students', d.stats.total], ['Absent', d.stats.absent], ['Present', d.stats.present]].map(([l, n]) => (
                <div key={l} className="w-32 rounded-[10px] border border-gray-400 bg-surface p-3"><p className="font-bold">{n}</p><p className="mt-2 text-sm text-ink-soft">{l}</p></div>))}
            </div>
          </section>
        </div>
        <RightPanel registered={d.stats} events={d.upcomingEvents} />
      </div>)}
    </Async>
  )
}
