import { useState } from 'react'
import { useApi } from '../../hooks'
import { libraryApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import CoverImage from '../../components/ui/CoverImage'
import { DownloadIcon } from '../../components/ui/Icons'
import { Async } from '../../components/ui/States'

const accents = ['from-blue-900 to-slate-900', 'from-indigo-400 to-sky-600', 'from-emerald-700 to-teal-900', 'from-blue-700 to-indigo-900', 'from-sky-500 to-blue-700', 'from-green-600 to-emerald-900', 'from-sky-300 to-blue-500', 'from-orange-300 to-rose-400']

// Figma: Desktop - 13
export default function Library() {
  const state = useApi(() => libraryApi.list(), [])
  const [q, setQ] = useState('')
  return (
    <>
      <Topbar title="Library" onSearch={setQ} />
      <Async state={state}>{(books) => (
        <section className="mt-2 grid grid-cols-2 gap-4 rounded-[10px] bg-white p-3 shadow-panel sm:grid-cols-3 sm:gap-6 sm:p-6 lg:grid-cols-4">
          {books.filter((b) => `${b.title} ${b.subject}`.toLowerCase().includes(q.toLowerCase())).map((b, i) => (
            <figure key={b.id}>
              <CoverImage src={b.cover} title={b.title} accent={accents[i % accents.length]} className="aspect-[3/4] w-full" />
              <figcaption className="mt-1 flex items-center justify-between text-sm font-bold">
                <span>{b.subject}</span>
                <a href={b.fileUrl} download aria-label={`Download ${b.title}`} className="text-blue-600"><DownloadIcon className="h-5 w-5" /></a>
              </figcaption>
            </figure>))}
        </section>)}
      </Async>
    </>
  )
}
