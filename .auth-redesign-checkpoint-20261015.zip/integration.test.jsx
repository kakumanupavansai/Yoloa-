// Runs the real UI against the real Django API. Skipped in mock mode.
//   (backend)  python manage.py migrate && python manage.py seed && python manage.py runserver
//   (frontend) VITE_USE_MOCK=false VITE_API_URL=http://localhost:8000/api npm test
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { beforeAll, describe, expect, it } from 'vitest'
import App from '../App'
import { AuthProvider } from '../context/AuthContext'
import { authApi, examsApi } from '../services/api'
import { tokenStore } from '../services/http'

const LIVE = String(import.meta.env.VITE_USE_MOCK) === 'false'
const open = (path) => render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>)

describe.skipIf(!LIVE)('live backend', () => {
  beforeAll(async () => {
    // Use an otherwise un-enrolled demo student so the progress flow remains repeatable.
    const { token } = await authApi.login({ username: 'shyam', password: 'student123', role: 'student' })
    tokenStore.set(token); localStorage.setItem('yoloa_role', 'student')
  })

  it('enroll → player → mark chapters complete → final exam remains required', async () => {
    const user = userEvent.setup()
    const courseRows = await (await fetch(`${import.meta.env.VITE_API_URL}/courses`, { headers: { Authorization: `Bearer ${tokenStore.get()}` } })).json()
    const social = courseRows.find((course) => /Social science Department/i.test(course.title))
    expect(social).toBeTruthy()
    // Keep this live check repeatable when a previous run left progress behind.
    await fetch(`${import.meta.env.VITE_API_URL}/courses/${social.id}/enroll`, { method: 'POST', headers: { Authorization: `Bearer ${tokenStore.get()}` } })
    const detail = await (await fetch(`${import.meta.env.VITE_API_URL}/courses/${social.id}`, { headers: { Authorization: `Bearer ${tokenStore.get()}` } })).json()
    for (const chapter of detail.chapters || []) {
      await fetch(`${import.meta.env.VITE_API_URL}/chapters/${chapter.id}/progress`, { method: 'PUT', headers: { Authorization: `Bearer ${tokenStore.get()}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ completed: false }) })
    }
    await fetch(`${import.meta.env.VITE_API_URL}/courses/${social.id}/enroll`, { method: 'DELETE', headers: { Authorization: `Bearer ${tokenStore.get()}` } })
    open('/student/courses')
    const socialCard = (await screen.findByText('Social science Department')).closest('article')
    await user.click(within(socialCard).getByRole('button', { name: 'Enroll' }))
    await waitFor(() => expect(screen.getAllByRole('link', { name: /resume|review/i }).length).toBeGreaterThan(0), { timeout: 4000 })

    // Open the seeded Social science player using its current database id.
    document.body.innerHTML = ''
    open(`/student/courses/${social.id}/watch`)
    await screen.findByRole('heading', { name: /Social chapter 1/i })
    const player = await (await fetch(`${import.meta.env.VITE_API_URL}/courses/${social.id}/player`, { headers: { Authorization: `Bearer ${tokenStore.get()}` } })).json()
    for (const chapter of player.modules) {
      await fetch(`${import.meta.env.VITE_API_URL}/chapters/${chapter.id}/progress`, { method: 'PUT', headers: { Authorization: `Bearer ${tokenStore.get()}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ completed: true }) })
    }
    const afterProgress = await (await fetch(`${import.meta.env.VITE_API_URL}/courses/${social.id}`, { headers: { Authorization: `Bearer ${tokenStore.get()}` } })).json()
    expect(afterProgress.percent).toBe(100)
    expect(afterProgress.status).toBe('ongoing')
  })

  it('quiz: start → answer all → real server scoring + review', async () => {
    const user = userEvent.setup()
    open('/student/quizzes/1?start=1')
    for (let i = 0; i < 10; i++) {
      await screen.findByText(`Question ${i + 1} of 10`, { exact: false })
      await user.click(screen.getAllByRole('radio')[0]) // seed: correct answer is always A
      if (i < 9) await user.click(screen.getByRole('button', { name: /next →/i }))
    }
    await user.click(screen.getByRole('button', { name: /submit quiz/i }))
    expect(await screen.findByText('Review your answers')).toBeInTheDocument()
    expect(screen.getByText(/100% · Well done!/)).toBeInTheDocument()
  })

  it('not-enrolled player shows the server 403 message (admin-created course not joined)', async () => {
    const courseRows = await (await fetch(`${import.meta.env.VITE_API_URL}/courses`, { headers: { Authorization: `Bearer ${tokenStore.get()}` } })).json()
    const social = courseRows.find((course) => /Social science Department/i.test(course.title))
    await fetch(`${import.meta.env.VITE_API_URL}/courses/${social.id}/enroll`, { method: 'DELETE', headers: { Authorization: `Bearer ${tokenStore.get()}` } })
    open(`/student/courses/${social.id}/watch`)
    expect(await screen.findByText(/Enroll in this course to start learning/i)).toBeInTheDocument()
  })
})

describe.skipIf(!LIVE)('live backend – admin deletes', () => {
  beforeAll(async () => {
    const { token } = await authApi.login({ username: 'admin', password: 'admin123', role: 'admin' })
    tokenStore.set(token); localStorage.setItem('yoloa_role', 'admin')
    window.confirm = () => true
  })

  it('admin deletes a course from the Courses page (real DELETE /courses/:id)', async () => {
    const user = userEvent.setup()
    open('/admin/courses')
    await screen.findByText('English Department')
    await user.click(screen.getByRole('button', { name: /delete course english department/i }))
    await waitFor(() => expect(screen.queryByText('English Department')).not.toBeInTheDocument(), { timeout: 4000 })
    expect(screen.getByRole('button', { name: /all courses \(5\)/i })).toBeInTheDocument()
  })

  it('admin can delete a draft exam without assessment history', async () => {
    const user = userEvent.setup()
    document.body.innerHTML = ''
    open('/admin/exams')
    await screen.findByText('Botany')
    await user.click(screen.getByRole('button', { name: /delete Final exam Botany/i }))
    await waitFor(() => expect(screen.queryByText('Botany')).not.toBeInTheDocument(), { timeout: 4000 })
    expect(screen.getByText('Physics')).toBeInTheDocument()
  })
})

describe.skipIf(!LIVE)('live backend – exam ⇄ quiz link + dashboard', () => {
  const loginAs = async (username, password, role) => {
    const { token } = await authApi.login({ username, password, role })
    tokenStore.set(token); localStorage.setItem('yoloa_role', role)
  }

  it('an exam the admin publishes is a quiz for the student; a draft is not', async () => {
    await loginAs('admin', 'admin123', 'admin')
    const suffix = Date.now()
    const liveTitle = `Live Link Test ${suffix}`
    const draftTitle = `Hidden Draft ${suffix}`
    const q = [{ text: 'Capital of France?', choices: ['Paris', 'Rome', 'Oslo', 'Lima'], correct: 0, points: 2 }]
    await examsApi.create({ title: liveTitle, subject: 'Geography', duration: '10 mins', status: 'published', questions: q })
    await examsApi.create({ title: draftTitle, subject: 'Geography', duration: '10 mins', status: 'draft', questions: q })
    await expect(examsApi.create({ title: 'Bad', status: 'published', questions: [] })).rejects.toThrow(/at least one question/)

    await loginAs('swetha', 'student123', 'student')
    document.body.innerHTML = ''
    open('/student/quizzes')
    expect(await screen.findByText(liveTitle)).toBeInTheDocument()
    expect(screen.getAllByText('Geography').length).toBeGreaterThan(0)
    expect(screen.queryByText(draftTitle)).not.toBeInTheDocument()
  })

  it('admin dashboard shows registered students (not the schedule)', async () => {
    await loginAs('admin', 'admin123', 'admin')
    document.body.innerHTML = ''
    open('/admin/dashboard')
    expect(await screen.findByTestId('students-registered')).toHaveTextContent('5')
    expect(screen.getByText('Enrolled in a course')).toBeInTheDocument()
    expect(screen.queryByRole('heading', { name: 'Schedule' })).not.toBeInTheDocument()
  })
})
