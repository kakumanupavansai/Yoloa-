import { useApi } from '../../hooks'
import { notesApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'

// Figma: Desktop - 7  (external app launchers; swap for real note CRUD later)
export default function Notes() {
  const state = useApi(() => notesApi.apps(), [])
  return (
    <>
      <Topbar title="Notes" />
      <Async state={state}>{(apps) => (
        <section className="card mt-2 grid grid-cols-2 gap-3 rounded-[10px] p-3 sm:gap-6 sm:p-8 lg:grid-cols-3">
          {apps.map((a) => (
            <a key={a.id} href={a.url} target="_blank" rel="noreferrer"
              className="flex h-40 flex-col items-center justify-center gap-4 sm:h-64 sm:gap-8 rounded-[10px] bg-[#e7e1e1] transition hover:shadow-panel">
              <span className="flex h-14 w-14 items-center justify-center rounded-xl text-2xl font-black sm:h-20 sm:w-20 sm:text-4xl text-white" style={{ background: a.color }}>{a.name.split(' ').pop()[0]}</span>
              <span className="text-center text-base font-bold sm:text-xl">{a.name}</span>
            </a>))}
        </section>)}
      </Async>
    </>
  )
}
