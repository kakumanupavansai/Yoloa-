// Turn a YouTube watch/share URL into an embeddable one; other URLs are returned unchanged.
export function toEmbedUrl(url = '') {
  if (!url) return ''
  const m = url.match(/(?:youtube\.com\/watch\?(?:.*&)?v=|youtu\.be\/|youtube\.com\/embed\/)([\w-]{11})/)
  return m ? `https://www.youtube.com/embed/${m[1]}` : url
}
export const fmtTime = (secs) => `${String(Math.floor(secs / 60)).padStart(2, '0')}:${String(secs % 60).padStart(2, '0')}`
