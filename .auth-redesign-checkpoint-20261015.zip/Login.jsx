import { useState } from 'react'
import { useNavigate, useSearchParams, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import Logo from '../components/ui/Logo'
import HeroArt from '../components/ui/HeroArt'

// Figma: Desktop - 2
export default function Login() {
  const [params] = useSearchParams()
  const role = params.get('role') === 'admin' ? 'admin' : 'student'
  const { login, mock } = useAuth()
  const nav = useNavigate()
  const [form, setForm] = useState({ username: '', password: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault(); setError(''); setBusy(true)
    try { const u = await login({ ...form, role }); nav(u.role === 'admin' ? '/admin/dashboard' : '/student/dashboard', { replace: true }) }
    catch (err) { setError(err.message || 'Login failed') }
    finally { setBusy(false) }
  }

  return (
    <div className="relative grid min-h-screen overflow-hidden bg-gradient-to-b from-white to-[#e9e9e9] md:grid-cols-2">
      <div className="absolute inset-y-0 right-0 hidden w-[62%] bg-hero md:block" style={{ borderTopLeftRadius: '50% 100%', borderBottomLeftRadius: '50% 100%' }} />
      <form onSubmit={submit} className="relative mx-auto flex w-full max-w-md flex-col justify-center gap-4 px-6 py-10 sm:px-8">
        <Logo className="mb-8 text-[28px]" />
        <p className="text-sm font-bold capitalize text-brand-dark">{role} sign in <Link to="/" className="ml-2 font-normal underline">change</Link></p>
        <label className="relative block rounded-lg border border-black bg-surface px-4 pb-2 pt-5">
          <span className="absolute left-4 top-1.5 text-sm font-bold text-gray-500">username</span>
          <input className="w-full bg-transparent outline-none" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} autoComplete="username" />
        </label>
        <label className="relative block rounded-lg border border-black bg-surface px-4 pb-2 pt-5">
          <span className="absolute left-4 top-1.5 text-sm font-bold text-gray-500">Password</span>
          <input type="password" className="w-full bg-transparent outline-none" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} autoComplete="current-password" />
        </label>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button disabled={busy} className="mt-4 rounded-lg border border-black bg-brand-dark py-4 text-sm font-bold text-white hover:opacity-90 disabled:opacity-60">{busy ? 'Signing in…' : 'Sign in'}</button>
        {mock && <p className="text-xs text-gray-500">Mock mode: any username/password works.</p>}
      </form>
      <div className="relative hidden md:block"><HeroArt /></div>
    </div>
  )
}
