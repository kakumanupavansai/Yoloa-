import { useApi } from '../../hooks'
import { adminApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'

const Metric = ({ label, value }) => <div className="rounded-lg border bg-surface-muted p-4"><p className="text-2xl font-bold">{value}</p><p className="mt-1 text-xs text-gray-600">{label}</p></div>

export default function Analytics() {
  const logins = useApi(() => adminApi.loginAnalytics(), [])
  const exams = useApi(() => adminApi.examAnalytics(), [])
  return <><Topbar title="Analytics" /><div className="mt-2 grid gap-5 xl:grid-cols-2"><Async state={logins}>{(data) => <section className="card p-5"><h2 className="text-xl font-bold">Login analytics</h2><div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3"><Metric label="Registered students" value={data.metrics.registeredStudents} /><Metric label="New registrations" value={data.metrics.newRegistrations} /><Metric label="Unique signed in" value={data.metrics.uniqueSignedIn} /><Metric label="Successful sign-ins" value={data.metrics.successfulLogins} /><Metric label="Token refreshes" value={data.metrics.tokenRefreshes} /></div></section>}</Async><Async state={exams}>{(data) => <section className="card p-5"><div className="flex flex-wrap items-baseline justify-between gap-2"><h2 className="text-xl font-bold">Examination overview</h2><span className="text-sm text-gray-500">Final exam duration: {Math.round(data.finalExamDurationSeconds / 60)} minutes</span></div><div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3"><Metric label="Published final exams" value={data.metrics.publishedFinalExams} /><Metric label="Total attempts" value={data.metrics.totalAttempts} /><Metric label="In progress" value={data.metrics.inProgress} /><Metric label="Completed" value={data.metrics.completed} /><Metric label="Expired" value={data.metrics.expired} /><Metric label="Pass rate" value={`${Math.round(data.metrics.passRate)}%`} /><Metric label="Average score" value={`${Math.round(data.metrics.averagePercent)}%`} /></div></section>}</Async></div></>
}
