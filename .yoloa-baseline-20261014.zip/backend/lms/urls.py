from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from . import views as v

urlpatterns = [
    path('auth/login', v.login),
    path('auth/refresh', TokenRefreshView.as_view()),
    path('auth/me', v.me),

    path('student/dashboard', v.student_dashboard),
    path('admin/dashboard', v.admin_dashboard),
    path('announcements', v.announcements),

    path('courses', v.courses),
    path('courses/<int:pk>', v.course_detail),
    path('courses/<int:pk>/player', v.course_player),
    path('courses/<int:pk>/enroll', v.course_enroll),
    path('chapters/<int:pk>/progress', v.chapter_progress),

    path('quizzes', v.quizzes),
    path('quizzes/<int:pk>', v.quiz_detail),
    path('quizzes/<int:pk>/attempts', v.quiz_attempt),

    path('exams', v.exams),
    path('exams/<int:pk>', v.exam_detail),

    path('library', v.library),
    path('notes/apps', v.notes_apps),
    path('calendar', v.calendar_view),

    path('profile', v.profile),
    path('profile/avatar', v.profile_avatar),
]
