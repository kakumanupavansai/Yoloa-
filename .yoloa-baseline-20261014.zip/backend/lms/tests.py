from django.core.management import call_command
from rest_framework.test import APITestCase

from lms import models as m


class ApiSmokeTests(APITestCase):
    @classmethod
    def setUpTestData(cls):
        call_command('seed', verbosity=0)

    def login(self, username, password, role):
        r = self.client.post('/api/auth/login', {'username': username, 'password': password, 'role': role}, format='json')
        self.assertEqual(r.status_code, 200, r.content)
        self.client.credentials(HTTP_AUTHORIZATION='Bearer ' + r.data['token'])
        return r.data

    def test_login_failures(self):
        r = self.client.post('/api/auth/login', {'username': 'swetha', 'password': 'bad', 'role': 'student'}, format='json')
        self.assertEqual(r.status_code, 401); self.assertIn('message', r.data)
        r = self.client.post('/api/auth/login', {'username': 'swetha', 'password': 'student123', 'role': 'admin'}, format='json')
        self.assertEqual(r.status_code, 403)

    def test_requires_auth(self):
        self.assertEqual(self.client.get('/api/courses').status_code, 401)

    def test_student_flow(self):
        d = self.login('swetha', 'student123', 'student')
        self.assertEqual(d['user']['name'], 'Swetha Shankaresh')
        dash = self.client.get('/api/student/dashboard').data
        self.assertEqual([x['score'] for x in dash['leaderboard']], [60, 58, 50, 49])
        self.assertTrue(dash['completion'] and dash['schedule'] and dash['assignments'] and dash['upcomingEvents'])
        cs = self.client.get('/api/courses').data
        self.assertEqual(len(cs), 6); self.assertEqual({c['status'] for c in cs}, {'ongoing', 'completed', 'available'})
        cid = cs[1]['id']
        det = self.client.get(f'/api/courses/{cid}').data
        self.assertEqual(len(det['content']), 3); self.assertTrue(det['progress'])
        self.assertEqual(len(self.client.get(f'/api/courses/{cid}/player').data['modules']), 6)
        qz = self.client.get('/api/quizzes').data
        self.assertEqual(len(qz), 5); self.assertEqual(qz[0]['questions'], 10)   # 4 practice tests + the published Maths exam
        qd = self.client.get(f"/api/quizzes/{qz[0]['id']}").data
        self.assertNotIn('correct', qd['questions'][0])
        ans = {str(q['id']): 0 for q in qd['questions']}
        r = self.client.post(f"/api/quizzes/{qz[0]['id']}/attempts", {'answers': ans}, format='json')
        self.assertEqual(r.data['score'], 10); self.assertEqual(len(r.data['review']), 10); self.assertTrue(r.data['review'][0]['isCorrect'])
        self.assertEqual(len(self.client.get('/api/library').data), 8)
        self.assertEqual(len(self.client.get('/api/notes/apps').data), 6)
        cal = self.client.get('/api/calendar?year=2023&month=11').data
        self.assertEqual(len(cal['events']), 4)
        p = self.client.put('/api/profile', {'city': 'Guntur', 'firstName': 'Swetha'}, format='json').data
        self.assertEqual(p['city'], 'Guntur')
        # the exam builder (which contains correct answers) is admin-only
        self.assertEqual(self.client.get('/api/exams').status_code, 403)
        self.assertEqual(self.client.get('/api/exams/1').status_code, 403)
        self.assertEqual(self.client.post('/api/exams', {'title': 'x'}, format='json').status_code, 403)
        self.assertEqual(self.client.get('/api/admin/dashboard').status_code, 403)

    def test_admin_flow(self):
        self.login('admin', 'admin123', 'admin')
        ad = self.client.get('/api/admin/dashboard').data
        self.assertEqual(ad['stats']['total'], 5); self.assertTrue(ad['announcements'])
        self.assertEqual((ad['stats']['newThisWeek'], ad['stats']['enrolled']), (5, 1))   # 5 students registered, only swetha enrolled
        self.assertNotIn('schedule', ad)
        self.assertEqual(self.client.post('/api/announcements', {'text': 'Hi all'}, format='json').status_code, 201)
        self.assertEqual(len(self.client.get('/api/exams').data), 9)   # 4 tests + 5 final exams
        exam = {'title': 'Midterm', 'duration': '50 mins', 'status': 'published',
                'questions': [{'text': 'Define Matter.', 'choices': ['a', 'b', 'c', 'd'], 'correct': 2, 'score': '', 'points': '5'}]}
        r = self.client.post('/api/exams', exam, format='json')
        self.assertEqual(r.status_code, 201, r.content); self.assertEqual(r.data['points'], 5); self.assertEqual(r.data['status'], 'Published')
        eid = r.data['id']
        got = self.client.get(f'/api/exams/{eid}').data
        self.assertEqual(got['questions'][0]['correct'], 2)
        self.assertEqual(self.client.put(f'/api/exams/{eid}', {'status': 'draft'}, format='json').data['status'], 'Draft')
        self.assertEqual(self.client.delete(f'/api/exams/{eid}').status_code, 204)
        r = self.client.post('/api/courses', {'title': 'Biology', 'description': 'd', 'startDate': '2024-01-01', 'endDate': '2024-06-01',
                                              'chapters': '[{"title":"Cells"},{"title":"DNA"}]'}, format='multipart')
        self.assertEqual(r.status_code, 201, r.content)
        self.assertEqual(len(self.client.get(f"/api/courses/{r.data['id']}/player").data['modules']), 2)
        self.assertEqual(self.client.post('/api/courses', {}, format='multipart').status_code, 400)

    def test_enroll_and_chapter_progress(self):
        self.login('swetha', 'student123', 'student')
        cs = {c['title']: c for c in self.client.get('/api/courses').data}
        soc = cs['Social science Department']
        self.assertFalse(soc['enrolled']); self.assertEqual(soc['status'], 'available')
        # cannot watch before enrolling, cannot mark chapters
        self.assertEqual(self.client.get(f"/api/courses/{soc['id']}/player").status_code, 403)
        chapter_id = m.Chapter.objects.filter(course_id=soc['id']).first().id
        self.assertEqual(self.client.put(f'/api/chapters/{chapter_id}/progress', {'completed': True}, format='json').status_code, 403)
        # enroll (idempotent)
        r = self.client.post(f"/api/courses/{soc['id']}/enroll"); self.assertEqual(r.status_code, 201); self.assertEqual(r.data['percent'], 0)
        self.assertEqual(self.client.post(f"/api/courses/{soc['id']}/enroll").status_code, 200)
        det = self.client.get(f"/api/courses/{soc['id']}").data
        self.assertTrue(det['enrolled']); self.assertEqual(len(det['chapters']), 6)
        # complete chapters one by one -> percent & completion
        ids = [c['id'] for c in det['chapters']]
        for n, cid in enumerate(ids, 1):
            r = self.client.put(f'/api/chapters/{cid}/progress', {'completed': True}, format='json')
            self.assertEqual(r.status_code, 200); self.assertEqual(r.data['percent'], round(n * 100 / 6))
        self.assertTrue(r.data['courseCompleted'])
        self.assertEqual({c['title']: c for c in self.client.get('/api/courses').data}['Social science Department']['status'], 'completed')
        # un-complete -> back to ongoing at current chapter
        r = self.client.put(f'/api/chapters/{ids[-1]}/progress', {'completed': False}, format='json')
        self.assertEqual(r.data['status'], 'ongoing'); self.assertEqual(r.data['percent'], 83)
        player = self.client.get(f"/api/courses/{soc['id']}/player").data
        self.assertEqual(player['currentModuleId'], ids[-1]); self.assertFalse(player['modules'][-1]['completed'])
        # existing seeded progress: Maths has 4/6 done
        maths = cs['Maths Department']; self.assertEqual(maths['percent'], 67)
        # unenroll
        self.assertEqual(self.client.delete(f"/api/courses/{soc['id']}/enroll").status_code, 204)
        self.assertFalse({c['title']: c for c in self.client.get('/api/courses').data}['Social science Department']['enrolled'])

    def test_admin_cannot_enroll(self):
        self.login('admin', 'admin123', 'admin')
        self.assertEqual(self.client.post('/api/courses/1/enroll').status_code, 403)

    def test_quiz_review_and_stats(self):
        self.login('swetha', 'student123', 'student')
        qz = self.client.get('/api/quizzes').data[0]
        self.assertEqual(qz['attempts'], 0); self.assertIsNone(qz['bestScore'])
        d = self.client.get(f"/api/quizzes/{qz['id']}").data
        self.assertEqual(d['durationMinutes'], 15); self.assertEqual(d['questionCount'], 10)
        # 3 right out of 10 (answer index 0 for first three, 1 for the rest), one skipped
        ans = {str(q['id']): (0 if i < 3 else 1) for i, q in enumerate(d['questions'])}
        ans.pop(str(d['questions'][9]['id']))
        r = self.client.post(f"/api/quizzes/{qz['id']}/attempts", {'answers': ans}, format='json').data
        self.assertEqual((r['score'], r['total'], r['percent']), (3, 10, 30))
        self.assertIsNone(r['review'][9]['chosen']); self.assertFalse(r['review'][9]['isCorrect'])
        self.assertEqual(r['attempts'], 1); self.assertEqual(r['bestScore'], 3)
        # retake with a better score keeps the best
        ans2 = {str(q['id']): 0 for q in d['questions']}
        r2 = self.client.post(f"/api/quizzes/{qz['id']}/attempts", {'answers': ans2}, format='json').data
        self.assertEqual((r2['attempts'], r2['bestScore']), (2, 10))
        # bad payload
        self.assertEqual(self.client.post(f"/api/quizzes/{qz['id']}/attempts", {'answers': [1]}, format='json').status_code, 400)
        # draft exams can't be attempted
        draft = m.Exam.objects.filter(status='draft').first()
        self.assertEqual(self.client.post(f'/api/quizzes/{draft.id}/attempts', {'answers': {}}, format='json').status_code, 404)

    def test_admin_can_delete_course(self):
        self.login('swetha', 'student123', 'student')
        cid = {c['title']: c['id'] for c in self.client.get('/api/courses').data}['Maths Department']
        self.assertEqual(self.client.delete(f'/api/courses/{cid}').status_code, 403)   # students can't
        self.assertEqual(m.Course.objects.filter(pk=cid).count(), 1)

        self.login('admin', 'admin123', 'admin')
        row = next(c for c in self.client.get('/api/courses').data if c['id'] == cid)
        self.assertGreaterEqual(row['students'], 1)                                    # swetha is enrolled
        exam = m.Exam.objects.get(subject='Mathematics')
        self.assertEqual(exam.course_id, cid)
        self.assertEqual(self.client.delete(f'/api/courses/{cid}').status_code, 204)
        self.assertEqual(self.client.get(f'/api/courses/{cid}').status_code, 404)
        self.assertFalse(m.Enrollment.objects.filter(course_id=cid).exists())
        self.assertFalse(m.Chapter.objects.filter(course_id=cid).exists())
        exam.refresh_from_db(); self.assertIsNone(exam.course_id)                      # exam survives
        self.assertEqual(len(self.client.get('/api/courses').data), 5)
        self.assertEqual(self.client.delete(f'/api/courses/{cid}').status_code, 404)   # already gone

    def test_admin_exam_is_the_student_quiz(self):
        self.login('admin', 'admin123', 'admin')
        exam = {'title': 'Chem Unit 1', 'subject': 'Chemistry', 'duration': '20 mins', 'status': 'draft', 'questions': [
            {'text': 'H2O is?', 'choices': ['Water', 'Salt', 'Acid', 'Gas'], 'correct': 0, 'points': '3'},
            {'text': 'NaCl is?', 'choices': ['Water', 'Salt', 'Acid', 'Gas'], 'correct': 1, 'points': '2'}]}
        r = self.client.post('/api/exams', exam, format='json'); eid = r.data['id']
        self.assertEqual((r.data['questions'], r.data['points']), (2, 5))

        # 1) draft -> students cannot see or take it
        self.login('swetha', 'student123', 'student')
        self.assertNotIn(eid, [q['id'] for q in self.client.get('/api/quizzes').data])
        self.assertEqual(self.client.get(f'/api/quizzes/{eid}').status_code, 404)

        # 2) admin publishes -> same record shows up as a quiz
        self.login('admin', 'admin123', 'admin')
        self.assertEqual(self.client.put(f'/api/exams/{eid}', {'status': 'published'}, format='json').data['status'], 'Published')
        self.login('swetha', 'student123', 'student')
        row = next(q for q in self.client.get('/api/quizzes').data if q['id'] == eid)
        self.assertEqual((row['title'], row['subject'], row['questions'], row['points']), ('Chem Unit 1', 'Chemistry', 2, 5))
        d = self.client.get(f'/api/quizzes/{eid}').data
        self.assertEqual((d['durationMinutes'], d['questionCount']), (20, 2))
        self.assertNotIn('correct', d['questions'][0])
        r = self.client.post(f'/api/quizzes/{eid}/attempts', {'answers': {str(d['questions'][0]['id']): 0, str(d['questions'][1]['id']): 0}}, format='json')
        self.assertEqual((r.data['score'], r.data['total']), (3, 5))        # first right (3 pts), second wrong

        # 3) admin edits the exam -> students get the edit
        self.login('admin', 'admin123', 'admin')
        self.client.put(f'/api/exams/{eid}', {'title': 'Chem Unit 1 (v2)'}, format='json')
        self.login('swetha', 'student123', 'student')
        self.assertEqual(self.client.get(f'/api/quizzes/{eid}').data['title'], 'Chem Unit 1 (v2)')

        # 4) unpublish -> gone for students; republish -> back (attempt history kept)
        self.login('admin', 'admin123', 'admin')
        self.client.put(f'/api/exams/{eid}', {'status': 'draft'}, format='json')
        self.login('swetha', 'student123', 'student')
        self.assertEqual(self.client.get(f'/api/quizzes/{eid}').status_code, 404)
        self.login('admin', 'admin123', 'admin')
        self.client.put(f'/api/exams/{eid}', {'status': 'published'}, format='json')
        self.login('swetha', 'student123', 'student')
        self.assertEqual(self.client.get(f'/api/quizzes/{eid}').data['attempts'], 1)

        # 5) delete -> gone for students too
        self.login('admin', 'admin123', 'admin')
        self.assertEqual(self.client.delete(f'/api/exams/{eid}').status_code, 204)
        self.login('swetha', 'student123', 'student')
        self.assertNotIn(eid, [q['id'] for q in self.client.get('/api/quizzes').data])

    def test_cannot_publish_incomplete_exam(self):
        self.login('admin', 'admin123', 'admin')
        n = m.Exam.objects.count()
        r = self.client.post('/api/exams', {'title': 'Empty', 'status': 'published', 'questions': []}, format='json')
        self.assertEqual(r.status_code, 400); self.assertIn('at least one question', r.data['message'])
        blank = [{'text': '', 'choices': ['', '', '', ''], 'correct': 0}]
        r = self.client.post('/api/exams', {'title': 'Blank', 'status': 'published', 'questions': blank}, format='json')
        self.assertEqual(r.status_code, 400); self.assertIn('Question 1 needs text', r.data['message'])
        bad = [{'text': 'Q?', 'choices': ['a', 'b', '', ''], 'correct': 3}]
        r = self.client.post('/api/exams', {'title': 'BadAnswer', 'status': 'published', 'questions': bad}, format='json')
        self.assertEqual(r.status_code, 400); self.assertIn('correct choice is empty', r.data['message'])
        self.assertEqual(m.Exam.objects.count(), n)                       # failed publishes are rolled back, nothing saved
        # the same incomplete exam is fine as a DRAFT
        self.assertEqual(self.client.post('/api/exams', {'title': 'Blank', 'status': 'draft', 'questions': blank}, format='json').status_code, 201)
        # publishing an existing draft that has no questions is refused too
        eid = m.Exam.objects.get(title='Blank').id
        r = self.client.put(f'/api/exams/{eid}', {'status': 'published', 'questions': []}, format='json')
        self.assertEqual(r.status_code, 400)
        self.assertEqual(m.Exam.objects.get(pk=eid).status, 'draft')
