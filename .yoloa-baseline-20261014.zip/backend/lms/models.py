from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    ROLES = [('student', 'Student'), ('admin', 'Admin')]
    role = models.CharField(max_length=10, choices=ROLES, default='student')
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    address = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)
    postal_code = models.CharField(max_length=20, blank=True)

    @property
    def display_name(self):
        return f'{self.first_name} {self.last_name}'.strip() or self.username


class Course(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    cover = models.ImageField(upload_to='courses/', blank=True, null=True)
    enrollment_label = models.CharField(max_length=100, default='Continous enrollement')
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    professor = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='taught_courses')
    created_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='created_courses')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['id']

    def __str__(self): return self.title


class Chapter(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='chapters')
    title = models.CharField(max_length=200)
    order = models.PositiveIntegerField(default=0)
    video_url = models.URLField(blank=True)
    duration = models.CharField(max_length=50, default='1 hr 30 mins')

    class Meta:
        ordering = ['order', 'id']


class CourseContent(models.Model):
    COLORS = [('green', 'green'), ('pink', 'pink'), ('blue', 'blue'), ('yellow', 'yellow')]
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='contents')
    title = models.CharField(max_length=200)
    text = models.TextField(blank=True)
    color = models.CharField(max_length=10, choices=COLORS, default='blue')
    file = models.FileField(upload_to='course_files/', blank=True, null=True)

    class Meta:
        ordering = ['id']


class Enrollment(models.Model):
    STATUS = [('ongoing', 'Ongoing'), ('completed', 'Completed')]
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='enrollments')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    status = models.CharField(max_length=10, choices=STATUS, default='ongoing')
    percent = models.PositiveIntegerField(default=0)
    current_chapter = models.CharField(max_length=100, blank=True)

    class Meta:
        unique_together = ('student', 'course')


class ChapterProgress(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='chapter_progress')
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE, related_name='progress')
    completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = ('student', 'chapter')


class Exam(models.Model):
    """One record = what the admin builds AND what students take as a quiz.
    Published -> visible to students in Quizzes. Draft -> admin only. Delete -> gone for everyone."""
    STATUS = [('draft', 'Draft'), ('published', 'Published')]
    title = models.CharField(max_length=200)
    subject = models.CharField(max_length=100, blank=True)
    term = models.CharField(max_length=50, blank=True, default='1st Term')
    duration = models.CharField(max_length=50, blank=True)
    status = models.CharField(max_length=10, choices=STATUS, default='draft')
    course = models.ForeignKey(Course, null=True, blank=True, on_delete=models.SET_NULL, related_name='exams')
    created_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['id']


class Question(models.Model):
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    choices = models.JSONField(default=list)  # ["A text","B text","C text","D text"]
    correct = models.PositiveSmallIntegerField(default=0)  # index 0-3
    score = models.PositiveIntegerField(default=0)
    points = models.PositiveIntegerField(default=1)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', 'id']


class Attempt(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='attempts')
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='attempts')
    answers = models.JSONField(default=dict)  # {question_id: choice_index}
    score = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)


class LibraryItem(models.Model):
    title = models.CharField(max_length=200)
    subject = models.CharField(max_length=100)
    cover = models.ImageField(upload_to='library/covers/', blank=True, null=True)
    file = models.FileField(upload_to='library/files/', blank=True, null=True)

    class Meta:
        ordering = ['id']


class Announcement(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='announcements')
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']


class CalendarEvent(models.Model):
    TYPES = [('event', 'Event'), ('deadline', 'Deadline')]
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE, help_text='null = visible to everyone')
    date = models.DateField()
    time = models.CharField(max_length=20, blank=True)
    title = models.CharField(max_length=200)
    type = models.CharField(max_length=10, choices=TYPES, default='event')

    class Meta:
        ordering = ['date', 'id']


class ScheduleItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='schedule')
    subject = models.CharField(max_length=100)
    done = models.PositiveIntegerField(default=0)
    total = models.PositiveIntegerField(default=20)
    time = models.CharField(max_length=30)

    class Meta:
        ordering = ['id']


class Assignment(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='assignments')
    subject = models.CharField(max_length=100)
    chapter = models.CharField(max_length=100, blank=True)
    title = models.CharField(max_length=200)
    page = models.CharField(max_length=50, blank=True)
    due_time = models.CharField(max_length=20, blank=True)
    status = models.CharField(max_length=20, default='Pending')
