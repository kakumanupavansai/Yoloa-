import calendar as cal
import json
import re
from datetime import date, timedelta

from django.contrib.auth import authenticate
from django.db import transaction
from django.db.models import Count, Max
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import status as http
from rest_framework.decorators import api_view, parser_classes, permission_classes
from rest_framework.exceptions import ValidationError
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken

from . import models as m
from .utils import IsAdminRole, abs_url, to_int, user_json

ANY = [JSONParser, FormParser, MultiPartParser]


def fail(message, code=400):
    return Response({'message': message}, status=code)


# ───────────────────────── Auth ─────────────────────────
@api_view(['POST'])
@permission_classes([AllowAny])
def login(request):
    """POST /auth/login {username,password,role} -> {token,refresh,user}"""
    d = request.data
    user = authenticate(username=d.get('username', ''), password=d.get('password', ''))
    if not user:
        return fail('Invalid username or password', 401)
    if d.get('role') and d['role'] != user.role:
        return fail(f'This account is not a {d["role"]} account', 403)
    refresh = RefreshToken.for_user(user)
    user.last_login = timezone.now(); user.save(update_fields=['last_login'])
    return Response({'token': str(refresh.access_token), 'refresh': str(refresh), 'user': user_json(user, request)})


@api_view(['GET'])
def me(request):
    return Response(user_json(request.user, request))


# ───────────────────────── Dashboards ─────────────────────────
def schedule_json(user):
    return [{'id': s.id, 'subject': s.subject, 'done': s.done, 'total': s.total, 'time': s.time} for s in user.schedule.all()]


def upcoming_json():
    evs = m.CalendarEvent.objects.filter(user__isnull=True, date__gte=date.today())[:3]
    return [{'id': e.id, 'title': e.title, 'soon': i > 0} for i, e in enumerate(evs)]


@api_view(['GET'])
def student_dashboard(request):
    u = request.user
    latest = m.Announcement.objects.first()
    best = {}
    for sid, eid, sc in m.Attempt.objects.values_list('student_id', 'exam_id', 'score'):
        best[(sid, eid)] = max(best.get((sid, eid), 0), sc)
    totals = {}
    for (sid, _), sc in best.items():
        totals[sid] = totals.get(sid, 0) + sc
    top = sorted(totals.items(), key=lambda x: -x[1])[:4]
    users = {x.id: x for x in m.User.objects.filter(id__in=[i for i, _ in top])}
    leaderboard = [{'id': i, 'name': users[i].display_name, 'score': sc, 'avatar': abs_url(request, users[i].avatar)} for i, sc in top]
    completion = [{'id': e.id, 'title': e.course.title, 'chapter': e.current_chapter, 'percent': e.percent}
                  for e in u.enrollments.select_related('course').filter(status='ongoing')[:6]]
    assignments = [{'id': a.id, 'subject': a.subject, 'chapter': a.chapter, 'title': a.title, 'page': a.page,
                    'time': a.due_time, 'status': a.status} for a in u.assignments.all()]
    return Response({'announcement': latest.text if latest else '', 'leaderboard': leaderboard, 'completion': completion,
                     'assignments': assignments, 'schedule': schedule_json(u), 'upcomingEvents': upcoming_json()})


@api_view(['GET'])
@permission_classes([IsAdminRole])
def admin_dashboard(request):
    students = m.User.objects.filter(role='student')
    total = students.count()
    present = students.filter(last_login__date=timezone.localdate()).count()
    week_ago = timezone.now() - timedelta(days=7)
    anns = [{'id': a.id, 'author': a.author.display_name, 'text': a.text,
             'time': timezone.localtime(a.created_at).strftime('%I.%M %p').lstrip('0').lower(), 'avatar': abs_url(request, a.author.avatar)}
            for a in m.Announcement.objects.select_related('author')[:5]]
    return Response({
        'announcements': anns,
        # total = students registered on the platform; enrolled = registered AND joined at least one course
        'stats': {'total': total, 'absent': total - present, 'present': present,
                  'newThisWeek': students.filter(date_joined__gte=week_ago).count(),
                  'enrolled': students.filter(enrollments__isnull=False).distinct().count()},
        'upcomingEvents': upcoming_json()})


@api_view(['POST'])
@permission_classes([IsAdminRole])
def announcements(request):
    text = (request.data.get('text') or '').strip()
    if not text:
        raise ValidationError({'text': 'This field is required.'})
    a = m.Announcement.objects.create(author=request.user, text=text)
    return Response({'id': a.id, 'text': a.text, 'author': request.user.display_name}, status=201)


# ───────────────────────── Courses, enrollment & chapter progress ─────────────────────────
def get_enrollment(user, course):
    return m.Enrollment.objects.filter(student=user, course=course).first() if user.role == 'student' else None


def done_chapter_ids(user, chapters):
    return set(m.ChapterProgress.objects.filter(student=user, chapter__in=chapters, completed=True).values_list('chapter_id', flat=True))


def recalc_enrollment(enr):
    """Recompute percent / status / current chapter from per-chapter progress."""
    chapters = list(enr.course.chapters.all())
    done = done_chapter_ids(enr.student, chapters)
    nxt = next((c for c in chapters if c.id not in done), None)
    enr.percent = round(len(done) * 100 / len(chapters)) if chapters else 0
    enr.status = 'completed' if chapters and nxt is None else 'ongoing'
    enr.current_chapter = nxt.title if nxt else (chapters[-1].title if chapters else '')
    enr.save()
    return enr


@api_view(['GET', 'POST'])
@parser_classes(ANY)
def courses(request):
    if request.method == 'GET':
        is_student = request.user.role == 'student'
        enr = {e.course_id: e for e in request.user.enrollments.all()} if is_student else {}
        out = []
        for c in m.Course.objects.annotate(n=Count('chapters', distinct=True), s=Count('enrollments', distinct=True)):
            e = enr.get(c.id)
            out.append({'id': c.id, 'title': c.title, 'cover': abs_url(request, c.cover), 'enrollment': c.enrollment_label,
                        'status': e.status if e else ('available' if is_student else 'ongoing'),
                        'enrolled': bool(e), 'percent': e.percent if e else 0, 'chapters': c.n, 'students': c.s})
        return Response(out)

    if request.user.role != 'admin':
        return fail('Admin access required.', 403)
    d = request.data
    title = (d.get('title') or '').strip()
    if not title:
        raise ValidationError({'title': 'This field is required.'})
    try:
        chapters = json.loads(d.get('chapters') or '[]')
    except json.JSONDecodeError:
        raise ValidationError({'chapters': 'Must be a JSON array.'})
    with transaction.atomic():
        c = m.Course.objects.create(
            title=title, description=d.get('description', ''), cover=d.get('cover') or None,
            start_date=d.get('startDate') or None, end_date=d.get('endDate') or None, created_by=request.user, professor=request.user)
        for i, ch in enumerate(chapters):
            m.Chapter.objects.create(course=c, title=ch.get('title') or f'Chapter {i + 1}', order=i, video_url=ch.get('videoUrl', ''))
    return Response({'id': c.id, 'title': c.title}, status=201)


@api_view(['POST', 'DELETE'])
def course_enroll(request, pk):
    """POST /courses/:id/enroll  (idempotent)  ·  DELETE /courses/:id/enroll  (progress is kept)"""
    if request.user.role != 'student':
        return fail('Only students can enroll in courses.', 403)
    c = get_object_or_404(m.Course, pk=pk)
    if request.method == 'DELETE':
        m.Enrollment.objects.filter(student=request.user, course=c).delete()
        return Response(status=204)
    enr, created = m.Enrollment.objects.get_or_create(student=request.user, course=c)
    recalc_enrollment(enr)
    return Response({'enrolled': True, 'percent': enr.percent, 'status': enr.status, 'currentChapter': enr.current_chapter},
                    status=201 if created else 200)


@api_view(['GET', 'DELETE'])
def course_detail(request, pk):
    c = get_object_or_404(m.Course, pk=pk)
    if request.method == 'DELETE':
        # Admin only. Removes chapters, lesson content, enrollments and chapter progress (cascade).
        # Exams linked to this course are kept (their course link is just cleared).
        if request.user.role != 'admin':
            return fail('Admin access required.', 403)
        if c.cover:
            c.cover.delete(save=False)
        for item in c.contents.all():
            if item.file:
                item.file.delete(save=False)
        c.delete()
        return Response(status=204)
    prof = c.professor
    enr = get_enrollment(request.user, c)
    chapters = list(c.chapters.all())
    done = done_chapter_ids(request.user, chapters) if enr else set()
    exams = c.exams.filter(status='published')
    progress = [{'id': e.id, 'title': e.course.title, 'chapter': e.current_chapter,
                 'status': 'Completed' if e.status == 'completed' else 'In progress'}
                for e in request.user.enrollments.select_related('course')[:5]]
    return Response({
        'id': c.id, 'title': c.title, 'adminTitle': c.title, 'description': c.description, 'cover': abs_url(request, c.cover),
        'enrolled': bool(enr), 'percent': enr.percent if enr else 0,
        'professor': {'name': prof.display_name, 'title': 'Professor', 'avatar': abs_url(request, prof.avatar)} if prof else None,
        'content': [{'id': x.id, 'title': x.title, 'text': x.text, 'color': x.color, 'fileUrl': abs_url(request, x.file) or '#'} for x in c.contents.all()],
        'chapters': [{'id': ch.id, 'title': ch.title, 'duration': ch.duration, 'completed': ch.id in done} for ch in chapters],
        'progress': progress,
        'publishedExams': [{'id': e.id, 'title': e.title, 'subject': e.subject, 'status': 'Published'} for e in exams],
    })


@api_view(['GET'])
def course_player(request, pk):
    c = get_object_or_404(m.Course, pk=pk)
    enr = get_enrollment(request.user, c)
    if request.user.role == 'student' and not enr:
        return fail('Enroll in this course to start learning.', 403)
    chapters = list(c.chapters.all())
    done = done_chapter_ids(request.user, chapters) if enr else set()
    cur = next((ch for ch in chapters if ch.id not in done), chapters[-1] if chapters else None)
    return Response({
        'courseId': c.id, 'courseTitle': c.title, 'description': c.description, 'percent': enr.percent if enr else 0,
        'lessonTitle': cur.title if cur else '', 'videoUrl': cur.video_url if cur else '', 'currentModuleId': cur.id if cur else None,
        'modules': [{'id': ch.id, 'title': ch.title, 'duration': ch.duration, 'videoUrl': ch.video_url, 'completed': ch.id in done} for ch in chapters],
    })


@api_view(['PUT'])
def chapter_progress(request, pk):
    """PUT /chapters/:id/progress {completed: true|false} -> updated course progress"""
    if request.user.role != 'student':
        return fail('Only students track progress.', 403)
    ch = get_object_or_404(m.Chapter.objects.select_related('course'), pk=pk)
    enr = get_enrollment(request.user, ch.course)
    if not enr:
        return fail('Enroll in this course first.', 403)
    v = request.data.get('completed', True)
    completed = v if isinstance(v, bool) else str(v).lower() in ('1', 'true', 'yes')
    m.ChapterProgress.objects.update_or_create(student=request.user, chapter=ch, defaults={
        'completed': completed, 'completed_at': timezone.now() if completed else None})
    recalc_enrollment(enr)
    return Response({'chapterId': ch.id, 'completed': completed, 'percent': enr.percent, 'status': enr.status,
                     'currentChapter': enr.current_chapter, 'courseCompleted': enr.status == 'completed'})


# ───────────────────────── Exams & quizzes ─────────────────────────
def exam_row(e):
    qs = list(e.questions.all())
    return {'id': e.id, 'title': e.title, 'subject': e.subject, 'term': e.term, 'duration': e.duration,
            'questions': len(qs), 'points': sum(q.points for q in qs), 'status': e.get_status_display()}


def check_publishable(exam):
    """Published exams are what students see as quizzes, so they must be complete."""
    qs = list(exam.questions.all())
    if not qs:
        raise ValidationError({'message': 'Add at least one question before publishing.'})
    for n, q in enumerate(qs, 1):
        if not q.text or len([c for c in q.choices if c]) < 2:
            raise ValidationError({'message': f'Question {n} needs text and at least 2 choices.'})
        if not (0 <= q.correct < len(q.choices)) or not q.choices[q.correct]:
            raise ValidationError({'message': f'Question {n}: the correct choice is empty.'})


def save_exam(exam, d, user=None):
    if d.get('status') and d['status'] not in ('draft', 'published'):
        raise ValidationError({'status': "Must be 'draft' or 'published'."})
    for f in ('title', 'subject', 'term', 'duration', 'status'):
        if f in d:
            setattr(exam, f, d[f])
    if user and not exam.pk:
        exam.created_by = user
    if not exam.title:
        raise ValidationError({'title': 'This field is required.'})
    exam.save()
    if 'questions' in d:
        exam.questions.all().delete()
        for i, q in enumerate(d['questions']):
            choices = [str(c).strip() for c in (q.get('choices') or [])]
            m.Question.objects.create(
                exam=exam, text=(q.get('text') or '').strip(), choices=choices, order=i,
                correct=min(max(to_int(q.get('correct')), 0), max(len(choices) - 1, 0)),
                score=to_int(q.get('score')), points=to_int(q.get('points'), 0) or to_int(q.get('score'), 0) or 1)
    if exam.status == 'published':
        check_publishable(exam)  # raises -> the surrounding transaction rolls everything back
    return exam


@api_view(['GET', 'POST'])
def exams(request):
    """Admin exam builder. (Students use /quizzes, which shows these same records once published.)"""
    if request.user.role != 'admin':
        return fail('Admin access required.', 403)
    if request.method == 'GET':
        return Response([exam_row(e) for e in m.Exam.objects.prefetch_related('questions')])
    with transaction.atomic():
        e = save_exam(m.Exam(), request.data, request.user)
    return Response(exam_row(e), status=201)


@api_view(['GET', 'PUT', 'DELETE'])
def exam_detail(request, pk):
    if request.user.role != 'admin':      # this response contains the correct answers
        return fail('Admin access required.', 403)
    e = get_object_or_404(m.Exam, pk=pk)
    if request.method == 'DELETE':
        e.delete(); return Response(status=204)   # also disappears from students' Quizzes
    if request.method == 'PUT':
        with transaction.atomic():
            save_exam(e, request.data)
    row = exam_row(e)
    row['questions'] = [{'id': q.id, 'text': q.text, 'choices': q.choices, 'correct': q.correct, 'score': q.score, 'points': q.points}
                        for q in e.questions.all()]
    return Response(row)


def minutes_from(text):
    mm = re.search(r'\d+', text or '')
    return int(mm.group()) if mm else None


def quiz_stats(user, exam):
    agg = user.attempts.filter(exam=exam).aggregate(n=Count('id'), best=Max('score'))
    return {'attempts': agg['n'], 'bestScore': agg['best']}


def published_exams():
    return m.Exam.objects.filter(status='published').annotate(nq=Count('questions')).filter(nq__gt=0)


@api_view(['GET'])
def quizzes(request):
    """Student quizzes = the exams the admin has published."""
    qs = published_exams().prefetch_related('questions')
    return Response([{'id': e.id, 'title': e.title, 'subject': e.subject, 'questions': len(e.questions.all()),
                      'points': sum(q.points for q in e.questions.all()), **quiz_stats(request.user, e)} for e in qs])


@api_view(['GET'])
def quiz_detail(request, pk):
    """Questions WITHOUT correct answers."""
    e = get_object_or_404(published_exams(), pk=pk)
    qs = list(e.questions.all())
    return Response({'id': e.id, 'title': e.title, 'subject': e.subject, 'duration': e.duration, 'durationMinutes': minutes_from(e.duration),
                     'questionCount': len(qs), 'totalPoints': sum(q.points for q in qs), **quiz_stats(request.user, e),
                     'questions': [{'id': q.id, 'text': q.text, 'choices': q.choices, 'points': q.points} for q in qs]})


@api_view(['POST'])
def quiz_attempt(request, pk):
    """POST /quizzes/:id/attempts {answers:{questionId: choiceIndex}} -> score + per-question review"""
    e = get_object_or_404(published_exams(), pk=pk)
    answers = request.data.get('answers') or {}
    if not isinstance(answers, dict):
        raise ValidationError({'answers': 'Must be an object {questionId: choiceIndex}.'})
    score = total = 0
    review = []
    for q in e.questions.all():
        total += q.points
        raw = answers.get(str(q.id))
        chosen = to_int(raw, -1) if raw is not None else -1
        ok = chosen == q.correct
        score += q.points if ok else 0
        review.append({'id': q.id, 'text': q.text, 'choices': q.choices, 'chosen': chosen if chosen >= 0 else None,
                       'correct': q.correct, 'isCorrect': ok, 'points': q.points})
    att = m.Attempt.objects.create(student=request.user, exam=e, answers=answers, score=score)
    return Response({'attemptId': att.id, 'score': score, 'total': total, 'percent': round(score * 100 / total) if total else 0,
                     'review': review, **quiz_stats(request.user, e)}, status=201)


# ───────────────────────── Library / Notes ─────────────────────────
@api_view(['GET'])
def library(request):
    return Response([{'id': i.id, 'title': i.title, 'subject': i.subject, 'cover': abs_url(request, i.cover),
                      'fileUrl': abs_url(request, i.file) or '#'} for i in m.LibraryItem.objects.all()])


NOTES_APPS = [
    {'id': 'drive', 'name': 'Google Drive', 'url': 'https://drive.google.com', 'color': '#34a853'},
    {'id': 'lens', 'name': 'Google Lens', 'url': 'https://lens.google.com', 'color': '#4285f4'},
    {'id': 'excel', 'name': 'Excel', 'url': 'https://www.office.com/launch/excel', 'color': '#107c41'},
    {'id': 'doc', 'name': 'Google Doc', 'url': 'https://docs.google.com', 'color': '#4285f4'},
    {'id': 'word', 'name': 'Word', 'url': 'https://www.office.com/launch/word', 'color': '#2b579a'},
    {'id': 'ppt', 'name': 'Power point', 'url': 'https://www.office.com/launch/powerpoint', 'color': '#d24726'},
]


@api_view(['GET'])
def notes_apps(request):
    return Response(NOTES_APPS)


# ───────────────────────── Calendar ─────────────────────────
@api_view(['GET', 'POST'])
def calendar_view(request):
    if request.method == 'POST':
        d = request.data
        if not d.get('date') or not d.get('title'):
            raise ValidationError({'message': 'date and title are required.'})
        e = m.CalendarEvent.objects.create(user=request.user, date=d['date'], title=d['title'],
                                           time=d.get('time', ''), type=d.get('type', 'event'))
        return Response({'id': e.id, 'date': str(e.date), 'title': e.title, 'type': e.type}, status=201)

    today = date.today()
    year, month = to_int(request.query_params.get('year'), today.year), to_int(request.query_params.get('month'), today.month)
    if not 1 <= month <= 12:
        raise ValidationError({'month': 'Must be 1-12.'})
    from django.db.models import Q
    mine = m.CalendarEvent.objects.filter(Q(user__isnull=True) | Q(user=request.user))
    events = mine.filter(date__year=year, date__month=month)
    day = today if (today.year, today.month) == (year, month) else date(year, month, 1)
    day_events = mine.filter(date=day).exclude(time='')
    return Response({
        'year': year, 'monthIndex': month - 1,
        'events': [{'id': e.id, 'date': str(e.date), 'title': e.title, 'type': e.type} for e in events],
        'daySchedule': {'date': f"{cal.month_name[month]} {day.day}, {cal.day_name[day.weekday()]}",
                        'items': [{'time': e.time, 'title': e.title} for e in day_events]},
    })


# ───────────────────────── Profile ─────────────────────────
PROFILE_FIELDS = {'username': 'username', 'email': 'email', 'firstName': 'first_name', 'lastName': 'last_name',
                  'address': 'address', 'city': 'city', 'country': 'country', 'postalCode': 'postal_code'}


@api_view(['GET', 'PUT'])
def profile(request):
    u = request.user
    if request.method == 'PUT':
        if 'username' in request.data and m.User.objects.exclude(pk=u.pk).filter(username=request.data['username']).exists():
            raise ValidationError({'username': 'This username is taken.'})
        for js, model_field in PROFILE_FIELDS.items():
            if js in request.data:
                setattr(u, model_field, request.data[js])
        u.save()
    return Response(user_json(u, request))


@api_view(['POST'])
@parser_classes([MultiPartParser])
def profile_avatar(request):
    f = request.FILES.get('avatar')
    if not f:
        raise ValidationError({'avatar': 'No file uploaded.'})
    request.user.avatar = f
    request.user.save(update_fields=['avatar'])
    return Response({'url': abs_url(request, request.user.avatar)})
