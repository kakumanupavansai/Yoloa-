from datetime import date, timedelta

from django.core.management.base import BaseCommand

from django.utils import timezone

from lms import models as m
from lms.views import recalc_enrollment


class Command(BaseCommand):
    help = 'Load demo data matching the Figma screens. Safe to re-run.'

    def handle(self, *a, **kw):
        U = m.User
        admin, _ = U.objects.get_or_create(username='admin', defaults=dict(role='admin', first_name='Sherin', last_name='Jackson', email='admin@example.com', is_staff=True, is_superuser=True))
        admin.set_password('admin123'); admin.save()
        swetha, _ = U.objects.get_or_create(username='swetha', defaults=dict(role='student', first_name='Swetha', last_name='Shankaresh', email='swetha@example.com'))
        swetha.set_password('student123'); swetha.save()

        others = []
        for uname, first, last in [('shyam', 'Shyam', 'Nithin'), ('nivin', 'Nivin', 'Kumar'), ('nivetha', 'Nivetha', 'Dinesh'), ('rudhra', 'Rudhra', 'Shankar')]:
            u, _ = U.objects.get_or_create(username=uname, defaults=dict(role='student', first_name=first, last_name=last))
            u.set_password('student123'); u.save(); others.append(u)

        # Courses
        titles = [('Maths Department', 'ongoing'), ('Chemistry Department', 'ongoing'), ('Physics Department', 'ongoing'),
                  ('Computer science Department', 'completed'), ('English Department', 'ongoing'), ('Social science Department', 'completed')]
        courses = []
        for t, st in titles:
            c, _ = m.Course.objects.get_or_create(title=t, defaults=dict(
                description='Matter is one of the very important topic in Chemistry. Matter is anything that takes up space and can be weighed. In other words, matter has volume and mass. There are many different substances, or types of matter, in the universe.',
                professor=admin, created_by=admin, start_date=date(2023, 11, 1)))
            courses.append((c, st))
            if not c.chapters.exists():
                for i in range(1, 7):
                    m.Chapter.objects.create(course=c, title=f"{c.title.split()[0]} chapter {i}", order=i)  # add video_url in /admin/
            if not c.contents.exists():
                for title, text, color in [
                    ('What is matter?', 'A common or traditional definition of matter is "anything that has mass and volume (occupies space)".', 'green'),
                    ('Chemical Element', 'A chemical element is a pure substance that consists of atoms with the same number of protons in the nucleus.', 'pink'),
                    ('Phase Changes', 'Heat decides the state of matter. Heat plays an important role in converting one state of matter to another.', 'blue')]:
                    m.CourseContent.objects.create(course=c, title=title, text=text, color=color)
        # Swetha is enrolled in 5 courses with some chapters done; "Social science" is left open to try enrolling.
        for (c, _), n_done in zip(courses[:5], [4, 3, 3, 6, 4]):
            enr, _ = m.Enrollment.objects.get_or_create(student=swetha, course=c)
            for ch in list(c.chapters.all())[:n_done]:
                m.ChapterProgress.objects.get_or_create(student=swetha, chapter=ch, defaults=dict(completed=True, completed_at=timezone.now()))
            recalc_enrollment(enr)

        # Exams (the SAME records are the student quizzes once published)
        def make_exam(title, subject, status, nq, pts, duration):
            e, created = m.Exam.objects.get_or_create(title=title, subject=subject, defaults=dict(status=status, duration=duration, created_by=admin))
            if created:
                for q in range(nq):
                    m.Question.objects.create(exam=e, order=q, text=f'Sample question {q + 1} for {subject}?',
                                              choices=['Option A', 'Option B', 'Option C', 'Option D'], correct=0, points=pts, score=pts)
            return e
        quizzes = [make_exam(f'Test 0{i + 1}', s, 'published', 10, 1, '15 mins') for i, s in enumerate(['Java', 'Java', 'Python', 'DSA'])]
        for s, st in [('Mathematics', 'published'), ('Chemistry', 'draft'), ('Botany', 'draft'), ('Physics', 'draft'), ('English', 'draft')]:
            make_exam('Final exam', s, st, 10, 10, '50 mins')
        m.Exam.objects.filter(title='Final exam', subject='Mathematics').update(course=courses[0][0])

        # Leaderboard
        if not m.Attempt.objects.exists():
            for u, s in zip(others, [60, 58, 50, 49]):
                m.Attempt.objects.create(student=u, exam=quizzes[0], score=s)

        # Dashboard extras
        if not swetha.schedule.exists():
            for s, d, t in [('Physics', 6, '17.00 - 18.00'), ('Chemistry', 8, '18.00 - 19.00'), ('Mathmetics', 5, '19.00 - 20.00'), ('Biology', 4, '21.00 - 22.00'), ('Social', 7, '16.00 - 17.00')]:
                m.ScheduleItem.objects.create(user=swetha, subject=s, done=d, time=t)
        if not swetha.assignments.exists():
            m.Assignment.objects.create(student=swetha, subject='Chemistry', chapter='Chapter 5', title='Daily task', page='Page 10', due_time='11.00 AM')
        if not m.Announcement.objects.exists():
            m.Announcement.objects.create(author=admin, text='Hello swetha, your live session is about to start!')
            m.Announcement.objects.create(author=admin, text='Hello, you have to complete your papers')

        # Calendar
        if not m.CalendarEvent.objects.exists():
            m.CalendarEvent.objects.create(date=date(2023, 11, 11), title='Physics workshop')
            m.CalendarEvent.objects.create(date=date(2023, 11, 15), title='Maths Assignment Deadline', type='deadline')
            m.CalendarEvent.objects.create(date=date(2023, 11, 20), time='10.00 AM', title='Live class')
            m.CalendarEvent.objects.create(date=date(2023, 11, 20), time='11.00 AM', title='Physics Workshop')
            today = date.today()
            for off, t in [(3, 'Presentation for maths'), (7, 'Guest Lecture on Atoms'), (10, 'English - Prepositions')]:
                m.CalendarEvent.objects.create(date=today + timedelta(days=off), title=t)

        # Library
        if not m.LibraryItem.objects.exists():
            for s, t in [('Chemistry', 'Chemistry Textbook Class 9'), ('Chemistry', 'Problems in Inorganic Chemistry'), ('Physics', 'Physics Class 12'),
                         ('Physics', 'Principles of Physics'), ('Mathematics', 'Mathematics Textbook Class XI'), ('Mathematics', 'Active Mathematics Book 1'),
                         ('English', 'Learn English'), ('English', 'General English')]:
                m.LibraryItem.objects.create(subject=s, title=t)

        self.stdout.write(self.style.SUCCESS('Seeded. Logins -> admin/admin123 (admin), swetha/student123 (student)'))
