# YOLOA LMS – "You Only Learn Once"

Full-stack learning management system converted from the Figma design **Edu-learn LMS UI**.

| Part | Stack | Folder |
|---|---|---|
| Frontend | React 18 · Vite · Tailwind CSS · React Router | `frontend/` |
| Backend | Django · Django REST Framework · JWT · PostgreSQL | `backend/` |
| API testing | Postman collection + environment | `backend/postman/` |

## Quick start (two terminals)

**1. Backend** (http://localhost:8000)
```bash
cd backend
python -m venv venv && source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                    # set DB_* (PostgreSQL), or USE_SQLITE=1 for a quick trial
# PostgreSQL: create the database first ->  CREATE DATABASE yoloa;
python manage.py migrate
python manage.py seed                                   # demo data
python manage.py runserver
```
Logins: **admin / admin123** · **swetha / student123**

**2. Frontend** (http://localhost:5173)
```bash
cd frontend
npm install
# in .env set VITE_USE_MOCK=false to talk to Django (true = built-in mock data, no backend needed)
npm run dev
```
`/api` calls are proxied to `localhost:8000` (see `frontend/vite.config.js`), so there are no CORS problems in development.

## Project structure
```
yoloa-project/
├── README.md
├── .gitignore
├── frontend/
│   ├── index.html · package.json · vite.config.js · tailwind.config.js · postcss.config.js
│   ├── .env / .env.example              VITE_USE_MOCK, VITE_API_URL
│   └── src/
│       ├── main.jsx · App.jsx · index.css · hooks.js · utils.js
│       ├── routes/ProtectedRoute.jsx    role-based route guard
│       ├── context/AuthContext.jsx      login state + JWT
│       ├── services/
│       │   ├── http.js                  fetch wrapper (token, errors, mock switch)
│       │   └── api.js                   one function per backend endpoint
│       ├── data/mock.js                 mock data (mirrors the API responses)
│       ├── components/
│       │   ├── layout/                  AppLayout, Sidebar, Topbar, RightPanel
│       │   └── ui/                      Avatar, CoverImage, ProgressBar, Icons, Logo, HeroArt, States
│       ├── pages/
│       │   ├── Landing.jsx · Login.jsx
│       │   ├── student/                 Dashboard, Courses, CourseDetail, CoursePlayer,
│       │   │                            Calendar, Notes, Quizzes, QuizTake, Library, Profile
│       │   └── admin/                   Dashboard, CourseCreation, Exams, ExamCreation
│       └── __tests__/                   flows.test.jsx (mock) · integration.test.jsx (live API)
└── backend/
    ├── manage.py · requirements.txt · .env.example
    ├── config/                          settings (PostgreSQL), urls, wsgi
    ├── lms/
    │   ├── models.py                    User, Course, Chapter, ChapterProgress, Enrollment, Exam, Question, Attempt, ...
    │   ├── views.py · urls.py · utils.py · admin.py
    │   ├── migrations/
    │   ├── management/commands/seed.py  demo data
    │   └── tests.py
    └── postman/                         YOLOA-LMS.postman_collection.json, YOLOA-Local.postman_environment.json
```

## Features
- **Student:** dashboard (leaderboard, progress, assignments, schedule), browse & **enroll** in courses, lesson player with **per-chapter progress**, calendar, notes launcher, **quizzes with timer + scored answer review**, library downloads, profile with avatar upload.
- **Admin:** dashboard (announcements, **students registered** count), course creation (cover image, chapters + video URLs), course/exam **delete**, exam builder (draft / publish). **Published exams are the students' quizzes** – one shared record.
- **Responsive:** works on phones, tablets and laptops (slide-in menu below 1024 px, fixed sidebar above).
- **Auth:** JWT, separate student/admin roles enforced on the server.

## Tests
```bash
cd backend  && USE_SQLITE=1 python manage.py test     # 10 API tests
cd frontend && npm test                               # 15 UI flow tests (mock mode)
# UI against the real API (backend running + seeded):
cd frontend && VITE_USE_MOCK=false VITE_API_URL=http://localhost:8000/api npm test
```
More detail: `frontend/README.md` (screen → route map, design tokens) and `backend/README.md` (API table, models, Postman).

## Still to do on your side
- Export the logo/illustration/photos from Figma (they could not be downloaded automatically) into `frontend/public/` and swap the placeholders (`Logo.jsx`, `HeroArt.jsx`).
- Before deploying: real `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=False`, `ALLOWED_HOSTS`, media storage (S3/nginx), `npm run build` for the frontend.
