import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { useApi } from '../../hooks'
import { quizzesApi } from '../../services/api'
import Topbar from '../../components/layout/Topbar'
import { Async } from '../../components/ui/States'
import { fmtTime } from '../../utils'

const LETTERS = ['A', 'B', 'C', 'D', 'E', 'F']

// Stages: intro (Preview) → taking (Attempt) → result (score + answer review)
export default function QuizTake() {
  const { id } = useParams()
  const [params] = useSearchParams()
  const state = useApi(() => quizzesApi.get(id), [id])
  const [stage, setStage] = useState(params.get('start') ? 'taking' : 'intro')
  const [result, setResult] = useState(null)
  const [round, setRound] = useState(0) // bumps on retake so Runner remounts fresh

  const finish = (r) => { setResult(r); setStage('result'); state.reload() }
  const start = () => { setRound((n) => n + 1); setResult(null); setStage('taking') }

  return (
    <>
      <Topbar title="Quizzes" />
      <Async state={state}>{(quiz) => (
        <section className="mt-2 rounded-[10px] bg-white p-3 shadow-panel sm:p-6">
          {stage === 'intro' && <Intro quiz={quiz} onStart={start} />}
          {stage === 'taking' && <Runner key={round} quiz={quiz} onDone={finish} />}
          {stage === 'result' && <Result quiz={quiz} result={result} onRetake={start} />}
        </section>)}
      </Async>
    </>
  )
}

function Intro({ quiz, onStart }) {
  return (
    <div className="mx-auto max-w-xl py-6 text-center">
      <p className="text-sm font-bold text-gray-500">{quiz.subject}</p>
      <h2 className="mt-1 text-3xl font-bold">{quiz.title}</h2>
      <dl className="mt-6 grid grid-cols-3 gap-4 text-sm">
        <div className="rounded-[10px] bg-surface-muted p-4"><dt className="text-gray-500">Questions</dt><dd className="text-xl font-bold">{quiz.questionCount}</dd></div>
        <div className="rounded-[10px] bg-surface-muted p-4"><dt className="text-gray-500">Points</dt><dd className="text-xl font-bold">{quiz.totalPoints}</dd></div>
        <div className="rounded-[10px] bg-surface-muted p-4"><dt className="text-gray-500">Time</dt><dd className="text-xl font-bold">{quiz.durationMinutes ? `${quiz.durationMinutes} min` : 'Untimed'}</dd></div>
      </dl>
      {quiz.attempts > 0 && <p className="mt-4 text-sm font-bold text-green-700">Your best: {quiz.bestScore}/{quiz.totalPoints} · {quiz.attempts} attempt{quiz.attempts > 1 ? 's' : ''}</p>}
      <p className="mt-4 text-xs text-gray-500">Each question has one correct answer. You can go back and change answers before submitting.{quiz.durationMinutes ? ' The quiz submits automatically when time runs out.' : ''}</p>
      <div className="mt-6 flex justify-center gap-4">
        <Link to="/student/quizzes" className="btn-outline">Back</Link>
        <button onClick={onStart} className="btn-primary px-10">{quiz.attempts > 0 ? 'Retake quiz' : 'Start quiz'}</button>
      </div>
    </div>
  )
}

function Runner({ quiz, onDone }) {
  const [answers, setAnswers] = useState({})
  const [i, setI] = useState(0)
  const [left, setLeft] = useState(quiz.durationMinutes ? quiz.durationMinutes * 60 : null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const answersRef = useRef(answers); answersRef.current = answers
  const sent = useRef(false)
  const qs = quiz.questions
  const q = qs[i]
  const answered = Object.keys(answers).length

  const submit = async (auto = false) => {
    if (sent.current) return
    if (!auto && answered < qs.length && !window.confirm(`You have ${qs.length - answered} unanswered question(s). Submit anyway?`)) return
    sent.current = true; setBusy(true); setError('')
    try { onDone(await quizzesApi.submit(quiz.id, answersRef.current)) }
    catch (e) { sent.current = false; setBusy(false); setError(e.message) }
  }
  const submitRef = useRef(submit); submitRef.current = submit

  useEffect(() => {
    if (!quiz.durationMinutes) return
    const end = Date.now() + quiz.durationMinutes * 60000
    const t = setInterval(() => {
      const s = Math.max(0, Math.round((end - Date.now()) / 1000))
      setLeft(s)
      if (s === 0) { clearInterval(t); submitRef.current(true) }
    }, 1000)
    return () => clearInterval(t)
  }, [quiz.durationMinutes])

  if (!q) return <p className="p-6 text-sm">This quiz has no questions yet.</p>
  return (
    <div>
      <div className="flex flex-wrap items-center gap-4">
        <div><h2 className="text-xl font-bold">{quiz.title}</h2><p className="text-xs font-bold text-gray-500">{quiz.subject}</p></div>
        <span className="ml-auto text-sm font-bold">{answered}/{qs.length} answered</span>
        {left !== null && <span className={`rounded-lg px-4 py-2 text-sm font-bold tabular-nums ${left < 60 ? 'bg-red-100 text-red-700' : 'bg-brand-soft text-brand'}`} aria-live="off">⏱ {fmtTime(left)}</span>}
      </div>
      <div className="mt-3 h-2 rounded-full bg-accent-lilac"><div className="h-full rounded-full bg-brand transition-all" style={{ width: `${((i + 1) / qs.length) * 100}%` }} /></div>

      <div className="mt-6 rounded-[10px] bg-surface-muted p-4 shadow-row sm:p-6">
        <p className="text-xs font-bold text-gray-500">Question {i + 1} of {qs.length} · {q.points} point{q.points > 1 ? 's' : ''}</p>
        <h3 className="mt-2 text-lg font-bold">{q.text}</h3>
        <div role="radiogroup" aria-label={`Choices for question ${i + 1}`} className="mt-5 grid gap-3 md:grid-cols-2">
          {q.choices.map((c, k) => {
            const on = answers[q.id] === k
            return (
              <button key={k} role="radio" aria-checked={on} onClick={() => setAnswers({ ...answers, [q.id]: k })}
                className={`flex items-center gap-3 rounded-[10px] border-2 px-4 py-3 text-left transition ${on ? 'border-brand bg-brand-soft' : 'border-transparent bg-white hover:border-brand/40'}`}>
                <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${on ? 'bg-brand text-white' : 'bg-surface-gray'}`}>{LETTERS[k]}</span>
                <span className="text-sm">{c || <em className="text-gray-400">(empty choice)</em>}</span>
              </button>)
          })}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2" aria-label="Question navigator">
        {qs.map((x, n) => (
          <button key={x.id} onClick={() => setI(n)} aria-label={`Go to question ${n + 1}${answers[x.id] !== undefined ? ' (answered)' : ''}`}
            className={`h-8 w-8 rounded-full text-xs font-bold ${n === i ? 'ring-2 ring-brand ring-offset-2' : ''} ${answers[x.id] !== undefined ? 'bg-brand text-white' : 'bg-surface-gray'}`}>{n + 1}</button>))}
      </div>

      {error && <p className="mt-3 text-sm text-red-600">{error} <button onClick={() => submit(true)} className="font-bold underline">Retry</button></p>}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <button disabled={i === 0} onClick={() => setI(i - 1)} className="btn-outline disabled:opacity-40">← Previous</button>
        <div className="flex flex-wrap gap-3">
          {i < qs.length - 1 && <button onClick={() => setI(i + 1)} className="btn-outline">Next →</button>}
          <button disabled={busy} onClick={() => submit(false)} className="btn-primary px-8">{busy ? 'Submitting…' : 'Submit quiz'}</button>
        </div>
      </div>
    </div>
  )
}

function Result({ quiz, result, onRetake }) {
  const nav = useNavigate()
  const pass = result.percent >= 50
  return (
    <div>
      <div className="mx-auto max-w-md rounded-[20px] bg-surface-muted p-8 text-center shadow-panel">
        <p className="text-sm font-bold text-gray-500">{quiz.title} · {quiz.subject}</p>
        <p className={`mt-2 text-5xl font-bold ${pass ? 'text-green-600' : 'text-accent-orange'}`}>{result.score}<span className="text-2xl text-gray-400">/{result.total}</span></p>
        <p className="mt-1 text-sm font-bold">{result.percent}% · {pass ? 'Well done!' : 'Keep practising!'}</p>
        <p className="mt-1 text-xs text-gray-500">Best: {result.bestScore}/{result.total} · Attempts: {result.attempts}</p>
        <div className="mt-5 flex justify-center gap-3">
          <button onClick={() => nav('/student/quizzes')} className="btn-outline">All quizzes</button>
          <button onClick={onRetake} className="btn-primary">Retake</button>
        </div>
      </div>
      <h3 className="mt-8 text-xl font-bold">Review your answers</h3>
      <ol className="mt-3 space-y-4">
        {result.review.map((r, n) => (
          <li key={r.id} className={`rounded-[10px] border-l-4 bg-surface-muted p-4 ${r.isCorrect ? 'border-green-600' : 'border-red-500'}`}>
            <p className="text-sm font-bold">{n + 1}. {r.text} <span className={`ml-2 text-xs ${r.isCorrect ? 'text-green-700' : 'text-red-600'}`}>{r.isCorrect ? `+${r.points}` : r.chosen === null ? 'Skipped' : 'Incorrect'}</span></p>
            <ul className="mt-2 grid gap-2 md:grid-cols-2">
              {r.choices.map((c, k) => {
                const isRight = k === r.correct, isMine = k === r.chosen
                return (
                  <li key={k} className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm ${isRight ? 'bg-pastel-green' : isMine ? 'bg-pastel-pink' : 'bg-white'}`}>
                    <span className="font-bold">{LETTERS[k]}.</span><span className="flex-1">{c}</span>
                    {isRight && <span className="text-xs font-bold text-green-800">Correct</span>}
                    {isMine && !isRight && <span className="text-xs font-bold text-red-700">Your answer</span>}
                  </li>)
              })}
            </ul>
          </li>))}
      </ol>
    </div>
  )
}
