const BASE = import.meta.env.VITE_API_URL || '/api'
export const USE_MOCK = String(import.meta.env.VITE_USE_MOCK) === 'true'

function csrfCookie() {
  const entry = document.cookie.split('; ').find((item) => item.startsWith('csrftoken='))
  return entry ? decodeURIComponent(entry.slice('csrftoken='.length)) : ''
}

export class ApiError extends Error {
  constructor(message, status, data) { super(message); this.status = status; this.data = data }
}

export async function http(path, { method = 'GET', body, headers = {}, isForm = false } = {}) {
  const verb = method.toUpperCase()
  const csrf = csrfCookie()
  const res = await fetch(`${BASE}${path}`, {
    method: verb,
    credentials: 'include',
    headers: {
      ...(isForm || body === undefined ? {} : { 'Content-Type': 'application/json' }),
      ...(!['GET', 'HEAD', 'OPTIONS', 'TRACE'].includes(verb) && csrf ? { 'X-CSRFToken': csrf } : {}),
      ...headers,
    },
    body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
  })
  const data = res.status === 204 ? null : await res.json().catch(() => null)
  if (!res.ok) {
    if (res.status === 401) window.dispatchEvent(new Event('auth:expired'))
    throw new ApiError(data?.message || res.statusText, res.status, data)
  }
  return data
}

export const get = (p) => http(p)
export const post = (p, body) => http(p, { method: 'POST', body })
export const put = (p, body) => http(p, { method: 'PUT', body })
export const del = (p) => http(p, { method: 'DELETE' })

// Returns mock data (small delay) when VITE_USE_MOCK=true, else performs the real call.
export const withMock = (mockValue, realFn) =>
  USE_MOCK ? new Promise((r) => setTimeout(() => r(structuredClone(mockValue)), 150)) : realFn()

// Lazy version for stateful mocks: `fn` runs at call time and may throw an ApiError.
export const withMockFn = (fn, realFn) =>
  USE_MOCK
    ? new Promise((resolve, reject) => setTimeout(() => { try { resolve(structuredClone(fn())) } catch (e) { reject(e) } }, 150))
    : realFn()
