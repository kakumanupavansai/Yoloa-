// One function per backend endpoint. Set VITE_USE_MOCK=false and implement these routes.
// See README.md -> "Backend API contract".
import * as m from '../data/mock'
import { get, post, put, del, http, withMock, withMockFn, ApiError, USE_MOCK } from './http'

export const authApi = {
  csrf: () => get('/auth/csrf'),
  login: ({ email, username, password, role }) =>
    withMock({ user: m.mockUsers[role || 'student'] }, () => post('/auth/login', { email: email || username, password, role })),
  me: () => withMock(m.mockUsers[localStorage.getItem('yoloa_role') || 'student'], () => get('/auth/me')),
  logout: () => withMock({ ok: true }, () => post('/auth/logout', {})),
  register: (data) => withMock({ user: m.mockUsers.student }, () => post('/auth/register', data)),
  requestPasswordReset: (email) => withMock({ message: 'If an account exists for that email, password reset instructions have been sent.' }, () => post('/auth/password-reset', { email })),
  resetPassword: (data) => withMock({ message: 'Password updated. Please sign in with your new password.' }, () => post('/auth/password-reset/confirm', data)),
}

export const dashboardApi = {
  student: () => withMock(m.mockDashboard, () => get('/student/dashboard')),
  admin: () => withMock(m.mockAdminDashboard, () => get('/admin/dashboard')),
}

// ── mock-mode helpers (only used when VITE_USE_MOCK=true) ──
const mockCourse = (id) => m.mockCourses.find((c) => String(c.id) === String(id)) || m.mockCourses[0]

export const coursesApi = {
  // GET /courses -> [{id,title,status:'ongoing'|'completed'|'available',enrolled,percent,chapters,cover,enrollment}]
  list: () => withMock(m.mockCourses, () => get('/courses')),
  // GET /courses/:id -> {..., enrolled, percent, chapters[{id,title,duration,completed}]}
  get: (id) => withMockFn(() => { const c = mockCourse(id); return { ...m.mockCourseDetail, id: c.id, enrolled: c.enrolled, percent: c.percent,
    chapters: m.mockPlayer.modules.map(({ id, title, duration, completed }) => ({ id, title, duration, completed })) } }, () => get(`/courses/${id}`)),
  // GET /courses/:id/player -> 403 if the student is not enrolled
  player: (id) => withMockFn(() => {
    const c = mockCourse(id)
    if (!c.enrolled) throw new ApiError('Enroll in this course to start learning.', 403)
    const cur = m.mockPlayer.modules.find((x) => !x.completed) || m.mockPlayer.modules.at(-1)
    return { ...m.mockPlayer, courseId: c.id, courseTitle: c.title, percent: c.percent, currentModuleId: cur.id, lessonTitle: cur.title, videoUrl: cur.videoUrl }
  }, () => get(`/courses/${id}/player`)),
  // POST /courses/:id/enroll  ·  DELETE /courses/:id/enroll
  enroll: (id) => withMockFn(() => { const c = mockCourse(id); Object.assign(c, { enrolled: true, status: 'ongoing' }); return { enrolled: true, percent: c.percent, status: c.status } }, () => post(`/courses/${id}/enroll`)),
  unenroll: (id) => withMockFn(() => { Object.assign(mockCourse(id), { enrolled: false, status: 'available' }); return null }, () => del(`/courses/${id}/enroll`)),
  // DELETE /courses/:id  (admin only; also removes chapters, enrollments and progress)
  remove: (id) => withMockFn(() => { const i = m.mockCourses.findIndex((c) => String(c.id) === String(id)); if (i >= 0) m.mockCourses.splice(i, 1); return null }, () => del(`/courses/${id}`)),
  // POST /courses (multipart: title, description, startDate, endDate, chapters (JSON [{title,videoUrl}]), cover file)
  create: (formData) => withMock({ ok: true }, () => http('/courses', { method: 'POST', body: formData, isForm: true })),
}

export const chaptersApi = {
  // PUT /chapters/:id/progress {completed} -> {chapterId,completed,percent,status,currentChapter,courseCompleted}
  setComplete: (courseId, chapterId, completed) => withMockFn(() => {
    const mod = m.mockPlayer.modules.find((x) => x.id === chapterId); mod.completed = completed
    const done = m.mockPlayer.modules.filter((x) => x.completed).length
    const c = mockCourse(courseId)
    Object.assign(c, { percent: Math.round((done * 100) / m.mockPlayer.modules.length) })
    c.status = c.percent === 100 ? 'completed' : 'ongoing'
    return { chapterId, completed, percent: c.percent, status: c.status, courseCompleted: c.percent === 100 }
  }, () => put(`/chapters/${chapterId}/progress`, { completed })),
}

// Student quizzes = the exams the admin has published (same records, see examsApi below).
const publishedMock = () => m.mockExams.filter((e) => e.status === 'Published' && e.questions > 0)
const quizMock = (id) => {
  const e = publishedMock().find((x) => String(x.id) === String(id))
  if (!e) throw new ApiError('Not found.', 404)
  return e
}

export const quizzesApi = {
  // GET /quizzes -> [{id,title,subject,questions,points,attempts,bestScore}]
  list: () => withMockFn(() => publishedMock().map(({ id, title, subject, questions, points, attempts, bestScore }) => ({ id, title, subject, questions, points, attempts, bestScore })), async () => {
    const rows = await get('/quizzes')
    return rows.map((row) => ({ ...row, durationMinutes: row.durationSeconds ? Math.round(row.durationSeconds / 60) : parseInt(row.duration, 10) || null,
      questionCount: row.questionCount || row.questions, totalPoints: row.totalPoints || row.points }))
  }),
  // GET /quizzes/:id -> {title,subject,duration,durationMinutes,questionCount,totalPoints,attempts,bestScore,questions[{id,text,choices,points}]}
  get: (id) => withMockFn(() => {
    const e = quizMock(id), qs = m.mockQuizQuestions(e)
    return { id: e.id, title: e.title, subject: e.subject, duration: e.duration, durationMinutes: parseInt(e.duration) || null,
      questionCount: qs.length, totalPoints: qs.reduce((n, q) => n + q.points, 0), attempts: e.attempts, bestScore: e.bestScore,
      questions: qs.map(({ correct, ...rest }) => rest) }
  }, async () => {
    const row = await get(`/quizzes/${id}`)
    return { ...row, durationMinutes: row.durationSeconds ? Math.round(row.durationSeconds / 60) : parseInt(row.duration, 10) || null,
      questionCount: row.questionCount || row.questions?.length || 0, totalPoints: row.totalPoints || row.points || 0 }
  }),
  // The server creates or resumes the persistent attempt. These methods are intentionally separate from submit.
  start: (id) => withMock({ attemptId: `mock-${id}`, status: 'in_progress', answers: {}, answerVersion: 0, deadline: null }, () => post(`/assessments/${id}/start`, {})),
  save: (attemptId, answers, version) => withMock({ answers, answerVersion: Number(version || 0) + 1, savedAt: new Date().toISOString() }, () => put(`/attempts/${attemptId}/answers`, { answers, version })),
  // POST /quizzes/:id/attempts {answers:{questionId:index}} -> {score,total,percent,review[],attempts,bestScore}
  submit: (id, answers) => withMockFn(() => {
    const e = quizMock(id)
    let score = 0, total = 0
    const review = m.mockQuizQuestions(e).map((qq) => {
      const chosen = answers[qq.id] ?? null, isCorrect = chosen === qq.correct
      total += qq.points; if (isCorrect) score += qq.points
      return { id: qq.id, text: qq.text, choices: qq.choices, chosen, correct: qq.correct, isCorrect, points: qq.points }
    })
    e.attempts += 1; e.bestScore = Math.max(e.bestScore ?? 0, score)
    return { score, total, percent: total ? Math.round((score * 100) / total) : 0, review, attempts: e.attempts, bestScore: e.bestScore }
  }, () => post(`/quizzes/${id}/attempts`, { answers })),
}

export const assessmentsApi = {
  list: () => withMock([], () => get('/assessments')),
  get: (id) => withMockFn(() => quizMock(id), () => get(`/assessments/${id}`)),
  start: (id) => withMock({ attemptId: `mock-final-${id}`, status: 'in_progress', answers: {}, answerVersion: 0, deadline: null }, () => post(`/assessments/${id}/start`, {})),
  save: (attemptId, answers, version) => withMock({ answers, answerVersion: Number(version || 0) + 1, savedAt: new Date().toISOString() }, () => put(`/attempts/${attemptId}/answers`, { answers, version })),
  submit: (attemptId) => withMock({ status: 'submitted', score: 0, total: 0, percent: 0, passed: false, review: [] }, () => post(`/attempts/${attemptId}/submit`, {})),
  history: (id) => withMock([], () => get(`/assessments/${id}/history`)),
}

export const adminApi = {
  students: (params = {}) => withMock({ results: [], page: 1, pageSize: Number(params.pageSize || 20), total: 0 }, () => get(`/admin/students?${new URLSearchParams(params)}`)),
  student: (id) => withMock({ id, name: 'Mock student', email: 'student@example.com', enrollments: [], assessments: [] }, () => get(`/admin/students/${id}`)),
  loginAnalytics: (params = {}) => withMock({ metrics: { successfulLogins: 0, uniqueSignedIn: 0, registeredStudents: 0, newRegistrations: 0, emailPasswordLogins: 0, googleLogins: 0, legacyJwtLogins: 0 }, events: [], page: 1, pageSize: 50, total: 0 }, () => get(`/admin/analytics/logins?${new URLSearchParams(params)}`)),
  examAnalytics: (params = {}) => withMock({ assessments: [], totals: { attempts: 0, passed: 0, averagePercent: 0, averageDurationSeconds: 0 } }, () => get(`/admin/analytics/exams?${new URLSearchParams(params)}`)),
  uploadQuestions: (formData) => withMock({ batchId: 'mock-import', sheets: [{ name: 'Sheet1', headers: [] }] }, () => http('/admin/question-imports/upload', { method: 'POST', body: formData, isForm: true })),
  previewQuestions: (batchId, payload) => withMock({ batchId, validCount: 0, invalidCount: 0, errors: [], rows: [] }, () => post(`/admin/question-imports/${batchId}/preview`, payload)),
  confirmQuestions: (batchId, idempotencyKey) => withMock({ batchId, imported: 0 }, () => post(`/admin/question-imports/${batchId}/confirm`, { idempotencyKey })),
}

export const libraryApi = { list: () => withMock(m.mockLibrary, () => get('/library')) }
export const notesApi = { apps: () => withMock(m.mockNotesApps, () => get('/notes/apps')) }

export const calendarApi = {
  month: (year, month) => withMock(m.mockCalendar, () => get(`/calendar?year=${year}&month=${month}`)),
  create: (event) => withMock(event, () => post('/calendar', event)),
}

export const profileApi = {
  get: () => withMock(m.mockUsers.student, () => get('/profile')),
  update: (data) => withMock(data, () => put('/profile', data)),
  uploadAvatar: (formData) => withMock({ url: '' }, () => http('/profile/avatar', { method: 'POST', body: formData, isForm: true })),
}

// Same publish rules as the server (a published exam is what students see, so it must be complete).
const assertPublishable = (items) => {
  if (!items.length) throw new ApiError('Add at least one question before publishing.', 400)
  items.forEach((q, i) => {
    if (!q.text?.trim() || q.choices.filter((c) => c?.trim()).length < 2) throw new ApiError(`Question ${i + 1} needs text and at least 2 choices.`, 400)
    if (!q.choices[q.correct]?.trim()) throw new ApiError(`Question ${i + 1}: the correct choice is empty.`, 400)
  })
}
const examRow = ({ items, attempts, bestScore, ...row }) => row

export const examsApi = {
  // Admin exam builder. A Published exam appears in the student Quizzes list (same record); Draft is admin-only.
  list: () => withMockFn(() => m.mockExams.map(examRow), () => get('/exams')),
  get: (id) => get(`/exams/${id}`),
  // body: { title, subject, duration, status: 'draft'|'published', questions: [{text, choices[4], correct, score, points}] }
  create: (exam) => withMockFn(() => {
    if (!exam.title?.trim()) throw new ApiError('title: This field is required.', 400)
    const id = Math.max(0, ...m.mockExams.map((e) => e.id)) + 1
    const items = (exam.questions || []).map((q, i) => ({ id: id * 100 + i, text: q.text || '', choices: q.choices, correct: Number(q.correct) || 0,
      points: Number(q.points) || Number(q.score) || 1 }))
    if (exam.status === 'published') assertPublishable(items)
    const row = { id, title: exam.title, subject: exam.subject || '', term: '1st Term', duration: exam.duration || '', questions: items.length,
      points: items.reduce((n, q) => n + q.points, 0), status: exam.status === 'published' ? 'Published' : 'Draft', attempts: 0, bestScore: null, items }
    m.mockExams.push(row); return examRow(row)
  }, () => post('/exams', exam)),
  // PUT /exams/:id  e.g. { status: 'published' } to publish, { status: 'draft' } to hide from students
  update: (id, patch) => withMockFn(() => {
    const e = m.mockExams.find((x) => x.id === id); if (!e) throw new ApiError('Not found.', 404)
    if (patch.status === 'published') assertPublishable(m.mockQuizQuestions(e).length ? (e.items || m.mockQuizQuestions(e)) : [])
    Object.assign(e, patch.title ? { title: patch.title } : {}, patch.status ? { status: patch.status === 'published' ? 'Published' : 'Draft' } : {})
    return examRow(e)
  }, () => put(`/exams/${id}`, patch)),
  // DELETE /exams/:id  -> also disappears from the student Quizzes list
  remove: (id) => withMockFn(() => { const i = m.mockExams.findIndex((e) => e.id === id); if (i >= 0) m.mockExams.splice(i, 1); return null }, () => del(`/exams/${id}`)),
}

export const announcementsApi = {
  create: (data) => withMock(data, () => post('/announcements', data)),
}
