import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { authApi } from '../services/api'
import { USE_MOCK } from '../services/http'
import { mockUsers } from '../data/mock'

const AuthContext = createContext(null)
export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (USE_MOCK) {
      const role = localStorage.getItem('yoloa_role')
      setUser(role ? mockUsers[role] || null : null)
      setLoading(false)
      return
    }
    authApi.csrf().then(() => authApi.me()).then(setUser).catch(() => setUser(null)).finally(() => setLoading(false))
  }, [])

  const logout = useCallback(() => {
    if (USE_MOCK) authApi.logout()
    else authApi.logout().catch(() => {})
    localStorage.removeItem('yoloa_role')
    setUser(null)
  }, [])
  const expireSession = useCallback(() => { localStorage.removeItem('yoloa_role'); setUser(null) }, [])
  useEffect(() => {
    window.addEventListener('auth:expired', expireSession)
    return () => window.removeEventListener('auth:expired', expireSession)
  }, [expireSession])

  const login = async (creds) => {
    if (!USE_MOCK) await authApi.csrf()
    const { user } = await authApi.login(creds)
    if (USE_MOCK) localStorage.setItem('yoloa_role', user.role)
    setUser(user)
    return user
  }

  return <AuthContext.Provider value={{ user, loading, login, logout, setUser, mock: USE_MOCK }}>{children}</AuthContext.Provider>
}
