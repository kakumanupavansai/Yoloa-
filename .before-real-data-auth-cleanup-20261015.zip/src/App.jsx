import { Routes, Route, Navigate } from 'react-router-dom'
import AppLayout from './components/layout/AppLayout'
import ProtectedRoute from './routes/ProtectedRoute'
import Landing from './pages/Landing'
import Login from './pages/Login'
import Register from './pages/Register'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import StudentDashboard from './pages/student/Dashboard'
import Courses from './pages/student/Courses'
import CourseDetail from './pages/student/CourseDetail'
import CoursePlayer from './pages/student/CoursePlayer'
import CalendarPage from './pages/student/Calendar'
import Notes from './pages/student/Notes'
import Quizzes from './pages/student/Quizzes'
import QuizTake from './pages/student/QuizTake'
import Library from './pages/student/Library'
import Profile from './pages/student/Profile'
import AdminDashboard from './pages/admin/Dashboard'
import Exams from './pages/admin/Exams'
import ExamCreation from './pages/admin/ExamCreation'
import CourseCreation from './pages/admin/CourseCreation'
import Students from './pages/admin/Students'
import StudentDetail from './pages/admin/StudentDetail'
import Analytics from './pages/admin/Analytics'
import QuestionImport from './pages/admin/QuestionImport'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      <Route element={<ProtectedRoute role="student" />}>
        <Route path="/student" element={<AppLayout />}>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<StudentDashboard />} />
          <Route path="courses" element={<Courses />} />
          <Route path="courses/:id" element={<CourseDetail />} />
          <Route path="courses/:id/watch" element={<CoursePlayer />} />
          <Route path="calendar" element={<CalendarPage />} />
          <Route path="notes" element={<Notes />} />
          <Route path="quizzes" element={<Quizzes />} />
          <Route path="quizzes/:id" element={<QuizTake />} />
          <Route path="exams/:id" element={<QuizTake final />} />
          <Route path="library" element={<Library />} />
          <Route path="profile" element={<Profile />} />
        </Route>
      </Route>

      <Route element={<ProtectedRoute role="admin" />}>
        <Route path="/admin" element={<AppLayout />}>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="courses" element={<Courses admin />} />
          <Route path="courses/:id" element={<CourseDetail admin />} />
          <Route path="course-creation" element={<CourseCreation />} />
          <Route path="exams" element={<Exams />} />
          <Route path="exams/new" element={<ExamCreation />} />
          <Route path="students" element={<Students />} />
          <Route path="students/:id" element={<StudentDetail />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="question-import" element={<QuestionImport />} />
          <Route path="library" element={<Library />} />
          <Route path="profile" element={<Profile />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
