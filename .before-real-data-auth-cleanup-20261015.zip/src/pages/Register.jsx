import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Logo from '../components/ui/Logo'
import { authApi } from '../services/api'
import { USE_MOCK } from '../services/http'
import { useAuth } from '../context/AuthContext'

export default function Register() {
  const nav = useNavigate()
  const { setUser } = useAuth()
  const [form, setForm] = useState({ fullName: '', email: '', password: '', passwordConfirmation: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const update = (field) => (event) => setForm((current) => ({ ...current, [field]: event.target.value }))
  const submit = async (event) => {
    event.preventDefault(); setError(''); setBusy(true)
    try {
      if (!USE_MOCK) await authApi.csrf()
      const result = await authApi.register(form)
      setUser(result.user)
      if (USE_MOCK) localStorage.setItem('yoloa_role', 'student')
      nav('/student/dashboard', { replace: true })
    } catch (err) { setError(err.message || 'Could not create your account.') }
    finally { setBusy(false) }
  }
  return <main className="flex min-h-screen items-center justify-center bg-gradient-to-b from-white to-[#e9e9e9] px-4 py-8">
    <form onSubmit={submit} className="card w-full max-w-md space-y-4 rounded-2xl p-6 sm:p-9">
      <Logo className="mb-3 text-[28px]" /><h1 className="text-2xl font-bold">Create your student account</h1>
      <label className="block text-sm font-semibold">Full name<input className="input mt-1 w-full" autoComplete="name" required value={form.fullName} onChange={update('fullName')} /></label>
      <label className="block text-sm font-semibold">Email address<input className="input mt-1 w-full" type="email" autoComplete="email" required value={form.email} onChange={update('email')} /></label>
      <label className="block text-sm font-semibold">Password<div className="relative mt-1"><input className="input w-full pr-14" type={showPassword ? 'text' : 'password'} autoComplete="new-password" minLength={8} required value={form.password} onChange={update('password')} /><button type="button" className="absolute right-3 top-3 text-xs font-bold text-brand" onClick={() => setShowPassword((shown) => !shown)}>{showPassword ? 'Hide' : 'Show'}</button></div></label>
      <label className="block text-sm font-semibold">Confirm password<input className="input mt-1 w-full" type="password" autoComplete="new-password" required value={form.passwordConfirmation} onChange={update('passwordConfirmation')} /></label>
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      <button disabled={busy} className="btn-primary w-full disabled:opacity-60">{busy ? 'Creating account…' : 'Create account'}</button>
      <p className="text-center text-sm text-gray-600">Already registered? <Link to="/login?role=student" className="font-bold text-brand underline">Sign in</Link></p>
    </form>
  </main>
}
