import { useState } from 'react'
import { Link } from 'react-router-dom'
import Logo from '../components/ui/Logo'
import { authApi } from '../services/api'
import { USE_MOCK } from '../services/http'

export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async (event) => {
    event.preventDefault(); setError(''); setMessage(''); setBusy(true)
    try { if (!USE_MOCK) await authApi.csrf(); const result = await authApi.requestPasswordReset(email); setMessage(result.message) }
    catch (err) { setError(err.message || 'Could not send the reset request.') }
    finally { setBusy(false) }
  }
  return <main className="flex min-h-screen items-center justify-center bg-gradient-to-b from-white to-[#e9e9e9] px-4 py-8"><form onSubmit={submit} className="card w-full max-w-md space-y-4 rounded-2xl p-6 sm:p-9">
    <Logo className="mb-3 text-[28px]" /><h1 className="text-2xl font-bold">Reset your password</h1><p className="text-sm text-gray-600">Enter your account email and we’ll send reset instructions if it matches an account.</p>
    <label className="block text-sm font-semibold">Email address<input className="input mt-1 w-full" type="email" autoComplete="email" required value={email} onChange={(event) => setEmail(event.target.value)} /></label>
    {message && <p role="status" className="text-sm text-green-700">{message}</p>}{error && <p role="alert" className="text-sm text-red-600">{error}</p>}
    <button disabled={busy} className="btn-primary w-full disabled:opacity-60">{busy ? 'Sending…' : 'Send reset link'}</button><Link className="block text-center text-sm font-semibold text-brand underline" to="/login?role=student">Back to sign in</Link>
  </form></main>
}
