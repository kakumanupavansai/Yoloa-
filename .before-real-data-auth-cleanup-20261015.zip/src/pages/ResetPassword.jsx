import { useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import Logo from '../components/ui/Logo'
import { authApi } from '../services/api'
import { USE_MOCK } from '../services/http'

export default function ResetPassword() {
  const [params] = useSearchParams()
  const nav = useNavigate()
  const [password, setPassword] = useState('')
  const [confirmation, setConfirmation] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async (event) => {
    event.preventDefault(); setError('')
    if (password !== confirmation) { setError('Passwords do not match.'); return }
    setBusy(true)
    try { if (!USE_MOCK) await authApi.csrf(); await authApi.resetPassword({ uid: params.get('uid'), token: params.get('token'), password }); nav('/login?role=student', { replace: true }) }
    catch (err) { setError(err.message || 'This reset link could not be used.') }
    finally { setBusy(false) }
  }
  return <main className="flex min-h-screen items-center justify-center bg-gradient-to-b from-white to-[#e9e9e9] px-4 py-8"><form onSubmit={submit} className="card w-full max-w-md space-y-4 rounded-2xl p-6 sm:p-9">
    <Logo className="mb-3 text-[28px]" /><h1 className="text-2xl font-bold">Choose a new password</h1>
    <label className="block text-sm font-semibold">New password<input className="input mt-1 w-full" type="password" autoComplete="new-password" minLength={8} required value={password} onChange={(event) => setPassword(event.target.value)} /></label>
    <label className="block text-sm font-semibold">Confirm new password<input className="input mt-1 w-full" type="password" autoComplete="new-password" required value={confirmation} onChange={(event) => setConfirmation(event.target.value)} /></label>
    {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
    <button disabled={busy || !params.get('uid') || !params.get('token')} className="btn-primary w-full disabled:opacity-60">{busy ? 'Saving…' : 'Update password'}</button><Link className="block text-center text-sm font-semibold text-brand underline" to="/login?role=student">Back to sign in</Link>
  </form></main>
}
