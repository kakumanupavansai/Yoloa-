import { useEffect, useRef, useState } from 'react'
import { useApi } from '../../hooks'
import { USE_MOCK } from '../../services/http'
import { profileApi } from '../../services/api'
import { useAuth } from '../../context/AuthContext'
import Topbar from '../../components/layout/Topbar'
import Avatar from '../../components/ui/Avatar'
import { Async } from '../../components/ui/States'

function Field({ label, name, form, setForm, editing, className = '' }) {
  return (
    <div className={className}>
      <label className="mb-1 block text-sm font-bold" htmlFor={name}>{label}</label>
      <input id={name} disabled={!editing} value={form[name] ?? ''} onChange={(e) => setForm({ ...form, [name]: e.target.value })}
        className="w-full rounded-lg border border-black/60 bg-surface px-3 py-3 outline-none disabled:opacity-80 focus:border-brand" />
    </div>)
}

// Figma: Desktop - 15
export default function Profile() {
  const state = useApi(() => profileApi.get(), [])
  const { setUser } = useAuth()
  const fileRef = useRef()
  const [form, setForm] = useState({})
  const [edit, setEdit] = useState({ user: false, contact: false })
  const [msg, setMsg] = useState('')
  useEffect(() => { if (state.data) setForm(state.data) }, [state.data])

  const save = async (section) => {
    try { const saved = await profileApi.update(form); setUser((u) => ({ ...u, ...saved })); setEdit({ ...edit, [section]: false }); setMsg('Saved') }
    catch (e) { setMsg(e.message) }
  }
  const upload = async (e) => {
    const file = e.target.files[0]; if (!file) return
    const fd = new FormData(); fd.append('avatar', file)
    try { const { url } = await profileApi.uploadAvatar(fd); setForm((f) => ({ ...f, avatar: url || URL.createObjectURL(file) })) } catch (err) { setMsg(err.message) }
  }
  const btn = (section) => edit[section]
    ? <button onClick={() => save(section)} className="btn-primary px-8">Save</button>
    : <button onClick={() => setEdit({ ...edit, [section]: true })} className="rounded-lg border border-black bg-white px-10 py-3">Edit</button>

  return (
    <>
      <Topbar title="My profile" />
      <Async state={state}>{() => (
        <section className="card mt-2 grid gap-8 rounded-[20px] p-4 sm:p-8 lg:grid-cols-[1fr_260px]">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-4 sm:gap-10"><h2 className="font-bold">USER INFORMATION</h2>{btn('user')}</div>
            <Field label="Username" name="username" {...{ form, setForm }} editing={edit.user} />
            <Field label="Email address" name="email" {...{ form, setForm }} editing={edit.user} />
            <Field label="First name" name="firstName" {...{ form, setForm }} editing={edit.user} />
            <Field label="Last name" name="lastName" {...{ form, setForm }} editing={edit.user} />
            {!USE_MOCK && <div className="rounded-lg bg-surface-muted p-4"><p className="font-bold">Google account</p><p className="mt-1 text-sm text-gray-600">Linking requires a verified Google account with this same email address.</p><a href={`${import.meta.env.VITE_API_URL || '/api'}/auth/google?mode=link`} className="mt-3 inline-block rounded-lg border border-gray-400 bg-white px-4 py-2 text-sm font-bold">Link Google account</a></div>}
            <div className="flex flex-wrap items-center gap-4 pt-4 sm:gap-10"><h2 className="font-bold">CONTACT INFORMATION</h2>{btn('contact')}</div>
            <Field label="Address" name="address" {...{ form, setForm }} editing={edit.contact} className="max-w-lg" />
            <div className="grid max-w-xl grid-cols-1 gap-4 sm:grid-cols-3">
              <Field label="Country" name="country" {...{ form, setForm }} editing={edit.contact} />
              <Field label="Postal code" name="postalCode" {...{ form, setForm }} editing={edit.contact} />
              <Field label="City" name="city" {...{ form, setForm }} editing={edit.contact} />
            </div>
            {msg && <p className="text-sm text-brand">{msg}</p>}
          </div>
          <div className="order-first flex flex-col items-center gap-6 lg:order-none lg:pt-10">
            <Avatar src={form.avatar} name={form.firstName} size={150} />
            <input ref={fileRef} type="file" accept="image/*" hidden onChange={upload} />
            <button onClick={() => fileRef.current.click()} className="rounded-lg border border-black bg-white px-8 py-3">Change Image</button>
          </div>
        </section>)}
      </Async>
    </>
  )
}
