import { useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import Logo from '../components/ui/Logo'
import HeroArt from '../components/ui/HeroArt'

const oauthMessages = {
  google_not_configured: 'Google sign-in is not configured yet. Use your email and password for now.',
  google_cancelled_or_invalid: 'Google sign-in was cancelled or could not be verified.',
  google_verification_failed: 'Google could not verify this sign-in. Please try again.',
  google_account_link_required: 'This email already has an account. Sign in with your password, then link Google from your profile.',
  google_link_mismatch: 'Use the same verified Google email as this account to link it.',
  google_account_already_linked: 'That Google account is linked to another YOLOA account.',
  sign_in_before_linking: 'Sign in before linking a Google account.',
}

export default function Login() {
  const [params] = useSearchParams()
  const role = params.get('role') === 'admin' ? 'admin' : 'student'
  const { login, mock } = useAuth()
  const nav = useNavigate()
  const [form, setForm] = useState({ email: '', password: '' })
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState(oauthMessages[params.get('auth_error')] || '')
  const [busy, setBusy] = useState(false)

  const submit = async (event) => {
    event.preventDefault(); setError(''); setBusy(true)
    try {
      const user = await login({ ...form, role })
      nav(user.role === 'admin' ? '/admin/dashboard' : '/student/dashboard', { replace: true })
    } catch (err) { setError(err.message || 'Sign-in failed. Check your email and password.') }
    finally { setBusy(false) }
  }

  return (
    <div className="relative grid min-h-screen overflow-hidden bg-gradient-to-b from-white to-[#e9e9e9] md:grid-cols-2">
      <div className="absolute inset-y-0 right-0 hidden w-[62%] bg-hero md:block" style={{ borderTopLeftRadius: '50% 100%', borderBottomLeftRadius: '50% 100%' }} />
      <form onSubmit={submit} className="relative mx-auto flex w-full max-w-md flex-col justify-center gap-4 px-6 py-10 sm:px-8">
        <Logo className="mb-5 text-[28px]" />
        <p className="text-sm font-bold capitalize text-brand-dark">{role} sign in <Link to="/" className="ml-2 font-normal underline">change</Link></p>
        <button type="button" onClick={() => { window.location.href = `${import.meta.env.VITE_API_URL || '/api'}/auth/google` }} className="rounded-lg border border-gray-300 bg-white py-3 font-bold text-gray-800 hover:bg-gray-50">
          <span aria-hidden="true" className="mr-2 text-lg font-black text-blue-600">G</span>Continue with Google
        </button>
        <div className="flex items-center gap-3 text-xs text-gray-500"><span className="h-px flex-1 bg-gray-200" />or sign in with email<span className="h-px flex-1 bg-gray-200" /></div>
        <label className="relative block rounded-lg border border-black bg-surface px-4 pb-2 pt-5">
          <span className="absolute left-4 top-1.5 text-sm font-bold text-gray-500">Email address</span>
          <input type="email" className="w-full bg-transparent outline-none" required autoComplete="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} />
        </label>
        <label className="relative block rounded-lg border border-black bg-surface px-4 pb-2 pt-5">
          <span className="absolute left-4 top-1.5 text-sm font-bold text-gray-500">Password</span>
          <input type={showPassword ? 'text' : 'password'} className="w-full bg-transparent pr-14 outline-none" required autoComplete="current-password" value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} />
          <button type="button" onClick={() => setShowPassword((visible) => !visible)} className="absolute bottom-2 right-3 text-xs font-bold text-brand">{showPassword ? 'Hide' : 'Show'}</button>
        </label>
        <div className="flex justify-end"><Link to="/forgot-password" className="text-sm font-semibold text-brand underline">Forgot password?</Link></div>
        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        <button disabled={busy} className="rounded-lg border border-black bg-brand-dark py-4 text-sm font-bold text-white hover:opacity-90 disabled:opacity-60">{busy ? 'Signing in…' : 'Sign in'}</button>
        {mock && <p className="text-xs text-gray-500">Mock mode: any email and password works.</p>}
        {role === 'student' && <p className="text-center text-sm text-gray-600">New to YOLOA? <Link to="/register" className="font-bold text-brand underline">Create an account</Link></p>}
      </form>
      <div className="relative hidden md:block"><HeroArt /></div>
    </div>
  )
}
