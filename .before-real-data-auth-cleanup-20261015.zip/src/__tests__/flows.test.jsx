// UI flow tests in mock mode (VITE_USE_MOCK=true). Order matters: mock state is shared in-memory.
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { beforeEach, describe, expect, it } from 'vitest'
import App from '../App'
import { AuthProvider } from '../context/AuthContext'

const open = (path) => {
  localStorage.setItem('yoloa_role', 'student')
  return render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>)
}
beforeEach(() => localStorage.clear())
const MOCK = String(import.meta.env.VITE_USE_MOCK) === 'true'

describe.skipIf(!MOCK)('enrolling', () => {
  it('blocks the player for a course the student is not enrolled in', async () => {
    open('/student/courses/soc/watch')
    expect(await screen.findByText(/Enroll in this course to start learning/i)).toBeInTheDocument()
    expect(screen.getByRole('link', { name: /go to course page to enroll/i })).toBeInTheDocument()
  })

  it('shows Enroll on unenrolled cards and Resume on enrolled ones; enrolling flips the card', async () => {
    const user = userEvent.setup()
    open('/student/courses')
    await screen.findByText('Social science Department')
    expect(screen.getAllByRole('link', { name: /resume|review/i })).toHaveLength(5)
    await user.click(screen.getByRole('button', { name: 'Enroll' }))
    await waitFor(() => expect(screen.getAllByRole('link', { name: /resume|review/i })).toHaveLength(6))
    expect(screen.queryByRole('button', { name: /enroll/i })).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: /ongoing \(5\)/i })).toBeInTheDocument()
  })
})

describe.skipIf(!MOCK)('authentication screens', () => {
  it('logs in with email/password and lets the student reveal the password', async () => {
    const user = userEvent.setup()
    render(<MemoryRouter initialEntries={['/login?role=student']}><AuthProvider><App /></AuthProvider></MemoryRouter>)
    await user.type(screen.getByLabelText(/email address/i), 'swetha@example.com')
    const password = screen.getByLabelText(/password/i)
    await user.type(password, 'student123')
    await user.click(screen.getByRole('button', { name: 'Show' }))
    expect(password).toHaveAttribute('type', 'text')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))
    expect(await screen.findByRole('heading', { name: 'Dashboard' })).toBeInTheDocument()
  })

  it('creates a student account through the public registration form', async () => {
    const user = userEvent.setup()
    render(<MemoryRouter initialEntries={['/register']}><AuthProvider><App /></AuthProvider></MemoryRouter>)
    await user.type(screen.getByLabelText(/full name/i), 'New Learner')
    await user.type(screen.getByLabelText(/email address/i), 'learner@example.com')
    await user.type(screen.getByLabelText(/^password$/i), 'Strong-pass-92!')
    await user.type(screen.getByLabelText(/confirm password/i), 'Strong-pass-92!')
    await user.click(screen.getByRole('button', { name: 'Create account' }))
    expect(await screen.findByRole('heading', { name: 'Dashboard' })).toBeInTheDocument()
  })
})

describe.skipIf(!MOCK)('chapter progress', () => {
  it('starts at the first unfinished chapter and updates percent when marked complete', async () => {
    const user = userEvent.setup()
    open('/student/courses/math/watch')
    await screen.findByRole('heading', { name: 'Math chapter 4' })
    expect(screen.getAllByText('✓').length).toBe(3)
    await user.click(screen.getByRole('button', { name: /mark complete & next/i }))
    await screen.findByRole('heading', { name: 'Math chapter 5' }) // auto-advanced
    expect(screen.getByText('67%')).toBeInTheDocument()
    expect(screen.getAllByText('✓').length).toBe(4)
    // un-complete an earlier chapter
    await user.click(screen.getByRole('button', { name: /math chapter 4/i }))
    await user.click(await screen.findByRole('button', { name: /mark as not done/i }))
    await waitFor(() => expect(screen.getByText('50%')).toBeInTheDocument())
  })
})

describe.skipIf(!MOCK)('taking a quiz', () => {
  it('preview shows details, then runs through questions and shows a scored review', async () => {
    const user = userEvent.setup()
    open('/student/quizzes/1')
    expect(await screen.findByText('Test 01')).toBeInTheDocument()
    expect(screen.getByText('15 min')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /start quiz/i }))

    for (let i = 0; i < 10; i++) {
      await screen.findByText(`Question ${i + 1} of 10`, { exact: false })
      const right = i % 4, pick = i < 7 ? right : (right + 1) % 4 // 7 right, 3 wrong
      await user.click(screen.getAllByRole('radio')[pick])
      if (i < 9) await user.click(screen.getByRole('button', { name: /next →/i }))
    }
    expect(screen.getByText('10/10 answered')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /submit quiz/i }))

    expect(await screen.findByText('Review your answers')).toBeInTheDocument()
    expect(screen.getByText(/^7$/)).toBeInTheDocument()
    expect(screen.getByText(/70% · Well done!/)).toBeInTheDocument()
    expect(screen.getAllByText('Correct').length).toBe(10) // every question marks its right choice
    expect(screen.getAllByText('Your answer').length).toBe(3)
  })

  it('warns before submitting with unanswered questions and records a skip', async () => {
    const user = userEvent.setup()
    window.confirm = () => true
    open('/student/quizzes/2?start=1')
    await screen.findByText('Question 1 of 10', { exact: false })
    await user.click(screen.getAllByRole('radio')[0]) // only Q1 answered (correct: A)
    await user.click(screen.getByRole('button', { name: /submit quiz/i }))
    await screen.findByText('Review your answers')
    expect(screen.getAllByText('Skipped').length).toBe(9)
    expect(screen.getByText(/10% ·/)).toBeInTheDocument()
  })

  it('quiz list shows best score after attempts', async () => {
    open('/student/quizzes')
    expect(await screen.findByText(/Best: 7\/10 · 1 attempt/)).toBeInTheDocument()
    expect(screen.getAllByRole('link', { name: /retake/i }).length).toBe(2)
  })
})

describe.skipIf(!MOCK)('admin exams', () => {
  it('deletes one exam, then all', async () => {
    const user = userEvent.setup()
    window.confirm = () => true
    localStorage.setItem('yoloa_role', 'admin')
    render(<MemoryRouter initialEntries={['/admin/exams']}><AuthProvider><App /></AuthProvider></MemoryRouter>)
    await screen.findByText('Botany')
    await user.click(screen.getByRole('button', { name: /delete final exam botany/i }))
    await waitFor(() => expect(screen.queryByText('Botany')).not.toBeInTheDocument())
    expect(screen.getAllByRole('button', { name: /^delete final exam/i })).toHaveLength(4)
    await user.click(screen.getByRole('button', { name: /delete all/i }))
    expect(await screen.findByText(/No exams yet/)).toBeInTheDocument()
  })
})

describe.skipIf(!MOCK)('admin courses', () => {
  const asAdmin = (path) => {
    localStorage.setItem('yoloa_role', 'admin')
    return render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>)
  }
  it('deletes a course from the list (with a warning about enrolled students)', async () => {
    const user = userEvent.setup()
    let asked = ''
    window.confirm = (msg) => { asked = msg; return true }
    asAdmin('/admin/courses')
    await screen.findByText('Physics Department')
    await user.click(screen.getByRole('button', { name: /delete course physics department/i }))
    await waitFor(() => expect(screen.queryByText('Physics Department')).not.toBeInTheDocument())
    expect(asked).toMatch(/12 enrolled student/)
    expect(screen.getByRole('button', { name: /all courses \(5\)/i })).toBeInTheDocument()
  })
  it('deletes a course from its detail page and returns to the list', async () => {
    const user = userEvent.setup()
    window.confirm = () => true
    asAdmin('/admin/courses/chem')
    await user.click(await screen.findByRole('button', { name: /delete course/i }))
    await screen.findByRole('button', { name: /all courses \(4\)/i })
    expect(screen.queryByText('Chemistry Department')).not.toBeInTheDocument()
  })
})

describe.skipIf(!MOCK)('exams ⇄ quizzes are the same records', () => {
  const as = (role, path) => {
    localStorage.setItem('yoloa_role', role)
    return render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>)
  }

  it('admin builds + publishes an exam → students can see and take it as a quiz; unpublish hides it', async () => {
    const user = userEvent.setup()
    // ── admin builds the exam
    const admin = as('admin', '/admin/exams/new')
    const title = await screen.findByLabelText(/exam title/i)
    await user.clear(title); await user.type(title, 'Cell Biology Test')
    await user.type(screen.getByLabelText(/subject/i), 'Biology')
    await user.type(screen.getByLabelText('Question 1 text'), 'What is the powerhouse of the cell?')
    for (const [i, c] of ['Nucleus', 'Mitochondria', 'Ribosome', 'Golgi'].entries()) await user.type(screen.getByPlaceholderText(`Choice ${i + 1}`), c)
    await user.click(screen.getByRole('radio', { name: 'B' }))           // correct = Mitochondria
    await user.type(screen.getByLabelText(/points/i), '4')
    await user.click(screen.getByRole('button', { name: /^publish$/i }))
    const row = (await screen.findByText('Cell Biology Test')).closest('li')
    expect(within(row).getByText(/Published/)).toBeInTheDocument()
    expect(within(row).getByText(/Live in student Quizzes/)).toBeInTheDocument()
    admin.unmount()

    // ── student sees the very same exam as a quiz and can take it
    const student = as('student', '/student/quizzes')
    const qrow = (await screen.findByText('Cell Biology Test')).closest('li')
    expect(within(qrow).getByText('Biology')).toBeInTheDocument()
    expect(within(qrow).getByText(/1 Questions/)).toBeInTheDocument()
    await user.click(within(qrow).getByRole('link', { name: /attempt/i }))
    await screen.findByText('What is the powerhouse of the cell?')
    await user.click(screen.getByRole('radio', { name: /mitochondria/i }))
    await user.click(screen.getByRole('button', { name: /submit quiz/i }))
    expect(await screen.findByText('Review your answers')).toBeInTheDocument()
    expect(screen.getByText(/100% · Well done!/)).toBeInTheDocument()
    student.unmount()

    // ── admin unpublishes → hidden from students
    const admin2 = as('admin', '/admin/exams')
    await user.click(await screen.findByRole('button', { name: /unpublish cell biology test biology/i }))
    await waitFor(() => expect(screen.getByRole('button', { name: /^publish cell biology test biology/i })).toBeInTheDocument())
    admin2.unmount()
    as('student', '/student/quizzes')
    await screen.findByText('Practice Tests')
    expect(screen.queryByText('Cell Biology Test')).not.toBeInTheDocument()
  })

  it('refuses to publish an incomplete exam, but a draft is fine and stays hidden from students', async () => {
    const user = userEvent.setup()
    const admin = as('admin', '/admin/exams/new')
    await user.click(await screen.findByRole('button', { name: /^publish$/i }))   // blank question
    expect(await screen.findByText(/Question 1 needs text and at least 2 choices/)).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /keep in draft/i }))
    const row = (await screen.findByText('Midterm')).closest('li')
    expect(within(row).getByText('Draft')).toBeInTheDocument()
    admin.unmount()
    as('student', '/student/quizzes')
    await screen.findByText('Practice Tests')
    expect(screen.queryByText('Midterm')).not.toBeInTheDocument()
  })
})

describe.skipIf(!MOCK)('admin dashboard', () => {
  it('shows the number of registered students instead of the schedule', async () => {
    localStorage.setItem('yoloa_role', 'admin')
    render(<MemoryRouter initialEntries={['/admin/dashboard']}><AuthProvider><App /></AuthProvider></MemoryRouter>)
    expect(await screen.findByTestId('students-registered')).toHaveTextContent('31')
    expect(screen.getByRole('heading', { name: 'Students registered' })).toBeInTheDocument()
    expect(screen.getByText('New this week')).toBeInTheDocument()
    expect(screen.getByText('Enrolled in a course')).toBeInTheDocument()
    expect(screen.queryByRole('heading', { name: 'Schedule' })).not.toBeInTheDocument()
    expect(screen.queryByText(/of 20 chapters/)).not.toBeInTheDocument()
  })
})

describe.skipIf(!MOCK)('mobile / tablet menu', () => {
  const mount = (role = 'student', path = '/student/dashboard') => {
    localStorage.setItem('yoloa_role', role)
    return render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>)
  }

  it('opens from the hamburger, locks scroll, closes on Escape and returns focus', async () => {
    const user = userEvent.setup()
    mount()
    const burger = await screen.findByRole('button', { name: /open menu/i })
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    await user.click(burger)
    const dialog = screen.getByRole('dialog', { name: /main menu/i })
    expect(burger).toHaveAttribute('aria-expanded', 'true')
    expect(document.body.style.overflow).toBe('hidden')
    expect(screen.getByRole('button', { name: /close menu/i })).toHaveFocus()
    expect(within(dialog).getAllByRole('link').map((a) => a.textContent)).toEqual(expect.arrayContaining(['Dashboard', 'Courses', 'Calender', 'Notes', 'Quizzes', 'Library']))
    await user.keyboard('{Escape}')
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(document.body.style.overflow).not.toBe('hidden')
    expect(burger).toHaveFocus()
  })

  it('navigates and closes when a menu link is tapped; the backdrop and X also close it', async () => {
    const user = userEvent.setup()
    mount()
    await user.click(await screen.findByRole('button', { name: /open menu/i }))
    await user.click(within(screen.getByRole('dialog')).getByRole('link', { name: 'Quizzes' }))
    expect(await screen.findByRole('heading', { name: 'Quizzes' })).toBeInTheDocument()
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /open menu/i }))
    await user.click(screen.getByRole('button', { name: /close menu/i }))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('shows the admin links for admins', async () => {
    const user = userEvent.setup()
    mount('admin', '/admin/dashboard')
    await user.click(await screen.findByRole('button', { name: /open menu/i }))
    expect(within(screen.getByRole('dialog')).getAllByRole('link').map((a) => a.textContent)).toEqual(
      expect.arrayContaining(['Dashboard', 'Courses', 'Course Creation', 'Exams', 'Library']))
  })
})
