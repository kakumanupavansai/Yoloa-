// Runs the real UI against the real Django API. Skipped in mock mode.
//   (backend)  python manage.py migrate && python manage.py seed && python manage.py runserver
//   (frontend) VITE_USE_MOCK=false VITE_API_URL=http://localhost:8000/api npm test
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import App from '../App'
import { AuthProvider } from '../context/AuthContext'
import { examsApi } from '../services/api'

const LIVE = String(import.meta.env.VITE_USE_MOCK) === 'false'
const API = import.meta.env.VITE_API_URL || 'http://localhost:8000/api'
let originalFetch
const cookies = new Map()
const apiFetch = (path, init = {}) => fetch(`${API}${path}`, init)
const json = async (path, init) => {
  const response = await apiFetch(path, init)
  const data = await response.json().catch(() => null)
  if (!response.ok) throw new Error(data?.message || response.statusText)
  return data
}
const loginAs = async (email, password, role) => {
  await apiFetch('/auth/csrf')
  await json('/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, role }) })
  localStorage.removeItem('yoloa_role')
}
const open = (path) => render(<MemoryRouter initialEntries={[path]}><AuthProvider><App /></AuthProvider></MemoryRouter>)

beforeAll(() => {
  originalFetch = globalThis.fetch
  globalThis.fetch = async (input, init = {}) => {
    const target = typeof input === 'string' && input.startsWith('/api/') ? `${API}${input.slice('/api'.length)}` : input
    const url = new URL(typeof target === 'string' ? target : target.url, window.location.href)
    if (!url.pathname.startsWith('/api/') && !url.href.startsWith(API)) return originalFetch(target, init)
    const headers = new Headers(init.headers || {})
    if (cookies.size) headers.set('Cookie', [...cookies].map(([name, value]) => `${name}=${value}`).join('; '))
    const method = String(init.method || 'GET').toUpperCase()
    if (!['GET', 'HEAD', 'OPTIONS', 'TRACE'].includes(method) && cookies.has('csrftoken')) headers.set('X-CSRFToken', cookies.get('csrftoken'))
    const response = await originalFetch(target, { ...init, headers })
    const setCookies = response.headers.getSetCookie?.() || (response.headers.get('set-cookie') ? response.headers.get('set-cookie').split(/,\s*(?=[^;,]+=)/) : [])
    for (const setCookie of setCookies) {
      const [name, ...value] = setCookie.split(';', 1)[0].split('=')
      if (name && value.length) cookies.set(name, value.join('='))
    }
    return response
  }
})
afterAll(() => { if (originalFetch) globalThis.fetch = originalFetch })

describe.skipIf(!LIVE)('live backend', () => {
  beforeAll(async () => {
    // Run these mutating learning-flow checks only against a disposable copy of the local database.
    await loginAs('shyam', 'student123', 'student')
  })

  it('authenticates with a server session that survives dashboard reloads', async () => {
    expect(cookies.has('sessionid')).toBe(true)
    expect(cookies.has('csrftoken')).toBe(true)
    expect(await json('/auth/me')).toMatchObject({ username: 'shyam', role: 'student' })
    expect(localStorage.getItem('yoloa_token')).toBeNull()
    open('/student/dashboard')
    expect(await screen.findByRole('heading', { name: 'Dashboard' })).toBeInTheDocument()
    document.body.innerHTML = ''
    open('/student/dashboard')
    expect(await screen.findByRole('heading', { name: 'Dashboard' })).toBeInTheDocument()
  })

  it('enroll → player → mark chapters complete → final exam remains required', async () => {
    const user = userEvent.setup()
    const courseRows = await json('/courses')
    const social = courseRows.find((course) => /Social science Department/i.test(course.title))
    expect(social).toBeTruthy()
    // Keep this live check repeatable when a previous run left progress behind.
    await json(`/courses/${social.id}/enroll`, { method: 'POST' })
    const detail = await json(`/courses/${social.id}`)
    for (const chapter of detail.chapters || []) {
      await json(`/chapters/${chapter.id}/progress`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ completed: false }) })
    }
    await json(`/courses/${social.id}/enroll`, { method: 'DELETE' })
    open('/student/courses')
    const socialCard = (await screen.findByText('Social science Department')).closest('article')
    await user.click(within(socialCard).getByRole('button', { name: 'Enroll' }))
    await waitFor(() => expect(screen.getAllByRole('link', { name: /resume|review/i }).length).toBeGreaterThan(0), { timeout: 4000 })

    // Open the seeded Social science player using its current database id.
    document.body.innerHTML = ''
    open(`/student/courses/${social.id}/watch`)
    await screen.findByRole('heading', { name: /Social chapter 1/i })
    const player = await json(`/courses/${social.id}/player`)
    for (const chapter of player.modules) {
      await json(`/chapters/${chapter.id}/progress`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ completed: true }) })
    }
    const afterProgress = await json(`/courses/${social.id}`)
    expect(afterProgress.percent).toBe(100)
    expect(afterProgress.status).toBe('ongoing')
  })

  it('quiz: start → answer all → real server scoring + review', async () => {
    const user = userEvent.setup()
    open('/student/quizzes/1?start=1')
    for (let i = 0; i < 10; i++) {
      await screen.findByText(`Question ${i + 1} of 10`, { exact: false })
      await user.click(screen.getAllByRole('radio')[0]) // seed: correct answer is always A
      if (i < 9) await user.click(screen.getByRole('button', { name: /next →/i }))
    }
    await user.click(screen.getByRole('button', { name: /submit quiz/i }))
    expect(await screen.findByText('Review your answers')).toBeInTheDocument()
    expect(screen.getByText(/100% · Well done!/)).toBeInTheDocument()
  })

  it('not-enrolled player shows the server 403 message (admin-created course not joined)', async () => {
    const courseRows = await json('/courses')
    const social = courseRows.find((course) => /Social science Department/i.test(course.title))
    await json(`/courses/${social.id}/enroll`, { method: 'DELETE' })
    open(`/student/courses/${social.id}/watch`)
    expect(await screen.findByText(/Enroll in this course to start learning/i)).toBeInTheDocument()
  })
})

describe.skipIf(!LIVE)('live backend – admin deletes', () => {
  beforeAll(async () => {
    await loginAs('admin@example.com', 'admin123', 'admin')
    window.confirm = () => true
  })

  it('admin deletes a course from the Courses page (real DELETE /courses/:id)', async () => {
    const user = userEvent.setup()
    open('/admin/courses')
    await screen.findByText('English Department')
    await user.click(screen.getByRole('button', { name: /delete course english department/i }))
    await waitFor(() => expect(screen.queryByText('English Department')).not.toBeInTheDocument(), { timeout: 4000 })
    expect(screen.getByRole('button', { name: /all courses \(5\)/i })).toBeInTheDocument()
  })

  it('admin can delete a draft exam without assessment history', async () => {
    const user = userEvent.setup()
    document.body.innerHTML = ''
    open('/admin/exams')
    await screen.findByText('Botany')
    await user.click(screen.getByRole('button', { name: /delete Final exam Botany/i }))
    await waitFor(() => expect(screen.queryByText('Botany')).not.toBeInTheDocument(), { timeout: 4000 })
    expect(screen.getByText('Physics')).toBeInTheDocument()
  })
})

describe.skipIf(!LIVE)('live backend – exam ⇄ quiz link + dashboard', () => {
  it('an exam the admin publishes is a quiz for the student; a draft is not', async () => {
    await loginAs('admin@example.com', 'admin123', 'admin')
    const suffix = Date.now()
    const liveTitle = `Live Link Test ${suffix}`
    const draftTitle = `Hidden Draft ${suffix}`
    const q = [{ text: 'Capital of France?', choices: ['Paris', 'Rome', 'Oslo', 'Lima'], correct: 0, points: 2 }]
    await examsApi.create({ title: liveTitle, subject: 'Geography', duration: '10 mins', status: 'published', questions: q })
    await examsApi.create({ title: draftTitle, subject: 'Geography', duration: '10 mins', status: 'draft', questions: q })
    await expect(examsApi.create({ title: 'Bad', status: 'published', questions: [] })).rejects.toThrow(/at least one question/)

    await loginAs('swetha@example.com', 'student123', 'student')
    document.body.innerHTML = ''
    open('/student/quizzes')
    expect(await screen.findByText(liveTitle)).toBeInTheDocument()
    expect(screen.getAllByText('Geography').length).toBeGreaterThan(0)
    expect(screen.queryByText(draftTitle)).not.toBeInTheDocument()
  })

  it('admin dashboard shows registered students (not the schedule)', async () => {
    await loginAs('admin@example.com', 'admin123', 'admin')
    document.body.innerHTML = ''
    open('/admin/dashboard')
    expect(await screen.findByTestId('students-registered')).toHaveTextContent('5')
    expect(screen.getByText('Enrolled in a course')).toBeInTheDocument()
    expect(screen.queryByRole('heading', { name: 'Schedule' })).not.toBeInTheDocument()
  })
})
